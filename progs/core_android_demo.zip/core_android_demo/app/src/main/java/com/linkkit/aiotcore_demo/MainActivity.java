package com.linkkit.aiotcore_demo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.linkkit.aiotcore.AiotMqttClient;
import com.linkkit.aiotcore.AiotMqttException;
import com.linkkit.aiotcore.AiotMqttListener;

public class MainActivity extends AppCompatActivity {

    AiotMqttClient mqttClient;
    EditText pkInput = null;
    EditText dnInput = null;
    EditText dsInput = null;
    String pkString = null;
    String dnString = null;
    String dsString = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        pkInput = findViewById(R.id.pkInput);
        dnInput = findViewById(R.id.dnInput);
        dsInput = findViewById(R.id.dsInput);

        try {
            mqttClient = new AiotMqttClient();
        } catch (AiotMqttException e) {
            e.printStackTrace();
        }

        Button connect = (Button) findViewById(R.id.connect);
        connect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    pkString = pkInput.getText().toString();
                    dnString = dnInput.getText().toString();
                    dsString = dsInput.getText().toString();

                    /* 设置设备三元组信息(ProductKey, DeviceName, DeviceSecret)，并创建连接 */
                    mqttClient.setProductKey(pkString);
                    mqttClient.setDeviceName(dnString);
                    mqttClient.setDeviceSecret(dsString);
                    mqttClient.connect();
                } catch (AiotMqttException e) {
                    System.out.println(e.toString());
                }
            }
        });

        Button disconnect = (Button)findViewById(R.id.disconnect);
        disconnect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    /* 断开连接 */
                    mqttClient.disconnect();
                } catch (AiotMqttException e) {
                    System.out.println(e.toString());
                }
            }
        });

        Button subscribe = (Button) findViewById(R.id.subscribe);
        subscribe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                System.out.println("mqtt subscribe");

                PostReplyListener listener = new PostReplyListener();
                try {
                    /* 订阅指定的topic，注册数据监听回调方法，用户可以在物联网平台的产品页面查看到设备的topic信息 */
                    mqttClient.subscribe("/sys/" + pkString + "/" + dnString + "/thing/event/property/post_reply", 1, listener);
                } catch (AiotMqttException e) {
                    System.out.println(e.toString());
                }
            }
        });

        Button publish = (Button) findViewById(R.id.publish);
        publish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                byte[] payload = "{\"id\":\"1\",\"version\":\"1.0\",\"params\":{\"LightSwitch\":0}}".getBytes();
                try {
                    /* 向特定的topic发布消息, 此处演示向云端灯类产品发送关灯消息 */
                    mqttClient.publish("/sys/" + pkString + "/" + dnString + "/thing/event/property/post", payload, 0);
                } catch (AiotMqttException e) {
                    System.out.println(e.toString());
                }
            }
        });
    }
}

class PostReplyListener implements AiotMqttListener {
    /* 处理云端下发的publish消息 */
    public void publishArrived(String topic, int qos, byte[] payload) {
        System.out.println("publish arrived, topic = " + topic);
        System.out.println("payload = " + new String(payload));
    }
}
