//
//  WebViewController.swift
//  LinkkitLab
//
//  Created by Eden Tao on 2019/7/11.
//  Copyright © 2019 alibaba. All rights reserved.
//

import UIKit
import AVFoundation

class QRScanController: UIViewController, AVCaptureMetadataOutputObjectsDelegate {
    @IBOutlet weak var videoPreview: UIView!
    var stringQRCode = ""
    let avCaptureSession = AVCaptureSession()
    
    enum error: Error {
        case noCameraAvailable
        case videoInputInitFail
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        do {
            try scanQRCode()
        } catch {
            print("Failed to scan the QR code.")
        }
    }
    
    func metadataOutput(_ output: AVCaptureMetadataOutput, didOutput metadataObjects: [AVMetadataObject], from connection: AVCaptureConnection) {
        if metadataObjects.count > 0 {
            let machineReadableCode = metadataObjects[0] as! AVMetadataMachineReadableCodeObject
            if machineReadableCode.type == AVMetadataObject.ObjectType.qr {
                print("scan result: \(machineReadableCode.stringValue!)")
                stringQRCode = machineReadableCode.stringValue!
                performSegue(withIdentifier: "backToMain", sender: self)
                avCaptureSession.stopRunning()
            }
        }
    }
    
    func scanQRCode() throws {
        guard let avCaptureDevice = AVCaptureDevice.default(for: AVMediaType.video) else {
            print("No camera.")
            throw error.noCameraAvailable
        }
        
        guard let avCaptureInput = try? AVCaptureDeviceInput(device: avCaptureDevice) else {
            print("Failed to init camera.")
            throw error.videoInputInitFail
        }
        
        let avCaptureMetadataOutput = AVCaptureMetadataOutput()
        avCaptureMetadataOutput.setMetadataObjectsDelegate(self, queue: DispatchQueue.main)
        
        avCaptureSession.addInput(avCaptureInput)
        avCaptureSession.addOutput(avCaptureMetadataOutput)
        
        avCaptureMetadataOutput.metadataObjectTypes = [AVMetadataObject.ObjectType.qr]
        
        let avCaptureVideoPreviewLayer = AVCaptureVideoPreviewLayer(session: avCaptureSession)
        avCaptureVideoPreviewLayer.videoGravity = AVLayerVideoGravity.resizeAspectFill
        avCaptureVideoPreviewLayer.frame = videoPreview.bounds
        self.videoPreview.layer.addSublayer(avCaptureVideoPreviewLayer)
        
        avCaptureSession.startRunning()
    }
    
    //QRCode Format: {"ProductKey":"a1dZFHMWsNQ","DeviceName":"example_light"}
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "backToMain" {
            let destination = segue.destination as! ViewController
            do {
                if let json = try JSONSerialization.jsonObject(with: Data(stringQRCode.utf8), options: []) as? [String: Any] {
                    if let productKey = json["ProductKey"] as? String, let deviceName = json["DeviceName"] as? String {
                        print("productKey: \(productKey), deivceName: \(deviceName)")
                        destination.targetProductKeyText = productKey
                        destination.targetDeviceNameText = deviceName
                    }
                }
            } catch {
                print(error)
            }
        }
    }
}
