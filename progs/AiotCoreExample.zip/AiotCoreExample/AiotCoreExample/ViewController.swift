//
//  ViewController.swift
//  core_ios
//
//  Created by Eden Tao on 2019/6/24.
//  Copyright © 2019 alibaba. All rights reserved.
//

import UIKit
import AiotCoreFramework

class ViewController: UIViewController {
    
    // 用于demo演示的iOS三元组
    var productKeyText = "a1dZFHMWsNQ"
    var deviceNameText = "example_ios"
    var deviceSecretText = "KVOh7CH5n7Rt1pTpfMjdGWU6KQbo7C1K"
    
    // 用于demo演示的设备三元组，可通过扫描二维码获得
    // 二维码格式举例：{"ProductKey":"a1dZFHMWsNQ","DeviceName":"example_light"}
    // 在云端配置好iOS三元组和设备三元组的规则引擎后，可通过onTest和offTest进行测试
    var targetProductKeyText : String?
    var targetDeviceNameText : String?
    
    @IBOutlet weak var productKey: UITextField!
    @IBOutlet weak var deviceName: UITextField!
    @IBOutlet weak var deviceSecret: UITextField!
    @IBOutlet weak var startButton: UIButton!
    @IBOutlet weak var pubButton: UIButton!
    @IBOutlet weak var stopButton: UIButton!
    @IBOutlet weak var logText: UITextView!
    @IBOutlet weak var onButton: UIButton!
    @IBOutlet weak var offButton: UIButton!
    @IBOutlet weak var qrCodeButton: UIButton!
    
    // 初始化mqtt客户端
    var mqttClient = AiotMqttClient()

    override func viewDidLoad() {
        super.viewDidLoad()
        stopButton.isEnabled = false
        // Do any additional setup after loading the view.
        productKey.text = productKeyText
        deviceName.text = deviceNameText
        deviceSecret.text = deviceSecretText
        
        if targetProductKeyText != nil && targetDeviceNameText != nil {
            logApend("Device Product Key: \(targetProductKeyText!)\n")
            logApend("Device Device Name: \(targetDeviceNameText!)\n")
        }
    }
    
    @IBAction func qrCodeStart(_ sender: Any) {
        // 跳转到二维码扫描界面
        performSegue(withIdentifier: "openLink", sender: self)
    }
    
    private func logApend(_ text: String) {
        let newText = NSMutableAttributedString(string: "")
        
        newText.append(self.logText.attributedText)
        newText.append(NSAttributedString(string: text))
        
        self.logText.attributedText = newText
    }
    
    private func logMqttApend(toCloud: Bool, topic: String, payload: String) {
        let newText = NSMutableAttributedString(string: "")
        let directionMessage = toCloud ? ">>> [Pubish Message To Cloud]" : "<<< [Receive Message From Cloud]"
        let dateFormatter = DateFormatter()
        
        dateFormatter.dateFormat = "YYYY-MM-dd HH:mm:ss z"
        let dateString = dateFormatter.string(from: Date())
        
        newText.append(self.logText.attributedText)
        newText.append(NSAttributedString(string: "\n"))
        newText.append(NSAttributedString(string: "[\(dateString)]\n\(directionMessage):", attributes: [NSAttributedString.Key.font: UIFont(name: "HelveticaNeue-Bold", size: 12.0)!]))
        newText.append(NSAttributedString(string: "\n"))
        newText.append(NSAttributedString(string: "topic  : \(topic)\n"))
        newText.append(NSAttributedString(string: "\npayload: \(payload)\n\n"))
        
        self.logText.attributedText = newText
        self.logText.scrollRectToVisible(CGRect(x: self.logText.contentSize.width - 1, y: self.logText.contentSize.height - 1, width: 1, height: 1), animated: true)
    }

    @IBAction func startLinkkitTest(_ sender: UIButton) {
        guard productKey.text != nil && deviceName.text != nil && deviceSecret.text != nil else {
            return
        }
        
        // 设置product key
        mqttClient.setProductKey(productKey.text!)
        
        // 设置device name
        mqttClient.setDeviceName(deviceName.text!)
        
        // 设置device secret
        mqttClient.setDeviceSecret(deviceSecret.text!)
        
        // 设置默认mqtt默认消息接收handle
        mqttClient.setMqttDatapktClosure({(qos: Int, topic: String, payload: [UInt8]) in
            let strPayload = String(bytes: payload, encoding: .utf8) ?? ""
            
            DispatchQueue.main.async {
                self.logMqttApend(toCloud: false, topic: topic, payload: strPayload)
            }
        })
        
        mqttClient.setOtaNewFileClosure(){
            (_ fileData: OtaFileData) -> Void in
            print("url       : \(fileData.url)")
            print("size      : \(fileData.size)")
            print("version   : \(fileData.version)")
            print("signMethod: \(fileData.signMethod)")
            print("sign      : \(fileData.sign)")
            self.mqttClient.otaDownload(fileData, {(_ stage: OtaDownloadStage, _ buffer: [UInt8]?) -> Void in
                switch stage {
                case .start:
                    print("view ota download start")
                case .process:
                    print("view ota in process")
                    if let data = buffer {
                        let strPayload = String(bytes: data, encoding: .utf8) ?? ""
                        print(strPayload)
                    }
                case .invalid:
                    print("view ota data invalid")
                case .valid:
                    print("view ota data valid")
                case .stop:
                    print("view ota download stop")
                    print("new version: \(fileData.version)")
                    self.mqttClient.otaReportVersion(fileData.version)
                }
            })
        }

        do {
            // 连接阿里云物联网平台
            try mqttClient.connect()
            
            let newText = NSMutableAttributedString(string: "")
            
            newText.append(self.logText.attributedText)
            newText.append(NSAttributedString(string: "[Aliyun Link Platform Connected]\n", attributes: [NSAttributedString.Key.font: UIFont(name: "HelveticaNeue-Bold", size: 12.0)!]))
    
            self.logText.attributedText = newText
        }catch{
            print("\(error)")
        }

        startButton.isEnabled = false
        stopButton.isEnabled = true
    }
    
    @IBAction func stopLinkkitTest(_ sender: UIButton) {
        let newText = NSMutableAttributedString(string: "")
        
        newText.append(self.logText.attributedText)
        newText.append(NSAttributedString(string: "[Aliyun Link Platform Disconnected]\n", attributes: [NSAttributedString.Key.font: UIFont(name: "HelveticaNeue-Bold", size: 12.0)!]))
        
        self.logText.attributedText = newText
        
        do {
            // 与阿里云物联网平台断开连接
            try mqttClient.disconnect()
            
        }catch{
            print("\(error)")
        }
        
        startButton.isEnabled = true
        stopButton.isEnabled = false
    }
    
    
    @IBAction func subscribeLinkkitTest(_ sender: UIButton) {
        guard productKey.text != nil && deviceName.text != nil && deviceSecret.text != nil else {
            return
        }
        
        let topic = "/sys/\(productKey.text!)/\(deviceName.text!)/thing/event/+/post_reply"
        
        do {
            // mqtt消息订阅，如果第二个参数的handle为空，那么收到的消息会通过mqttClient.setMqttDatapktClosure
            // 设置的默认handle收到
            _ = try mqttClient.subscribe(topic){qos, topic, payload in
                let strPayload = String(bytes: payload, encoding: .utf8) ?? ""
                
                print("message from subscribe callback")
                DispatchQueue.main.async {
                    self.logMqttApend(toCloud: false, topic: topic, payload: strPayload)
                }
            }
        }catch{
            print("\(error)")
        }
    }
    
    @IBAction func unsubscribeLinkkitTest(_ sender: UIButton) {
        guard productKey.text != nil && deviceName.text != nil && deviceSecret.text != nil else {
            return
        }
        
        let topic = "/sys/\(productKey.text!)/\(deviceName.text!)/thing/event/+/post_reply"
        
        do {
            // 取消mqtt消息订阅
            _ = try mqttClient.unsubscribe(topic)
        }catch{
            print("\(error)")
        }
    }
    
    @IBAction func publishLinkkitTest(_ sender: UIButton) {
        guard productKey.text != nil && deviceName.text != nil && deviceSecret.text != nil else {
            return
        }
        
        let topic = "/sys/\(productKey.text!)/\(deviceName.text!)/thing/event/property/post"
        let payload = "{\"id\":\"1\",\"version\":\"1.0\",\"params\":{\"LightSwitch\":0}}"
        
        do {
            // 向指定topic发布消息
            _ = try mqttClient.publish(0, topic, Array(payload.utf8))
            
            self.logMqttApend(toCloud: true, topic: topic, payload: payload)
        }catch{
            print("\(error)")
        }
    }
    
    @IBAction func onTest(_ sender: UIButton) {
        guard productKey.text != nil && deviceName.text != nil &&
            targetProductKeyText != nil && targetDeviceNameText != nil else {
            return
        }

        let topic = "/\(productKey.text!)/\(deviceName.text!)/user/update"
        let payload = "{\"ProductKey\":\"\(targetProductKeyText!)\",\"DeviceName\":\"\(targetDeviceNameText!)\",\"Action\":\"On\"}"
        
        do {
            _ = try mqttClient.publish(0, topic, Array(payload.utf8))
            
            self.logMqttApend(toCloud: true, topic: topic, payload: payload)
        }catch{
            print("\(error)")
        }
    }
    
    @IBAction func offTest(_ sender: UIButton) {
        guard productKey.text != nil && deviceName.text != nil &&
            targetProductKeyText != nil && targetDeviceNameText != nil else {
                return
        }
        
        let topic = "/\(productKey.text!)/\(deviceName.text!)/user/update"
        let payload = "{\"ProductKey\":\"\(targetProductKeyText!)\",\"DeviceName\":\"\(targetDeviceNameText!)\",\"Action\":\"Off\"}"
        
        do {
            _ = try mqttClient.publish(0, topic, Array(payload.utf8))
            
            self.logMqttApend(toCloud: true, topic: topic, payload: payload)
        }catch{
            print("\(error)")
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        do {
            try mqttClient.disconnect()
        } catch {
            print(error)
        }
    }
}

