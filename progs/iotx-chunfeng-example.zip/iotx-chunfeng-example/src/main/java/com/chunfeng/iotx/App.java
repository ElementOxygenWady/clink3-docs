package com.chunfeng.iotx;
import com.aliyuncs.DefaultAcsClient;
import com.aliyuncs.IAcsClient;
import com.aliyuncs.exceptions.ClientException;
import com.aliyuncs.exceptions.ServerException;
import com.aliyuncs.profile.DefaultProfile;
import com.google.gson.Gson;
import com.aliyuncs.iot.model.v20180120.*;

/**
 * Hello world!
 *
 */
public class App 
{
    private static String createProductExample() {
        //accessKeyId和secret为阿里云账号生成的访问API的密钥，可在物联网控制台查询
        DefaultProfile profile = DefaultProfile.getProfile("cn-shanghai", "", "");
        IAcsClient client = new DefaultAcsClient(profile);

        //创建产品的API，该API请求参数详见
        //https://help.aliyun.com/document_detail/69123.html?spm=a2c4g.11186623.6.693.4a5456cerYMA06
        CreateProductRequest request = new CreateProductRequest();

        //设置数据格式，这里填1就可以了
        request.setDataFormat(1);

        //设置产品名称
        request.setProductName("ChungfengExample");

        //设置节点类型，0代表网关
        request.setNodeType(0);

        try {
            CreateProductResponse response = client.getAcsResponse(request);

            //打印请求的返回值，这里可以拿到产品的唯一标识符Product Key
            System.out.println("创建设备成功:\n" + new Gson().toJson(response) + "\n");
            System.out.println("产品Product Key  :" + response.getData().getProductKey() + "\n");
            return response.getProductKey();
        } catch (ServerException e) {
            e.printStackTrace();
        } catch (ClientException e) {
            System.out.println("ErrCode:" + e.getErrCode());
            System.out.println("ErrMsg:" + e.getErrMsg());
            System.out.println("RequestId:" + e.getRequestId());
        }

        return null;
    }

    private static void registerDevice(String productKey) {
        if (productKey == null) {
            return;
        }

        DefaultProfile profile = DefaultProfile.getProfile("cn-shanghai", "", "");
        IAcsClient client = new DefaultAcsClient(profile);

        //创建设备的API，该API请求参数详见
        //https://help.aliyun.com/document_detail/69470.html?spm=a2c4g.11186623.6.704.4bbb41193ebXYu
        RegisterDeviceRequest request = new RegisterDeviceRequest();

        //设置产品的Product Key
        request.setProductKey(productKey);

        //设置设备的名称，该名称在产品下唯一；若不设置，物联网平台会随机生成一个名称
        //支持英文字母、数字和特殊字符-_@.:，长度限制4~32
        request.setDeviceName("ChunfengDevice");

        try {
            RegisterDeviceResponse response = client.getAcsResponse(request);
            System.out.println("创建设备成功:\n" + new Gson().toJson(response) + "\n");

            //打印设备的三元组
            System.out.println("设备Product Key  :" + response.getData().getProductKey());
            System.out.println("设备Device Name  :" + response.getData().getDeviceName());
            System.out.println("设备Device Secret:" + response.getData().getDeviceSecret() + "\n");
        } catch (ServerException e) {
            e.printStackTrace();
        } catch (ClientException e) {
            System.out.println("ErrCode:" + e.getErrCode());
            System.out.println("ErrMsg:" + e.getErrMsg());
            System.out.println("RequestId:" + e.getRequestId());
        }
    }

    public static void main( String[] args ) {
        //创建产品
        String productKey = createProductExample();

        //创建设备
        registerDevice(productKey);
    }
}
