#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <linux/if.h>
#include <linux/if_packet.h>
#include <linux/if_ether.h>
#include <net/ethernet.h>
#include <netinet/in.h>
#include <netdb.h>
#include <pthread.h>

#include "aiot_errno.h"
#include "aiot_log_api.h"
#include "aiot_wifi_api.h"
#include "linux_sys.h"

char    *g_ifname          = "wlx00259cf84f36";
int32_t  g_sock_fd         = 0;
char    *product_key       = "a1X2bEnP82z";
char    *product_secret    = "7jluWm1zql7bt8qK";
char    *device_name       = "example_core";
uint8_t  mac[]             = { 0x00, 0x25, 0x9c, 0xf8, 0x4f, 0x36 };

typedef struct {
    void *handle;
    wifi_frame_recv_t frame_recv;
} linux_sniffer_thread_args_t;

static uint8_t sniffer_mode_flag = 0;

int32_t linux_raw_socket_init(void)
{
    struct ifreq ifr;
    struct sockaddr_ll sll;
    char buffer[256] = {0};

    memset(&ifr, 0, sizeof(struct ifreq));
    memset(&sll, 0, sizeof(struct sockaddr_ll));

    memset(buffer, 0, 256);
    snprintf(buffer, 256, "ifconfig %s down", g_ifname);
    system(buffer);

    memset(buffer, 0, 256);
    snprintf(buffer, 256, "iwconfig %s mode monitor", g_ifname);
    system(buffer);

    memset(buffer, 0, 256);
    snprintf(buffer, 256, "ifconfig %s up", g_ifname);
    system(buffer);

    g_sock_fd = socket(AF_PACKET, SOCK_RAW, htons(ETH_P_ALL));
    if (g_sock_fd < 0) {
        perror("raw socket error: ");
        return -1;
    }
        
    memcpy(ifr.ifr_name, g_ifname , strlen(g_ifname));
    if (ioctl(g_sock_fd, SIOCGIFINDEX, &ifr) < 0) {
        perror("SIOCGIFINDED error: ");
        return -1;
    }

    sll.sll_family = AF_PACKET;
    sll.sll_ifindex = ifr.ifr_ifindex;
    sll.sll_protocol = htons(ETH_P_ALL);
    if (bind(g_sock_fd, (struct sockaddr *)&sll, sizeof(sll)) < 0) {
        perror("bind error: ");
        return -1;
    }

    if (ioctl(g_sock_fd, SIOCGIFFLAGS, &ifr) < 0) {
        perror("SIOCGIFFLAGS error: ");
        return -1;
    }
    ifr.ifr_flags |= IFF_PROMISC;
    if (ioctl(g_sock_fd, SIOCSIFFLAGS, &ifr) < 0) {
        perror("SIOCSIFFLAGS error: ");
        return -1;
    }

    return 0;
}

int32_t linux_raw_socket_read(uint8_t *buffer, uint32_t buffer_len)
{
    int32_t recv_bytes = 0;

    if (buffer == NULL || buffer_len == 0) {
        return -1;
    }

    recv_bytes = recvfrom(g_sock_fd, buffer, buffer_len, 0, NULL, NULL);
    if (recv_bytes < 0) {
        perror("raw socket recv error: ");
        return recv_bytes;
    }

    return recv_bytes;
}

int32_t linux_raw_socket_deinit(void)
{
    char buffer[256] = {0};

    close(g_sock_fd);
    g_sock_fd = 0;

    memset(buffer, 0, 256);
    snprintf(buffer, 256, "ifconfig %s down", g_ifname);
    system(buffer);

    memset(buffer, 0, 256);
    snprintf(buffer, 256, "iwconfig %s mode managed", g_ifname);
    system(buffer);

    memset(buffer, 0, 256);
    snprintf(buffer, 256, "ifconfig %s up", g_ifname);
    system(buffer);

    return 0;
}

void *linux_sniffer_mode(void *args)
{
    int32_t res = 0, recv_bytes = 0;
    uint8_t *buffer = NULL;
    const uint32_t buffer_len = 3000;
    linux_sniffer_thread_args_t *thread_args = NULL;
    aiot_wifi_mac_frame_t mac_frame; 

    if (args == NULL) {
        printf("invalid args\n");
        return NULL;
    }
    thread_args = (linux_sniffer_thread_args_t *)args;
    memset(&mac_frame, 0, sizeof(aiot_wifi_mac_frame_t));

    buffer = malloc(buffer_len);
    if (buffer == NULL) {
        printf("sniffer buffer malloc failed\n");
        return NULL;
    }

    /* raw socket open */
    res = linux_raw_socket_init();
    if (res < 0) {
        free(buffer);
        return NULL;
    }

    while(sniffer_mode_flag) {
        memset(buffer, 0, buffer_len);

        /* read OSI Layer 2 packet*/
        recv_bytes = linux_raw_socket_read(buffer, buffer_len);
        if (recv_bytes < 0) {
            continue;
        }

/*         {
            uint32_t idx = 0;
            printf("recv_bytes: %d\n",buffer_len);
            printf("--------------------------------------------------\n");
            for (idx = 0;idx < 180;idx++) {
                if (idx % 16 == 0) {
                    printf("\n");
                }
                printf("%02X ",buffer[idx]);
            }
            printf("\n");
            printf("--------------------------------------------------\n");
        } */

        mac_frame.buffer = buffer;
        mac_frame.buffer_len = recv_bytes;

        thread_args->frame_recv(thread_args->handle, &mac_frame);
    }

    linux_raw_socket_deinit();

    free(buffer);
    free(args);

    return NULL;
}

int32_t linux_ap_mode(void)
{
    char buffer[256] = {0};
    char *ap_ssid = "linkkit-ap";
    char *ap_passwd = "";

    /**
     * using linux16.04 network manager to create wireless access point
     * reference:
     * https://developer.gnome.org/NetworkManager/stable/nmcli.html
     * https://unix.stackexchange.com/questions/234552/create-wireless-access-point-and-share-internet-connection-with-nmcli
     */
    memset(buffer, 0, 256);
    snprintf(buffer, 256, "ifconfig %s down", g_ifname);
    system(buffer);

    memset(buffer, 0, 256);
    snprintf(buffer, 256, "nmcli connection down %s",ap_ssid);
    system(buffer);

    memset(buffer, 0, 256);
    snprintf(buffer, 256, "nmcli connection delete %s",ap_ssid);
    system(buffer);

    memset(buffer, 0, 256);
    snprintf(buffer, 256, "nmcli connection add con-name %s type wifi ifname %s autoconnect yes ssid %s mode ap", ap_ssid, g_ifname, ap_ssid);
    system(buffer);

    if (strlen(ap_passwd) == 0) {
        memset(buffer, 0, 256);
        snprintf(buffer, 256, "nmcli connection modify %s 802-11-wireless.mode ap ipv4.method shared", ap_ssid);
        system(buffer);
    }else{
        memset(buffer, 0, 256);
        snprintf(buffer, 256, "nmcli connection modify %s 802-11-wireless.mode ap 802-11-wireless-security.key-mgmt wpa-psk ipv4.method shared 802-11-wireless-security.psk %s", ap_ssid, ap_passwd);
        system(buffer);
    }

    memset(buffer, 0, 256);
    snprintf(buffer, 256, "nmcli connection up %s", ap_ssid);
    system(buffer);

    return 0;
}

int32_t linux_switch_mode(void *handle, aiot_wifi_wlan_mode_t mode, void *data)
{
    int32_t res = 0;
    static pthread_t sniffer_mode_thread;

    switch (mode)
    {
        case WIFI_MODE_SNIFFER: {
            printf("switch to WIFI_MODE_SNIFFER\n");
            if (sniffer_mode_flag == 0 && sniffer_mode_thread == 0) {
                linux_sniffer_thread_args_t *thread_args = NULL;
                sniffer_mode_flag = 1;

                thread_args = malloc(sizeof(linux_sniffer_thread_args_t));
                if (thread_args == NULL) {
                    return -1;
                }
                memset(thread_args, 0, sizeof(linux_sniffer_thread_args_t));

                thread_args->handle = handle;
                thread_args->frame_recv = (wifi_frame_recv_t)data;

                res = pthread_create(&sniffer_mode_thread, NULL, linux_sniffer_mode, thread_args);
                if (res < 0) {
                    printf("create sniffer mode thread failed\n");
                    return res;
                }
            }
        }
        break;
        case WIFI_MODE_STA: {
            printf("switch to WIFI_MODE_STA\n");
            if (sniffer_mode_flag == 1) {
                sniffer_mode_flag = 0;
                pthread_join(sniffer_mode_thread, NULL);
                sniffer_mode_thread = 0;
            }
        }
        break;
        case WIFI_MODE_AP: {
            printf("switch to WIFI_MODE_AP\n");
            if (sniffer_mode_flag == 1) {
                sniffer_mode_flag = 0;
                pthread_join(sniffer_mode_thread, NULL);
                sniffer_mode_thread = 0;
            }
            linux_ap_mode();
        }
        break;
        default: {
            printf("unknown mode\n");
        }
        break;
    }

    return 0;
}

int32_t linux_switch_channel(void *handle, uint8_t channel)
{
    char buffer[256] = {0};

    memset(buffer, 0, 256);
    snprintf(buffer, 256, "iwconfig %s channel %d", g_ifname,channel);
    system(buffer);
    printf("switch channel: %d\n",channel);

    return 0;
}

int32_t linux_frame_send(void *handle, aiot_wifi_frame_type_t type, aiot_wifi_mac_frame_t *mac_frame)
{
    /* new raw socket */
    uint8_t t_buffer[512];
    struct ifreq t_ifr;
    struct sockaddr_ll t_sll;
    struct packet_mreq t_mr;
    int32_t t_size;

    uint8_t t_radiotap[] = {0x00, 0x00, 0x0d, 0x00, 0x04, 0x80, 0x02, 0x00, 0x20, 0x00, 0x00, 0x00, 0x00};

    if (g_sock_fd < 0) {
        g_sock_fd = socket(PF_PACKET, SOCK_RAW, htons(ETH_P_ALL));

        if (g_sock_fd < 0) {
            printf("<create_raw_socket> socket(PF_PACKET,SOCK_RAW,htons(ETH_P_ALL)) failed!");
            return -1;
        }
        /* get the index of the interface */
        memset(&t_ifr, 0, sizeof(t_ifr));
        strncpy(t_ifr.ifr_name, g_ifname, sizeof(t_ifr.ifr_name) - 1);
        if (ioctl(g_sock_fd, SIOCGIFINDEX, &t_ifr) < 0) {
            printf("<create_raw_socket> ioctl(SIOCGIFINDEX) failed!");
            return -1;
        }
        /* bind the raw socket to the interface */

        memset(&t_sll, 0, sizeof(t_sll));
        t_sll.sll_family = AF_PACKET;
        t_sll.sll_ifindex = t_ifr.ifr_ifindex;
        t_sll.sll_protocol = htons(ETH_P_ALL);
        if (bind(g_sock_fd, (struct sockaddr *)&t_sll, sizeof(t_sll)) < 0) {
            printf("<create_raw_socket> bind(ETH_P_ALL) failed!");
            return -1;
        }
        /* open promisc */
        memset(&t_mr, 0, sizeof(t_mr));
        t_mr.mr_ifindex = t_sll.sll_ifindex;
        t_mr.mr_type = PACKET_MR_PROMISC;
        if (setsockopt(g_sock_fd, SOL_PACKET, PACKET_ADD_MEMBERSHIP, &t_mr, sizeof(t_mr)) < 0) {
            printf("<create_raw_socket> setsockopt(PACKET_MR_PROMISC) failed!");
            return -1;
        }
    }
    //return g_sock_fd;

    memcpy(t_buffer, t_radiotap, 13);
    mac_frame->buffer_len -= 4;
    memcpy(t_buffer + 13, mac_frame->buffer, mac_frame->buffer_len);
    mac_frame->buffer_len += 13;
    t_size = write(g_sock_fd, t_buffer, mac_frame->buffer_len);
    if (t_size < 0) {
        printf("<send_80211_frame> write() failed!");
        perror("write error:");
        return -1;
    }
    return t_size;
}

int32_t linux_connect_ap(void *handle, aiot_wifi_apinfo_t *apinfo)
{
    char buffer[128] = {0};
    char *wifi_name = "linkkit";

    printf("ssid  : %s\n",apinfo->ssid);
    printf("passwd: %s\n",apinfo->passwd);

    /** 
     * using linux16.04 network manager to connect ap
     * reference: 
     * https://developer.gnome.org/NetworkManager/stable/nmcli.html
     * https://www.96boards.org/documentation/consumer/guides/wifi_commandline.md.html
     */
    memset(buffer, 0, 128);
    snprintf(buffer, 128, "nmcli connection down %s",wifi_name);
    system(buffer);

    memset(buffer, 0, 128);
    snprintf(buffer, 128, "nmcli connection delete %s",wifi_name);
    system(buffer);

    memset(buffer, 0, 128);
    snprintf(buffer, 128, "nmcli connection add con-name %s ifname %s type wifi ssid %s", wifi_name, g_ifname, apinfo->ssid);
    system(buffer);

    /**
     * security reference: 
     * https://developer.gnome.org/NetworkManager/stable/settings-802-11-wireless-security.html 
     */
    if (strlen((char *)apinfo->passwd) == 0) {
        memset(buffer, 0, 128);
        snprintf(buffer, 128, "nmcli connection modify %s wifi-sec.key-mgmt %s", "none", wifi_name);
        system(buffer);
    }else{
        memset(buffer, 0, 128);
        snprintf(buffer, 128, "nmcli connection modify %s wifi-sec.key-mgmt %s", wifi_name, "wpa-psk");
        system(buffer);

        memset(buffer, 0, 128);
        snprintf(buffer, 128, "nmcli connection modify %s wifi-sec.psk %s", wifi_name, apinfo->passwd);
        system(buffer);
    }
    

    memset(buffer, 0, 128);
    snprintf(buffer, 128, "nmcli connection up %s",wifi_name);
    system(buffer);

    return 0;
}

int32_t linux_wifi_event_handle(void *handle, aiot_wifi_event_t *event)
{
    switch (event->type) {
        case WIFI_EVENT_APINFO: {
            aiot_wifi_apinfo_t apinfo;
            memset(&apinfo, 0, sizeof(aiot_wifi_apinfo_t));

            memcpy(apinfo.ssid, event->data.apinfo.ssid, strlen(event->data.apinfo.ssid));
            memcpy(apinfo.passwd, event->data.apinfo.passwd, strlen(event->data.apinfo.passwd));
            memcpy(apinfo.bssid, event->data.apinfo.bssid, WIFI_BSSID_LEN);

            linux_connect_ap(handle, &apinfo);
        }
        break;
        case WIFI_EVENT_USERDATA: {

        }
        break;
    }

    return 0;
}

void linux_wifi_provision(void)
{
    int32_t res = 0;
    void *handle = NULL;
    uint16_t flags = WIFIOPT_FLAGS_SMARTCONFIG|WIFIOPT_FLAGS_ZEROCONFIG;

    handle = aiot_wifi_init();
    if (handle == NULL) {
        printf("wifi provision init failed\n");
        return;
    }
    aiot_wifi_setopt(handle, WIFIOPT_PRODUCT_KEY,       (void *)product_key);
    aiot_wifi_setopt(handle, WIFIOPT_DEVICE_NAME,       (void *)device_name);
    aiot_wifi_setopt(handle, WIFIOPT_DECRYPT_KEY,       (void *)product_secret);
    aiot_wifi_setopt(handle, WIFIOPT_MAC_ADDR,       (void *)mac);
    aiot_wifi_setopt(handle, WIFIOPT_EVENT_HANDLE,      (void *)linux_wifi_event_handle);
    aiot_wifi_setopt(handle, WIFIOPT_SWITCH_MODE_CB,    (void *)linux_switch_mode);
    aiot_wifi_setopt(handle, WIFIOPT_SWITCH_CHANNEL_CB, (void *)linux_switch_channel);
    aiot_wifi_setopt(handle, WIFIOPT_MACFRAME_SEND_CB,  (void *)linux_frame_send);

    aiot_wifi_enable(handle, flags);

    while(1) {
        res = aiot_wifi_process(handle);
        if (res == ERRCODE_WIFI_STATE_IDLE) {
            break;
        }
        usleep(100 * 1000);
    }

    aiot_wifi_deinit(&handle);
}

int main(int argc, char *argv[])
{
    /* set log level */
    aiot_log_set_level(AIOT_LOG_DEBUG);

    /* start wifi provision until succeed */
    linux_wifi_provision();

    return 0;
}