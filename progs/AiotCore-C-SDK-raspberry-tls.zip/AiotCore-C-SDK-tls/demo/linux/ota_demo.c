#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include "linux_sys.h"
#include "aiot_errno.h"
#include "aiot_log_api.h"
#include "aiot_sys_callback.h"
#include "aiot_mqtt_api.h"
#include "aiot_ota_api.h"

#define OTA_DOWNLOAD_BUFFER (100)

char *product_key       = "a1X2bEnP82z";
char *product_secret    = "7jluWm1zql7bt8qK";
char *device_name       = "example_core";
char *device_secret     = "VhQTSW48QngI1lG6ytYsbcNjqxMH4HpC";
static uint8_t g_process_running = 0;
static uint8_t g_download_running = 0;
static pthread_t g_download_thread;
static pthread_t g_process_thread;

typedef struct {
    void *ota_handle;
    uint32_t total_size;
} demo_download_t;

void demo_ctrlpkt_handle(void *handle, aiot_mqtt_ctrlpkt_t *packet, void *userdata)
{
    switch (packet->ctrltype) {
        case MQTTCTRL_HEARTBEAT_RESPONSE: {

        }
        break;
        case MQTTCTRL_SUB_RESPONSE: {

        }
        break;
        case MQTTCTRL_UNSUB_RESPONSE: {

        }
        break;
        case MQTTCTRL_PUB_RESPONSE: {

        }
        break;
    }
}

void demo_datapkt_handle(void *handle, aiot_mqtt_datapkt_t *packet, void *userdata)
{
    printf("data packet received:\n");
    printf("topic  : %.*s\n", packet->topic_len, packet->topic);
    printf("payload: %.*s\n", packet->payload_len, packet->payload);
}

void *demo_process_thread(void *param)
{
    while (g_process_running) {
        sleep(1);

        /* handle heartbeat send and qos1 message re-publish */
        aiot_mqtt_process(param);
    }

    return NULL;
}

void *demo_download_thread(void *param)
{
    int32_t res = 0;
    uint32_t download_size = 0;
    demo_download_t *download = (demo_download_t *)param;
    uint8_t firmware_buffer[OTA_DOWNLOAD_BUFFER] = {0};

    while (g_download_running) {
        res = aiot_ota_download(download->ota_handle, firmware_buffer, OTA_DOWNLOAD_BUFFER);
        if (res < ERRCODE_OTA_DOWNLOAD_STOP) {
            if (res == ERRCODE_OTA_DOWNLOAD_START) {
                printf("ota download start\n");
            }else if (res == ERRCODE_OTA_DOWNLOAD_RENEWAL) {
                printf("network error, we are in reconnect state\n");
            }else if (res == ERRCODE_OTA_FIRMWARE_VALID_SIGN) {
                printf("firmware verify success\n");
            }else if (res == ERRCODE_OTA_FIRMWARE_INVALID_SIGN) {
                printf("firmware verify failed\n");
                g_download_running = 0;
            }else if (res == ERRCODE_OTA_FIRMWARE_UNKNOWN_SIGN_METHOD) {
                printf("firmware unknown sign method\n");
            }else{
                printf("error code: -0x%04X\n",-res);
                g_download_running = 0;
            }
        }else if (res == ERRCODE_OTA_DOWNLOAD_STOP) {
            printf("firmware download stop\n");
            aiot_ota_report_version(download->ota_handle, "2.0.0");
            g_download_running = 0;
        }else{
            download_size += res;
            if ((download_size * 100/download->total_size) % 10 == 0) {
                printf("download progress: %d%%\n",download_size * 100/download->total_size);
                aiot_ota_report_progress(download->ota_handle, download_size * 100/download->total_size, NULL);
            }
        }
    }

    free(download);
    return NULL;
}

int32_t linux_ota_event_handle(void *handle, aiot_ota_event_t *event, void *userdata)
{
    int32_t res = 0;
    demo_download_t *download = NULL;

    switch (event->event_type) {
        case OTA_EVENT_NEW_FIRMWARE: {
            printf("receive new firmware\n");
            printf("url        : %s\n",event->data.firmware.url);
            printf("size       : %d\n",event->data.firmware.size);
            printf("version    : %s\n",event->data.firmware.version);
            printf("sign method: %s\n",event->data.firmware.sign_method);
            printf("sign       : %s\n",event->data.firmware.sign);
            if (g_download_running) {
                g_download_running = 0;
                pthread_join(g_download_thread, NULL);
            }
            aiot_ota_setopt(handle, OTAOPT_DOWNLOAD_FRIMWARE, &event->data.firmware);
            g_download_running = 1;

            /* create ota download thread */
            download = malloc(sizeof(demo_download_t));
            if (download == NULL) {
                printf("memory malloc failed\n");
                return 0;
            }
            memset(download, 0, sizeof(demo_download_t));
            download->ota_handle = handle;
            download->total_size = event->data.firmware.size;

            res = pthread_create(&g_download_thread, NULL, demo_download_thread, download);
            if (res < 0) {
                free(download);
            }
        }
        break;
    }

    return 0;
}

int main(int argc, char *argv[])
{
    int32_t res = 0;
    void *mqtt_handle = NULL;
    char *url = "iot-as-mqtt.cn-shanghai.aliyuncs.com";
    char host[100] = {0};
    uint16_t port = 1883;
    const char *host_fmt = "%s.%s";
    void *ota_handle = NULL;

    /* linux memstat */
    linux_memstat_init();

    /* set log level */
    aiot_log_set_level(AIOT_LOG_INFO);

    /* get mqtt handle */
    mqtt_handle = aiot_mqtt_init();
    if (mqtt_handle == NULL) {
        printf("aiot_mqtt_init failed\n");
        return -1;
    }

    snprintf(host, 100, host_fmt, product_key, url);
    aiot_mqtt_setopt(mqtt_handle, MQTTOPT_HOST, (void *)host);
    aiot_mqtt_setopt(mqtt_handle, MQTTOPT_PORT, (void *)&port);
    aiot_mqtt_setopt(mqtt_handle, MQTTOPT_PRODUCT_KEY, (void *)product_key);
    aiot_mqtt_setopt(mqtt_handle, MQTTOPT_DEVICE_NAME, (void *)device_name);
    aiot_mqtt_setopt(mqtt_handle, MQTTOPT_DEVICE_SECRET, (void *)device_secret);
    aiot_mqtt_setopt(mqtt_handle, MQTTOPT_CTRLPKT_HANDLE, (void *)demo_ctrlpkt_handle);
    aiot_mqtt_setopt(mqtt_handle, MQTTOPT_DATAPKT_HANDLE, (void *)demo_datapkt_handle);

    res = aiot_mqtt_connect(mqtt_handle);
    if (res < 0) {
        printf("aiot_mqtt_connect failed, res = %d\n", res);
        return -1;
    }

    /* create thread for sending heartbeat */
    g_process_running = 1;
    res = pthread_create(&g_process_thread, NULL, demo_process_thread, mqtt_handle);
    if (res < 0) {
        printf("pthread_create failed\n");
        aiot_mqtt_deinit(&mqtt_handle);
        return -1;
    }

    /* init ota handle */
    ota_handle = aiot_ota_init();
    if (ota_handle == NULL) {
        printf("aiot_ota_init failed\n");
        aiot_mqtt_deinit(&mqtt_handle);
        return -1;
    }

    aiot_ota_setopt(ota_handle, OTAOPT_PRODUCT_KEY, product_key);
    aiot_ota_setopt(ota_handle, OTAOPT_DEVICE_NAME, device_name);
    aiot_ota_setopt(ota_handle, OTAOPT_MQTT_HANDLE, mqtt_handle);
    aiot_ota_setopt(ota_handle, OTAOPT_EVENT_HANDLE, linux_ota_event_handle);

    aiot_ota_enable(ota_handle);
    aiot_ota_report_version(ota_handle, "1.5.0");

    while (1) {
        /* recv packet from network */
        res = aiot_mqtt_recv(mqtt_handle);
        if (res < 0) {
            /**
             * if network closed, aiot_mqtt_recv will be returned immediately if
             * it is not try to reconnect this time.
             */
            if (res == ERRCODE_SYS_NWK_CLOSED) {
                sleep(1);
            }
        }
    }

    g_process_running = 0;
    pthread_join(g_process_thread, NULL);

    aiot_mqtt_deinit(&mqtt_handle);
    aiot_ota_deinit(&ota_handle);
    linux_memstat_print();
    linux_memstat_deinit();

    return 0;
}