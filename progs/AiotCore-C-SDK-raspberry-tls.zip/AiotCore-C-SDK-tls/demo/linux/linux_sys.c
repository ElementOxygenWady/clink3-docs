#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdint.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/select.h>
#include <sys/time.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <pthread.h>
#include "aiot_sys_callback.h"

#define NWK_SECURITY_ENABLED

#ifdef NWK_SECURITY_ENABLED
#include "net_sockets.h"
#include "ssl.h"
#include "ctr_drbg.h"
#endif

#ifdef NWK_SECURITY_ENABLED
typedef struct {
    mbedtls_net_context net_ctx;
    mbedtls_ssl_context ssl_ctx;
    mbedtls_ssl_config  ssl_config;
    mbedtls_x509_crt    x509_crt;
} linux_nwk_security_t;
#endif

typedef struct {
    int fd;
    uint8_t nwk_type;
    uint8_t security;
    char *host;
    uint16_t port;
#ifdef NWK_SECURITY_ENABLED
    linux_nwk_security_t security_ctx;
#endif
} linux_nwk_handle_t;

#define sys_printf(...) {printf("[%s:%d] ",__FUNCTION__,__LINE__);printf(__VA_ARGS__);}

#ifdef NWK_SECURITY_ENABLED
const char *ali_ca_crt = \
{
    \
    "-----BEGIN CERTIFICATE-----\r\n"
    "MIIDdTCCAl2gAwIBAgILBAAAAAABFUtaw5QwDQYJKoZIhvcNAQEFBQAwVzELMAkG\r\n" \
    "A1UEBhMCQkUxGTAXBgNVBAoTEEdsb2JhbFNpZ24gbnYtc2ExEDAOBgNVBAsTB1Jv\r\n" \
    "b3QgQ0ExGzAZBgNVBAMTEkdsb2JhbFNpZ24gUm9vdCBDQTAeFw05ODA5MDExMjAw\r\n" \
    "MDBaFw0yODAxMjgxMjAwMDBaMFcxCzAJBgNVBAYTAkJFMRkwFwYDVQQKExBHbG9i\r\n" \
    "YWxTaWduIG52LXNhMRAwDgYDVQQLEwdSb290IENBMRswGQYDVQQDExJHbG9iYWxT\r\n" \
    "aWduIFJvb3QgQ0EwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQDaDuaZ\r\n" \
    "jc6j40+Kfvvxi4Mla+pIH/EqsLmVEQS98GPR4mdmzxzdzxtIK+6NiY6arymAZavp\r\n" \
    "xy0Sy6scTHAHoT0KMM0VjU/43dSMUBUc71DuxC73/OlS8pF94G3VNTCOXkNz8kHp\r\n" \
    "1Wrjsok6Vjk4bwY8iGlbKk3Fp1S4bInMm/k8yuX9ifUSPJJ4ltbcdG6TRGHRjcdG\r\n" \
    "snUOhugZitVtbNV4FpWi6cgKOOvyJBNPc1STE4U6G7weNLWLBYy5d4ux2x8gkasJ\r\n" \
    "U26Qzns3dLlwR5EiUWMWea6xrkEmCMgZK9FGqkjWZCrXgzT/LCrBbBlDSgeF59N8\r\n" \
    "9iFo7+ryUp9/k5DPAgMBAAGjQjBAMA4GA1UdDwEB/wQEAwIBBjAPBgNVHRMBAf8E\r\n" \
    "BTADAQH/MB0GA1UdDgQWBBRge2YaRQ2XyolQL30EzTSo//z9SzANBgkqhkiG9w0B\r\n" \
    "AQUFAAOCAQEA1nPnfE920I2/7LqivjTFKDK1fPxsnCwrvQmeU79rXqoRSLblCKOz\r\n" \
    "yj1hTdNGCbM+w6DjY1Ub8rrvrTnhQ7k4o+YviiY776BQVvnGCv04zcQLcFGUl5gE\r\n" \
    "38NflNUVyRRBnMRddWQVDf9VMOyGj/8N7yy5Y0b2qvzfvGn9LhJIZJrglfCm7ymP\r\n" \
    "AbEVtQwdpf5pLGkkeB6zpxxxYu7KyJesF12KwvhHhm4qxFYxldBniYUr+WymXUad\r\n" \
    "DKqC5JlR3XC321Y9YeRq4VzW9v493kHMB65jUr9TU/Qr6cf9tveCX4XSQRjbgbME\r\n" \
    "HMUfpIBvFSDJ3gyICh3WZlXi/EjJKSZp4A==\r\n" \
    "-----END CERTIFICATE-----"
};
#endif

void *aiot_nwk_init(void)
{
    linux_nwk_handle_t *handle = NULL;

    handle = malloc(sizeof(linux_nwk_handle_t));
    if (handle == NULL) {
        return NULL;
    }
    memset(handle, 0, sizeof(linux_nwk_handle_t));

    return handle;
}

int32_t aiot_nwk_setopt(void *handle, aiot_sys_nwk_option_t option, void *data)
{
    linux_nwk_handle_t *nwk_handle = (linux_nwk_handle_t *)handle;

    if (handle == NULL || option >= SYSNWK_MAX || data == NULL) {
        return -1;
    }

    switch (option) {
        case SYSNWK_TYPE: {
            nwk_handle->nwk_type = *(uint8_t *)data;
        }
        break;
        case SYSNWK_HOST: {
            nwk_handle->host = malloc(strlen(data) + 1);
            if (nwk_handle->host == NULL) {
                sys_printf("malloc failed\n");
                return -1;
            }
            memset(nwk_handle->host, 0, strlen(data) + 1);
            memcpy(nwk_handle->host, data, strlen(data));
        }
        break;
        case SYSNWK_SECURITY: {
            nwk_handle->security = *(uint8_t *)data;
        }
        break;
        case SYSNWK_PORT: {
            nwk_handle->port = *(uint16_t *)data;
        }
        break;
        default: {
            sys_printf("unknown option\n");
        }
    }

    return 0;
}

static int32_t _linux_nwk_tcp_establish(void *handle)
{
    int32_t res = 0, fd = 0;
    char service[6] = {0};
    struct addrinfo hints;
    struct addrinfo *addrInfoList = NULL, *pos = NULL;

    linux_nwk_handle_t *nwk_handle = (linux_nwk_handle_t *)handle;

    memset(&hints, 0, sizeof(struct addrinfo));
    hints.ai_family = AF_INET; /* only IPv4 */
    hints.ai_socktype = SOCK_STREAM;
    hints.ai_protocol = IPPROTO_TCP;
    hints.ai_flags = 0;
    sprintf(service, "%u", nwk_handle->port);

    sys_printf("establish tcp connection with server(host='%s', port=[%u])\n", nwk_handle->host, nwk_handle->port);

    res = getaddrinfo(nwk_handle->host, service, &hints, &addrInfoList);
    if (res != 0) {
        sys_printf("getaddrinfo error, res: %s, host: %s, port: %s\n", gai_strerror(res), nwk_handle->host, service);
        return -1;
    }

    for (pos = addrInfoList; pos != NULL; pos = pos->ai_next) {
        if (pos->ai_family != AF_INET) {
            sys_printf("socket type error\n");
            res = -1;
            continue;
        }

        fd = socket(pos->ai_family, pos->ai_socktype, pos->ai_protocol);
        if (fd < 0) {
            sys_printf("create socket error\n");
            res = -1;
            continue;
        }

        if (connect(fd, pos->ai_addr, pos->ai_addrlen) == 0) {
            nwk_handle->fd = fd;
            res = 0;
            break;
        }

        close(fd);
        sys_printf("connect error, errno: %d\n",errno);
    }

    if (res == -1) {
        sys_printf("fail to establish tcp\n");
    } else {
        sys_printf("success to establish tcp, fd=%d\n", nwk_handle->fd);
    }
    freeaddrinfo(addrInfoList);

    return 0;
}

#ifdef NWK_SECURITY_ENABLED
static void _port_uint2str(uint16_t input, char *output)
{
    uint8_t i = 0, j = 0;
    char temp[6] = {0};

    do {
        temp[i++] = input % 10 + '0';
    } while ((input /= 10) > 0);

    do {
        output[--i] = temp[j++];
    } while (i > 0);
}

static int _security_random(void *handle, unsigned char *output, size_t output_len)
{
    aiot_sys_rand(output, output_len);
    return 0;
}

static int32_t _linux_nwk_security_establish(void *handle)
{
    int32_t res = 0;
    char port_str[6] = {0};
    linux_nwk_handle_t *nwk_handle = (linux_nwk_handle_t *)handle;

    mbedtls_net_init(&nwk_handle->security_ctx.net_ctx);
    mbedtls_ssl_init(&nwk_handle->security_ctx.ssl_ctx);
    mbedtls_ssl_config_init(&nwk_handle->security_ctx.ssl_config);
    mbedtls_x509_crt_init(&nwk_handle->security_ctx.x509_crt);

    sys_printf("establish security connection with server(host='%s', port=[%u])\n", nwk_handle->host, nwk_handle->port);

    _port_uint2str(nwk_handle->port, port_str);

    res = mbedtls_x509_crt_parse(&nwk_handle->security_ctx.x509_crt, (const unsigned char *)ali_ca_crt, strlen(ali_ca_crt) + 1);
    if (res < 0) {
        sys_printf("mbedtls_x509_crt_parse error, res: -0x%04X\n",-res);
        return res;
    }

    res = mbedtls_net_connect(&nwk_handle->security_ctx.net_ctx, nwk_handle->host, port_str, MBEDTLS_NET_PROTO_TCP);
    if (res < 0) {
        sys_printf("mbedtls_net_connect error, res: -0x%04X\n",-res);
        return res;
    }

    res = mbedtls_ssl_config_defaults(&nwk_handle->security_ctx.ssl_config, MBEDTLS_SSL_IS_CLIENT, MBEDTLS_SSL_TRANSPORT_STREAM, MBEDTLS_SSL_PRESET_DEFAULT);
    if (res < 0) {
        sys_printf("mbedtls_ssl_config_defaults error, res: -0x%04X\n",-res);
        return res;
    }

    mbedtls_ssl_conf_max_version(&nwk_handle->security_ctx.ssl_config, MBEDTLS_SSL_MAJOR_VERSION_3, MBEDTLS_SSL_MINOR_VERSION_3);
    mbedtls_ssl_conf_min_version(&nwk_handle->security_ctx.ssl_config, MBEDTLS_SSL_MAJOR_VERSION_3, MBEDTLS_SSL_MINOR_VERSION_3);
    mbedtls_ssl_conf_rng(&nwk_handle->security_ctx.ssl_config, _security_random, NULL);
    mbedtls_ssl_conf_authmode(&nwk_handle->security_ctx.ssl_config, MBEDTLS_SSL_VERIFY_REQUIRED);
    mbedtls_ssl_conf_ca_chain(&nwk_handle->security_ctx.ssl_config, &nwk_handle->security_ctx.x509_crt, NULL);

    res = mbedtls_ssl_setup(&nwk_handle->security_ctx.ssl_ctx, &nwk_handle->security_ctx.ssl_config);
    if (res < 0) {
        sys_printf("mbedtls_ssl_setup error, res: -0x%04X\n",-res);
        return res;
    }

    mbedtls_ssl_set_bio(&nwk_handle->security_ctx.ssl_ctx, &nwk_handle->security_ctx.net_ctx, mbedtls_net_send, mbedtls_net_recv, mbedtls_net_recv_timeout);
    mbedtls_ssl_conf_read_timeout(&nwk_handle->security_ctx.ssl_config, 10000);

    while ((res = mbedtls_ssl_handshake(&nwk_handle->security_ctx.ssl_ctx)) != 0) {
        if ((res != MBEDTLS_ERR_SSL_WANT_READ) && (res != MBEDTLS_ERR_SSL_WANT_WRITE)) {
            sys_printf("mbedtls_ssl_handshake error, res: -0x%04X\n",-res);
            return res;
        }
    }

    res = mbedtls_ssl_get_verify_result(&nwk_handle->security_ctx.ssl_ctx);
    if (res < 0) {
        sys_printf("mbedtls_ssl_get_verify_result error, res: -0x%04X\n",-res);
        return res;
    }

    sys_printf("success to establish security connection, fd = %d\n", (int)nwk_handle->security_ctx.net_ctx.fd);

    return 0;
}
#endif

static int32_t _linux_nwk_udp_establish(void *handle)
{
    int32_t sockfd;
    struct sockaddr_in servaddr;
    int opt_val = 1;
    linux_nwk_handle_t *nwk_handle = (linux_nwk_handle_t *)handle;

    sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    if (sockfd < 0) {
        sys_printf("create socket error, errno: %d\n", errno);
        perror("create socket error: ");
        return -1;
    }

    if (0 != setsockopt(sockfd, SOL_SOCKET, SO_BROADCAST, &opt_val, sizeof(opt_val))) {
        sys_printf("setsockopt(SO_BROADCAST) falied, errno: %d\n", errno);
        perror("setsockopt(SO_BROADCAST) error: ");
        close(sockfd);
        return -1;
    }

    if (0 != setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, &opt_val, sizeof(opt_val))) {
        sys_printf("setsockopt(SO_REUSEADDR) falied, errno: %d\n", errno);
        perror("setsockopt(SO_REUSEADDR) error: ");
        close(sockfd);
        return -1;
    }

    memset(&servaddr, 0, sizeof(struct sockaddr_in));
    servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
    servaddr.sin_family = AF_INET;
    servaddr.sin_port = htons(nwk_handle->port);

    if (-1 == bind(sockfd, (struct sockaddr *)&servaddr, sizeof(struct sockaddr_in))) {
        sys_printf("bind(%d) falied, errno: %d\n", (int)sockfd, errno);
        perror("bind(%d) error: ");
        close(sockfd);
        return -1;
    }

    nwk_handle->fd = sockfd;
    sys_printf("success to establish udp, fd=%d\n", (int)sockfd);

    return 0;
}

int32_t aiot_nwk_establish(void *handle)
{
    linux_nwk_handle_t *nwk_handle = (linux_nwk_handle_t *)handle;

    if (handle == NULL) {
        return -1;
    }

    if (nwk_handle->nwk_type == 0 && nwk_handle->host != NULL) {
        if (nwk_handle->security == 0) {
            return _linux_nwk_tcp_establish(handle);
        }else{
#ifdef NWK_SECURITY_ENABLED
            return _linux_nwk_security_establish(handle);
#else
            return -1;
#endif
        }
    } else if (nwk_handle->nwk_type == 3) {
        return _linux_nwk_udp_establish(handle);
    }

    sys_printf("unknown nwk type or tcp host absent\n");

    return -1;
}

static int32_t _linux_nwk_tcp_read(void *handle, uint8_t *buffer, uint32_t len, uint32_t timeout_ms)
{
    int res = 0;
    int32_t read_bytes = 0;
    ssize_t recv_res = 0;
    uint64_t timestart_ms = 0, timenow_ms = 0, timeselect_ms = 0;
    linux_nwk_handle_t *nwk_handle = (linux_nwk_handle_t *)handle;
    fd_set read_sets;
    struct timeval timestart, timenow, timeselect;

    FD_ZERO(&read_sets);
    FD_SET(nwk_handle->fd, &read_sets);

    /* Start Time */
    gettimeofday(&timestart, NULL);
    timestart_ms = timestart.tv_sec * 1000 + timestart.tv_usec / 1000;
    timenow_ms = timestart_ms;

    do {
        gettimeofday(&timenow, NULL);
        timenow_ms = timenow.tv_sec * 1000 + timenow.tv_usec / 1000;

        if (timenow_ms - timestart_ms >= timenow_ms ||
            timeout_ms - (timenow_ms - timestart_ms) > timeout_ms) {
            break;
        }

        timeselect_ms = timeout_ms - (timenow_ms - timestart_ms);
        timeselect.tv_sec = timeselect_ms / 1000;
        timeselect.tv_usec = timeselect_ms % 1000 * 1000;

        res = select(nwk_handle->fd + 1, &read_sets, NULL, NULL, &timeselect);
        if (res == 0) {
            /* sys_printf("aiot_nwk_read, nwk select timeout\n"); */
            continue;
        } else if (res < 0) {
            sys_printf("aiot_nwk_read, errno: %d\n",errno);
            perror("aiot_nwk_read, nwk select failed: ");
            return -1;
        } else {
            if (FD_ISSET(nwk_handle->fd, &read_sets)) {
                recv_res = recv(nwk_handle->fd, buffer + read_bytes, len - read_bytes, 0);
                if (recv_res == 0) {
                    sys_printf("aiot_nwk_read, nwk connection closed\n");
                    return -1;
                } else if (recv_res < 0) {
                    sys_printf("aiot_nwk_read, errno: %d\n",errno);
                    perror("aiot_nwk_read, nwk recv error: ");
                    if (errno == EINTR) {
                        continue;
                    }
                    return -1;
                } else {
                    read_bytes += recv_res;
                    /* sys_printf("read_bytes: %d, len: %d\n",read_bytes,len); */
                    if (read_bytes == len) {
                        break;
                    }
                }
            }
        }
    } while (((timenow_ms - timestart_ms) < timeout_ms) && (read_bytes < len));

    /* sys_printf("%s: read over\n",__FUNCTION__); */
    return read_bytes;
}

#ifdef NWK_SECURITY_ENABLED
static int32_t _linux_nwk_security_read(void *handle, uint8_t *buffer, uint32_t len, uint32_t timeout_ms)
{
    int res = 0;
    int32_t read_bytes = 0;
    linux_nwk_handle_t *nwk_handle = (linux_nwk_handle_t *)handle;

    mbedtls_ssl_conf_read_timeout(&nwk_handle->security_ctx.ssl_config, timeout_ms);
    do {
       res = mbedtls_ssl_read(&nwk_handle->security_ctx.ssl_ctx, buffer + read_bytes, len - read_bytes);
       if (res < 0) {
           if (res == MBEDTLS_ERR_SSL_PEER_CLOSE_NOTIFY) {
               return -1;
           }else if (res == MBEDTLS_ERR_SSL_TIMEOUT) {
               break;
           }else if (res != MBEDTLS_ERR_SSL_WANT_READ ||
                    res != MBEDTLS_ERR_SSL_WANT_WRITE ||
                    res != MBEDTLS_ERR_SSL_CLIENT_RECONNECT) {
                break;
            }
        }else if (res == 0) {
            break;
        }else{
           read_bytes += res;
        }
    }while(read_bytes < len);

    return read_bytes;
}
#endif

static int32_t _linux_nwk_udp_read(void *handle, uint8_t *buffer, uint32_t len, uint32_t timeout_ms, aiot_sys_addr_t *addr)
{
    int ret;
    struct sockaddr_in cliaddr;
    socklen_t addr_len = sizeof(cliaddr);
    fd_set read_fds;
    struct timeval timeout = {timeout_ms / 1000, (timeout_ms % 1000) * 1000};
    linux_nwk_handle_t *nwk_handle = (linux_nwk_handle_t *)handle;

    FD_ZERO(&read_fds);
    FD_SET(nwk_handle->fd, &read_fds);

    ret = select(nwk_handle->fd + 1, &read_fds, NULL, NULL, &timeout);
    if (ret == 0) {
        return 0;       /* select timeout */
    }
    else if (ret < 0) {
        sys_printf("_linux_nwk_udp_read select errno: %d\n", errno);
        perror("_linux_nwk_udp_read select error: ");
        return -1;
    }

    ret = recvfrom(nwk_handle->fd, buffer, len, 0, (struct sockaddr *)&cliaddr, &addr_len);
    if (ret >= 0) {
        if (NULL != addr) {
            addr->port = ntohs(cliaddr.sin_port);
            strcpy((char *)addr->addr, inet_ntoa(cliaddr.sin_addr));
        }

        return ret;
    }else{
        sys_printf("_linux_nwk_udp_read errno: %d\n", errno);
        perror("_linux_nwk_udp_read error: ");
    }

    return -1;
}

int32_t aiot_nwk_read(void *handle, uint8_t *buffer, uint32_t len, uint32_t timeout_ms, aiot_sys_addr_t *addr)
{
    linux_nwk_handle_t *nwk_handle = (linux_nwk_handle_t *)handle;

    if (handle == NULL || buffer == NULL || len == 0 || timeout_ms == 0) {
        return -1;
    }

    if (nwk_handle->nwk_type == 0) {
        if (nwk_handle->security == 0) {
             return _linux_nwk_tcp_read(handle, buffer, len, timeout_ms);
        }else{
#ifdef NWK_SECURITY_ENABLED
            return _linux_nwk_security_read(handle, buffer, len, timeout_ms);
#else
            return -1;
#endif
        }
    } else if (nwk_handle->nwk_type == 3) {
        return _linux_nwk_udp_read(handle, buffer, len, timeout_ms, addr);;
    }

    sys_printf("unknown nwk type\n");

    return -1;
}

int32_t _linux_nwk_tcp_write(void *handle, uint8_t *buffer, uint32_t len, uint32_t timeout_ms)
{
    int res = 0;
    int32_t write_bytes = 0;
    ssize_t send_res = 0;
    uint64_t timestart_ms = 0, timenow_ms = 0, timeselect_ms = 0;
    linux_nwk_handle_t *nwk_handle = (linux_nwk_handle_t *)handle;
    fd_set write_sets;
    struct timeval timestart, timenow, timeselect;

    if (handle == NULL || buffer == NULL || len == 0 || timeout_ms == 0) {
        sys_printf("invalid parameter\n");
        return -1;
    }

    FD_ZERO(&write_sets);
    FD_SET(nwk_handle->fd, &write_sets);

    /* Start Time */
    gettimeofday(&timestart, NULL);
    timestart_ms = timestart.tv_sec * 1000 + timestart.tv_usec / 1000;
    timenow_ms = timestart_ms;

    do {
        gettimeofday(&timenow, NULL);
        timenow_ms = timenow.tv_sec * 1000 + timenow.tv_usec / 1000;

        if (timenow_ms - timestart_ms >= timenow_ms ||
            timeout_ms - (timenow_ms - timestart_ms) > timeout_ms) {
            break;
        }

        timeselect_ms = timeout_ms - (timenow_ms - timestart_ms);
        timeselect.tv_sec = timeselect_ms / 1000;
        timeselect.tv_usec = timeselect_ms % 1000 * 1000;

        res = select(nwk_handle->fd + 1, NULL, &write_sets, NULL, &timeselect);
        if (res == 0) {
            sys_printf("aiot_nwk_write, nwk select timeout\n");
            continue;
        } else if (res < 0) {
            sys_printf("aiot_nwk_write, errno: %d\n",errno);
            perror("aiot_nwk_write, nwk select failed: ");
            return -1;
        } else {
            if (FD_ISSET(nwk_handle->fd, &write_sets)) {
                send_res = send(nwk_handle->fd, buffer + write_bytes, len - write_bytes, 0);
                if (send_res == 0) {
                    sys_printf("aiot_nwk_write, nwk connection closed\n");
                    return -1;
                } else if (send_res < 0) {
                    sys_printf("aiot_nwk_write, errno: %d\n",errno);
                    perror("aiot_nwk_write, nwk recv error: ");
                    if (errno == EINTR) {
                        continue;
                    }
                    return -1;
                } else {
                    write_bytes += send_res;
                    if (write_bytes == len) {
                        break;
                    }
                }
            }
        }
    } while (((timenow_ms - timestart_ms) < timeout_ms) && (write_bytes < len));

    return write_bytes;
}

#ifdef NWK_SECURITY_ENABLED
int32_t _linux_nwk_security_write(void *handle, uint8_t *buffer, uint32_t len, uint32_t timeout_ms)
{
    int32_t res = 0;
    int32_t write_bytes = 0;
    uint64_t timestart_ms = 0, timenow_ms = 0;
    struct timeval timestart, timenow, timeout;
    linux_nwk_handle_t *nwk_handle = (linux_nwk_handle_t *)handle;

    /* timeout */
    timeout.tv_sec = timeout_ms/1000;
    timeout.tv_usec = (timeout_ms % 1000) * 1000;

    /* Start Time */
    gettimeofday(&timestart, NULL);
    timestart_ms = timestart.tv_sec * 1000 + timestart.tv_usec / 1000;
    timenow_ms = timestart_ms;

    res = setsockopt(nwk_handle->security_ctx.net_ctx.fd, SOL_SOCKET, SO_SNDTIMEO, &timeout, sizeof(timeout));
    if (res < 0) {
        return -1;
    }

    do {
        gettimeofday(&timenow, NULL);
        timenow_ms = timenow.tv_sec * 1000 + timenow.tv_usec / 1000;

        if (timenow_ms - timestart_ms >= timenow_ms ||
            timeout_ms - (timenow_ms - timestart_ms) > timeout_ms) {
            break;
        }

        res = mbedtls_ssl_write(&nwk_handle->security_ctx.ssl_ctx, buffer + write_bytes, len - write_bytes);
        if (res < 0) {
            if (res != MBEDTLS_ERR_SSL_WANT_READ &&
                res != MBEDTLS_ERR_SSL_WANT_WRITE) {
                if (write_bytes == 0) {
                    return -1;
                }
                break;
            }
        }else if (res == 0) {
            break;
        }else{
            write_bytes += res;
        }
    }while(((timenow_ms - timestart_ms) < timeout_ms) && (write_bytes < len));

    return write_bytes;
}
#endif

int32_t _linux_nwk_udp_write(void *handle, uint8_t *buffer, uint32_t len, uint32_t timeout_ms, aiot_sys_addr_t *addr)
{
    int ret;
    struct sockaddr_in cliaddr;
    fd_set write_fds;
    struct timeval timeout = {timeout_ms / 1000, (timeout_ms % 1000) * 1000};
    linux_nwk_handle_t *nwk_handle = (linux_nwk_handle_t *)handle;

    if (addr == NULL) {
        sys_printf("invalid parameter\n");
    }

    FD_ZERO(&write_fds);
    FD_SET(nwk_handle->fd, &write_fds);

    ret = select(nwk_handle->fd + 1, NULL, &write_fds, NULL, &timeout);
    if (ret == 0) {
        sys_printf("select timeout\n");
        return 0;    /* write timeout */
    }else if (ret < 0) {
        sys_printf("_linux_nwk_udp_write select errno: %d\n", errno);
        perror("_linux_nwk_udp_write select error: ");
        return -1;
    }

    ret = inet_aton((char *)addr->addr, &cliaddr.sin_addr);
    if (ret < 0) {
        sys_printf("aiot_nwk_write, addr error\r\n");
        return -1;
    }

    cliaddr.sin_family = AF_INET;
    cliaddr.sin_port = htons(addr->port);

    ret = sendto(nwk_handle->fd, buffer, len, 0, (struct sockaddr *)&cliaddr, sizeof(struct sockaddr_in));
    if (ret < 0) {
        sys_printf("_linux_nwk_udp_write errno: %d\n", errno);
        perror("_linux_nwk_udp_write error: ");
    }

    return (ret) > 0 ? ret : -1;
}

int32_t aiot_nwk_write(void *handle, uint8_t *buffer, uint32_t len, uint32_t timeout_ms, aiot_sys_addr_t *addr)
{
    linux_nwk_handle_t *nwk_handle = (linux_nwk_handle_t *)handle;

    if (handle == NULL || buffer == NULL || len == 0 || timeout_ms == 0) {
        sys_printf("invalid parameter\n");
        return -1;
    }

    if (nwk_handle->nwk_type == 0) {
        if (nwk_handle->security == 0) {
            return _linux_nwk_tcp_write(handle, buffer, len, timeout_ms);
        }else{
#ifdef NWK_SECURITY_ENABLED
            return _linux_nwk_security_write(handle, buffer, len, timeout_ms);
#else
            return -1;
#endif
        }
    } else if (nwk_handle->nwk_type == 3) {
        return _linux_nwk_udp_write(handle, buffer, len, timeout_ms, addr);
    }

    sys_printf("unknown nwk type\n");

    return -1;
}

static int32_t _linux_nwk_tcp_disconnect(void *handle)
{
    int32_t res = 0;
    linux_nwk_handle_t *nwk_handle = (linux_nwk_handle_t *)handle;

    res = shutdown(nwk_handle->fd, 2);
    if (res != 0) {
        sys_printf("shutdown error\n");
        return -1;
    }

    res = close(nwk_handle->fd);
    if (res != 0) {
        sys_printf("closesocket error\n");
        return -1;
    }

    return 0;
}

static int32_t _linux_nwk_udp_disconnect(void *handle)
{
    int32_t res = 0;
    linux_nwk_handle_t *nwk_handle = (linux_nwk_handle_t *)handle;

    res = close(nwk_handle->fd);
    if (res != 0) {
        sys_printf("closesocket error\n");
        return -1;
    }

    return 0;
}

#ifdef NWK_SECURITY_ENABLED
static int32_t _linux_nwk_security_disconnect(void *handle)
{
    linux_nwk_handle_t *nwk_handle = (linux_nwk_handle_t *)handle;

    mbedtls_ssl_close_notify(&nwk_handle->security_ctx.ssl_ctx);
    mbedtls_net_free(&nwk_handle->security_ctx.net_ctx);
    mbedtls_x509_crt_free(&nwk_handle->security_ctx.x509_crt);
    mbedtls_ssl_free(&nwk_handle->security_ctx.ssl_ctx);
    mbedtls_ssl_config_free(&nwk_handle->security_ctx.ssl_config);

    return 0;
}
#endif

int32_t aiot_nwk_deinit(void *handle)
{
    int res = 0;
    linux_nwk_handle_t *nwk_handle = (linux_nwk_handle_t *)handle;

    if (handle == NULL ) {
        return -1;
    }

    free(nwk_handle->host);

    /* Shutdown both send and receive operations. */
    if (nwk_handle->nwk_type == 0 && nwk_handle->host != NULL) {
        if (nwk_handle->security == 0) {
            res = _linux_nwk_tcp_disconnect(handle);
            if (res != 0) {
            return -1;
        }
    }else{
#ifdef NWK_SECURITY_ENABLED
            res = _linux_nwk_security_disconnect(handle);
            if (res != 0) {
                return -1;
            }
#else
            return -1;
#endif
        }
    }else{
        res = _linux_nwk_udp_disconnect(handle);
        if (res != 0) {
            return -1;
        }
    }

    free(handle);

    return 0;
}

uint64_t aiot_sys_time(void)
{
    struct timeval time;

    memset(&time, 0, sizeof(struct timeval));
    gettimeofday(&time, NULL);

    return (time.tv_sec * 1000 + time.tv_usec / 1000);
}

void aiot_sys_rand(uint8_t *output, uint32_t output_len)
{
	uint32_t idx = 0, bytes = 0, rand_num = 0;
	struct timeval time;

    memset(&time, 0, sizeof(struct timeval));
    gettimeofday(&time, NULL);

	srand((unsigned int)(time.tv_sec * 1000 + time.tv_usec / 1000) + rand());

	for (idx = 0;idx < output_len;) {
		if (output_len - idx < 4) {
			bytes = output_len - idx;
		}else{
			bytes = 4;
		}
		rand_num = rand();
		while(bytes-- > 0) {
			output[idx++] = (uint8_t)(rand_num >> bytes * 8);
		}
	}
}

void aiot_sys_printf(char *log)
{
    uint8_t color[] = {36,33,31};

    printf("\33[1;%d;40m%s\033[0m",color[1],log);
}

void *aiot_mutex_init(void)
{
    int res = 0;
    pthread_mutex_t *mutex = (pthread_mutex_t *)malloc(sizeof(pthread_mutex_t));
    if (NULL == mutex) {
        return NULL;
    }

    if (0 != (res = pthread_mutex_init(mutex, NULL))) {
        perror("create mutex failed\n");
        free(mutex);
        return NULL;
    }
    /* sys_printf("init mutex: %p\n",mutex); */

    return (void *)mutex;
}

void aiot_mutex_lock(void *mutex)
{
    int res = 0;
    if (mutex != NULL) {
        if (0 != (res = pthread_mutex_lock((pthread_mutex_t *)mutex))) {
            sys_printf("lock mutex failed: - '%s' (%d)\n", strerror(res), res);
        }
    }
}

void aiot_mutex_unlock(void *mutex)
{
    int res = 0;
    if (mutex != NULL) {
        if (0 != (res = pthread_mutex_unlock((pthread_mutex_t *)mutex))) {
            sys_printf("unlock mutex failed - '%s' (%d)\n", strerror(res), res);
        }
    }
}

void aiot_mutex_deinit(void *mutex)
{
    int err_num = 0;
    if (mutex != NULL) {
        /* sys_printf("deinit mutex: %p\n",mutex); */
        if (0 != (err_num = pthread_mutex_destroy((pthread_mutex_t *)mutex))) {
            perror("destroy mutex failed\n");
        }
        free(mutex);
    }
}

/* Memory Stat */
typedef struct _linux_memstat_block {
    void *ptr;
    uint32_t size;
    struct _linux_memstat_block *next;
} linux_memstat_block_t;

typedef struct _linux_memstat_node {
    char *name;
    uint64_t in_use;
    uint64_t max_in_use;
    uint32_t max_allocated;
    uint64_t total_allocated;
    struct _linux_memstat_block *block_head;
    struct _linux_memstat_node  *next;
} linux_memstat_node_t;

typedef struct {
    pthread_mutex_t mutex;
    struct _linux_memstat_node *node_head;
} linux_memstat_t;

linux_memstat_t *g_linux_memstat = NULL;

void linux_memstat_init(void)
{
    if (g_linux_memstat != NULL) {
        return;
    }

    g_linux_memstat = malloc(sizeof(linux_memstat_t));
    if (g_linux_memstat == NULL) {
        sys_printf("malloc failed\n");
        return;
    }
    memset(g_linux_memstat, 0, sizeof(linux_memstat_t));

    if (0 != pthread_mutex_init(&g_linux_memstat->mutex, NULL)) {
        perror("create mutex failed\n");
        free(g_linux_memstat);
        g_linux_memstat = NULL;
        return;
    }
}

void linux_memstat_deinit(void)
{
    linux_memstat_node_t *node = NULL, *node_next = NULL;
    linux_memstat_block_t *block = NULL, *block_next = NULL;
    if (g_linux_memstat == NULL) {
        return;
    }

    pthread_mutex_lock(&g_linux_memstat->mutex);
    for (node = g_linux_memstat->node_head;node != NULL;node = node_next){
        node_next = node->next;
        free(node->name);
        for (block = node->block_head;block != NULL;block = block_next) {
            block_next = block->next;
            free(block);
        }
        free(node);
    }
    pthread_mutex_unlock(&g_linux_memstat->mutex);

    if (0 != pthread_mutex_destroy(&g_linux_memstat->mutex)) {
        perror("destroy mutex failed\n");
    }

    free(g_linux_memstat);
    g_linux_memstat = NULL;
}

void linux_memstat_print(void)
{
    uint64_t max_in_use = 0, total_allocated = 0, total_free = 0;
    linux_memstat_node_t *node = NULL;

    if (g_linux_memstat == NULL) {
        return;
    }

    pthread_mutex_lock(&g_linux_memstat->mutex);
    sys_printf("\n");
    sys_printf("|               |      max_in_use       |  max_allocated   |    total_allocated    |      total_free\n");
    sys_printf("|---------------|-----------------------|------------------|-----------------------|----------------------\n");
    for (node = g_linux_memstat->node_head;node != NULL;node = node->next) {
        max_in_use += node->max_in_use;
        total_allocated += node->total_allocated;
        total_free += (node->total_allocated - node->in_use);
    }
    for (node = g_linux_memstat->node_head;node != NULL;node = node->next) {
        sys_printf("| %-13s | %6lld / %-5lld bytes  |    %6d bytes  | %6lld / %-5lld bytes  | %6lld / %-5lld bytes   \n",
                   node->name, (long long unsigned int)node->max_in_use, (long long unsigned int)max_in_use, node->max_allocated, (long long unsigned int)node->total_allocated,
                   (long long unsigned int)total_allocated, (long long unsigned int)(node->total_allocated - node->in_use), (long long unsigned int)total_free);
    }
    pthread_mutex_unlock(&g_linux_memstat->mutex);
}

static void _linux_memstat_block_insert(void *ptr, uint32_t size, linux_memstat_node_t *node)
{
    linux_memstat_block_t *block = NULL, *tail_block = NULL;

    block = malloc(sizeof(linux_memstat_block_t));
    if (block != NULL) {
        memset(block, 0, sizeof(linux_memstat_block_t));
        block->ptr = ptr;
        block->size = size;
        if (node->block_head == NULL) {
            node->block_head = block;
        }else{
            for (tail_block = node->block_head;tail_block->next != NULL;tail_block = tail_block->next) {
                ;
            }
            tail_block->next = block;
        }

        node->in_use += size;
        if (node->in_use > node->max_in_use) {
            node->max_in_use = node->in_use;
        }
        if (size > node->max_allocated) {
            node->max_allocated = size;
        }
        node->total_allocated += size;
    } else {
        sys_printf("malloc failed\n")
    }
}

void *aiot_sys_malloc(uint32_t size, char *name)
{
    uint8_t flag = 0;
    void *allocated = malloc(size);
    char *module_name = NULL;
    linux_memstat_node_t *node = NULL, *tail_node = NULL;

    /* Memory Stat */
    if (allocated != NULL && g_linux_memstat != NULL) {
        module_name = (name == NULL) ? ("unknown") : (name);
        pthread_mutex_lock(&g_linux_memstat->mutex);
        for (node = g_linux_memstat->node_head;node != NULL;node = node->next) {
            if (strlen(node->name) == strlen(module_name) && memcmp(node->name, module_name, strlen(module_name)) == 0) {
                flag = 1;
                _linux_memstat_block_insert(allocated, size, node);
            }
        }
        if (flag == 0) {
            node = malloc(sizeof(linux_memstat_node_t));
            if (node != NULL) {
                memset(node, 0, sizeof(linux_memstat_node_t));
                node->name = malloc(strlen(module_name) + 1);
                if (node->name != NULL) {
                    memset(node->name, 0, strlen(module_name) + 1);
                    memcpy(node->name, module_name, strlen(module_name));
                    if (g_linux_memstat->node_head == NULL) {
                        g_linux_memstat->node_head = node;
                    }else{
                        for (tail_node = g_linux_memstat->node_head;tail_node->next != NULL;tail_node = tail_node->next) {
                            ;
                        }
                        tail_node->next = node;
                    }
                    _linux_memstat_block_insert(allocated, size, node);
                } else {
                    sys_printf("malloc failed\n")
                    free(node);
                }
            } else {
                sys_printf("malloc failed\n")
            }
        }
        pthread_mutex_unlock(&g_linux_memstat->mutex);
    }

    return allocated;
}

void aiot_sys_free(void *ptr)
{
    uint8_t flag = 0;
    uint32_t size = 0;
    linux_memstat_node_t *node = NULL;
    linux_memstat_block_t *block = NULL, *block_prev = NULL, *block_next = NULL;

    if (g_linux_memstat != NULL) {
        pthread_mutex_lock(&g_linux_memstat->mutex);
        for (node = g_linux_memstat->node_head;node != NULL;node = node->next) {
            for (block = node->block_head;block != NULL;block = block_next) {
                block_next = block->next;
                if (block->ptr == ptr) {
                    flag = 1;
                    size = block->size;
                    if (block_prev == NULL) {
                        node->block_head = block->next;
                    }else{
                        block_prev->next = block->next;
                    }
                    free(block);
                    break;
                }else{
                    block_prev = block;
                }
            }
            if (flag == 1) {
                node->in_use -= size;
                break;
            }
        }
        pthread_mutex_unlock(&g_linux_memstat->mutex);
    }
    free(ptr);
}
