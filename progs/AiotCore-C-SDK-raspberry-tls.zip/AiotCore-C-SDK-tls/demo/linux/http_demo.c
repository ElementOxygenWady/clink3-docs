#include <stdio.h>
#include <string.h>
#include "aiot_errno.h"
#include "aiot_log_api.h"
#include "aiot_http_api.h"
#include "linux_sys.h"

int main(int argc, char *argv[])
{
    int32_t res = 0;
    void *http_handle = NULL;
    char *method = "GET";
    char *host = "http://linkkit-export.oss-cn-shanghai.aliyuncs.com/zhengcheng/test_file";
    char *header = "Content-Type: application/x-www-form-urlencoded\r\n";
    uint16_t port = 80;
    uint8_t output[128] = {0};
    uint32_t recv_bytes = 0;
    uint32_t body_offset = 0;

    /* linux memstat */
    linux_memstat_init();

    /* set log level */
    aiot_log_set_level(AIOT_LOG_INFO);

    /* init http handle */
    http_handle = aiot_http_init();
    if (http_handle == NULL) {
        printf("aiot_http_init failed\n");
        return -1;
    }

    aiot_http_setopt(http_handle, HTTPOPT_URL, host);
    aiot_http_setopt(http_handle, HTTPOPT_PORT, &port);
    aiot_http_setopt(http_handle, HTTPOPT_METHOD, method);
    aiot_http_setopt(http_handle, HTTPOPT_HEADER, header);
    aiot_http_setopt(http_handle, HTTPOPT_BODY_OFFSET, (void *)&body_offset);

    /* send to http server */
    res = aiot_http_send(http_handle, NULL, 0);
    if (http_handle == NULL) {
        printf("aiot_http_connect failed\n");
        return -1;
    }

    while (1)
    {
        memset(output, 0, 128);
        res = aiot_http_recv(http_handle, output, 128);
        // printf("%s\n", output);
        
        if (res < 0) {
            printf("error occurs, res : -0x%04X\n",-res);
            break;
        }

        recv_bytes += res;
        if (res < 128) {
            break;
        }
    }
    printf("recv bytes: %d\n",recv_bytes);

    aiot_http_deinit(&http_handle);

    linux_memstat_print();
    linux_memstat_deinit();

    return 0;
}