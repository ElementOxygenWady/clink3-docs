#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <linux/if.h>
#include <linux/if_packet.h>
#include <linux/if_ether.h>
#include <net/ethernet.h>
#include <netinet/in.h>
#include <ifaddrs.h>
#include <netdb.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include "linux_sys.h"
#include "aiot_errno.h"
#include "aiot_log_api.h"
#include "aiot_sys_callback.h"
#include "aiot_coap_api.h"
#include "aiot_mqtt_api.h"
#include "aiot_bind_api.h"
#include "utils_string.h"

const char url[] = "iot-as-mqtt.cn-shanghai.aliyuncs.com";
const uint16_t port = 1883;
const char *g_ifname = "wlx00259ce04ceb";

const char product_key[]       = "a1X2bEnP82z";
const char product_secret[]    = "7jluWm1zql7bt8qK";
const char device_name[]       = "bind_test";
const char device_secret[]     = "aMkSWA8saaawbJd0P0xB7OVnGoihVLYi";
char local_ip[16]        = {0};
char broadcast_ip[16]    = {0};
static uint8_t g_mqtt_running = 0;
static uint8_t g_coap_running = 0;
static uint8_t g_bind_running = 0;
static pthread_t g_mqtt_thread;
static pthread_t g_coap_thread;
static pthread_t g_bind_thread;


void linux_get_network_info(char ip_addr[16], char broadcast_ip_addr[16])
{
    struct ifaddrs *ifap, *ifa;
    struct sockaddr_in *ip, *broadcast_ip;
    char *addr = NULL;

    getifaddrs (&ifap);
    for (ifa = ifap; ifa; ifa = ifa->ifa_next) {
        if (ifa->ifa_addr->sa_family==AF_INET && (strlen(ifa->ifa_name) == strlen(g_ifname)) &&
            (memcmp(ifa->ifa_name, g_ifname, strlen(g_ifname)) == 0)) {

            /* local ip address */
            ip = (struct sockaddr_in *) ifa->ifa_addr;
            addr = inet_ntoa(ip->sin_addr);
            memcpy(ip_addr, addr, strlen(addr));

            /* local broadcast ip address */
            broadcast_ip = (struct sockaddr_in *) ifa->ifa_ifu.ifu_broadaddr;
            addr = inet_ntoa(broadcast_ip->sin_addr);
            memcpy(broadcast_ip_addr, addr, strlen(addr));

            printf("Interface: %s\tAddress: %s\tBroadcast Address: %s\n", ifa->ifa_name, ip_addr, broadcast_ip_addr);
        }
    }

    freeifaddrs(ifap);
}

void demo_ctrlpkt_handle(void *handle, aiot_mqtt_ctrlpkt_t *packet, void *userdata)
{
    switch (packet->ctrltype) {
        case MQTTCTRL_HEARTBEAT_RESPONSE: {
            printf("heartbeat received\n");
        }
        break;
        case MQTTCTRL_SUB_RESPONSE: {
            printf("sub res: %d, max_qos: %d, packet id: %d\n",
                   packet->data.sub_resp_data.res,
                   packet->data.sub_resp_data.max_qos,
                   packet->data.sub_resp_data.packet_id);
        }
        break;
        case MQTTCTRL_UNSUB_RESPONSE: {

        }
        break;
        case MQTTCTRL_PUB_RESPONSE: {

        }
        break;
    }
}

void demo_datapkt_handle(void *handle, aiot_mqtt_datapkt_t *packet, void *userdata)
{
    printf("data packet received:\n");
    printf("topic  : %.*s\n", packet->topic_len, packet->topic);
    printf("payload: %.*s\n", packet->payload_len, packet->payload);
}

void aiot_bind_event_handler(void *handle, aiot_bind_event_data_t *event)
{
    switch (event->type) {
        case BIND_EVENT_POST_CLOUD_SUCCEED: {
            printf("POST_CLOUD_SUCCEED event:\r\n");
            printf("token = %s, ttl = %d\r\n", event->data.post_cloud.token, event->data.post_cloud.ttl);
        } break;
        case BIND_EVENT_TOKEN_REQ_RECVED: {
            printf("TOKEN_REQ_RECVED event, remote = %s:\r\n", event->data.token_req.remote_ip);
            printf("req data = %.*s\r\n", event->data.token_req.req_data_len, event->data.token_req.req_data);
        } break;
        case BIND_EVENT_TOKEN_RSP_SENDED: {
            printf("TOKEN_RSP_SENDED event, remote = %s\r\n", event->data.token_rsp.remote_ip);
            printf("rsp data = %.*s\r\n", event->data.token_rsp.rsp_data_len, event->data.token_rsp.rsp_data);
        } break;
        default: break;
    }
}

void *demo_mqtt_thread(void *param)
{
    int32_t res;

    while (g_mqtt_running) {
        /* handle heartbeat send and qos1 message re-publish */
        aiot_mqtt_process(param);

        /* recv packet from network */
        res = aiot_mqtt_recv(param);
        if (res < 0) {
            /**
             * if network closed, aiot_mqtt_recv will be returned immediately if
             * it is not try to reconnect this time.
             */
            if (res == ERRCODE_SYS_NWK_CLOSED) {
                sleep(1);
            }
        }
    }

    return NULL;
}

void *demo_coap_thread(void *param)
{
    int32_t res;

    while (g_coap_running) {
        res = aiot_coap_recv(param);
        if (res < 0) {

            if (res == ERRCODE_SYS_NWK_CLOSED) {
                sleep(1);
            }
        }
        usleep(100 * 1000);
    }

    return NULL;
}

void *demo_bind_thread(void *param)
{
    while (g_bind_running) {
        aiot_bind_process(param);
        usleep(100 *1000);
    }

    return NULL;
}

void *mqtt_start(void)
{
    void *mqtt_handle = NULL;
    char host[100] = {0};
    const char *host_fmt = "%s.%s";
    int32_t res;

    mqtt_handle = aiot_mqtt_init();
    if (mqtt_handle == NULL) {
        printf("aiot_mqtt_init failed\r\n");
        return NULL;
    }

    snprintf(host, 100, host_fmt, product_key, url);
    aiot_mqtt_setopt(mqtt_handle, MQTTOPT_HOST, (void *)host);
    aiot_mqtt_setopt(mqtt_handle, MQTTOPT_PORT, (void *)&port);
    aiot_mqtt_setopt(mqtt_handle, MQTTOPT_PRODUCT_KEY, (void *)product_key);
    aiot_mqtt_setopt(mqtt_handle, MQTTOPT_DEVICE_NAME, (void *)device_name);
    aiot_mqtt_setopt(mqtt_handle, MQTTOPT_DEVICE_SECRET, (void *)device_secret);
    aiot_mqtt_setopt(mqtt_handle, MQTTOPT_CTRLPKT_HANDLE, (void *)demo_ctrlpkt_handle);
    aiot_mqtt_setopt(mqtt_handle, MQTTOPT_DATAPKT_HANDLE, (void *)demo_datapkt_handle);

    res = aiot_mqtt_connect(mqtt_handle);
    if (res < 0) {
        printf("aiot_mqtt_connect failed, res = %d\n", res);
        return NULL;
    }

    /* create thread for mqtt receiving */
    g_mqtt_running = 1;
    res = pthread_create(&g_mqtt_thread, NULL, demo_mqtt_thread, mqtt_handle);
    if (res < 0) {
        printf("pthread_create failed\n");
        aiot_mqtt_deinit(&mqtt_handle);
        return NULL;
    }

    return mqtt_handle;
}

void *coap_start(void)
{
    void *coap_handle = NULL;
    int32_t res;

    coap_handle = aiot_coap_init();
    if (coap_handle == NULL) {
        printf("aiot_coap_init fail\r\n");
        return NULL;
    }

    res = aiot_coap_connect(coap_handle);
    if (res < 0) {
        return NULL;
    }

    g_coap_running = 1;
    res = pthread_create(&g_coap_thread, NULL, demo_coap_thread, coap_handle);
    if (res < 0) {
        printf("pthread_create failed\n");
        aiot_mqtt_deinit(&coap_handle);
        return NULL;
    }

    return coap_handle;
}

void *bind_start(void *mqtt_handle, void *coap_handle)
{
    void *bind_handle;
    int32_t res;

    bind_handle = aiot_bind_init();
    if (bind_handle == NULL) {
        return NULL;
    }
    aiot_bind_setopt(bind_handle, BINDOPT_MQTT_HANDLE, mqtt_handle);
    aiot_bind_setopt(bind_handle, BINDOPT_COAP_HANDLE, coap_handle);
    aiot_bind_setopt(bind_handle, BINDOPT_PRODUCT_KEY, (void *)product_key);
    aiot_bind_setopt(bind_handle, BINDOPT_DEVICE_NAME, (void *)device_name);
    aiot_bind_setopt(bind_handle, BINDOPT_MAC_ADDR, (void *)"\x8c\x16\x45\x66\x47\x55");
    aiot_bind_setopt(bind_handle, BINDOPT_IP_ADDR, (void *)local_ip);
    aiot_bind_setopt(bind_handle, BINDOPT_BROADCAST_ADDR, (void *)broadcast_ip);
    aiot_bind_setopt(bind_handle, BINDOPT_EVENT_CB, (void *)aiot_bind_event_handler);

    g_bind_running = 1;
    res = pthread_create(&g_bind_thread, NULL, demo_bind_thread, bind_handle);
    if (res < 0) {
        printf("pthread_create failed\n");
        aiot_mqtt_deinit(&mqtt_handle);
        aiot_coap_deinit(&coap_handle);
        return NULL;
    }

    return bind_handle;
}

int main(int argc, char *argv[])
{
    void *mqtt_handle = NULL;
    void *coap_handle = NULL;
    void *bind_handle = NULL;

    /* linux memstat */
    linux_memstat_init();

    /* set log level */
    aiot_log_set_level(AIOT_LOG_DEBUG);

    /* get local ip and broadcast ip */
    linux_get_network_info(local_ip, broadcast_ip);

    /* mqtt init */
    mqtt_handle = mqtt_start();
    if (mqtt_handle == NULL) {
        return -1;
    }
    /* coap init */
    coap_handle = coap_start();
    if (mqtt_handle == NULL) {
        aiot_mqtt_deinit(&mqtt_handle);
        return -1;
    }
    /* bind init */
    bind_handle = bind_start(mqtt_handle, coap_handle);
    if (bind_handle == NULL) {
        aiot_mqtt_deinit(&mqtt_handle);
        aiot_coap_deinit(&coap_handle);
        return -1;
    }

    while (1) {
        sleep(1);
    }

    g_mqtt_running = 0;
    pthread_join(g_mqtt_thread, NULL);
    g_coap_running = 0;
    pthread_join(g_coap_thread, NULL);
    g_bind_running = 0;
    pthread_join(g_bind_thread, NULL);

    aiot_mqtt_deinit(&mqtt_handle);
    aiot_coap_deinit(&coap_handle);
    aiot_bind_deinit(&bind_handle);
    linux_memstat_print();
    linux_memstat_deinit();

    return 0;
}



