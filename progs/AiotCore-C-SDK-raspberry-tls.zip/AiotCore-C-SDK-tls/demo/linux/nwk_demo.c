#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include "linux_sys.h"
#include "aiot_errno.h"
#include "aiot_log_api.h"
#include "aiot_sys_callback.h"
#include "aiot_mqtt_api.h"

char *product_key       = "a1X2bEnP82z";
char *product_secret    = "7jluWm1zql7bt8qK";
char *device_name       = "example_core";
char *device_secret     = "VhQTSW48QngI1lG6ytYsbcNjqxMH4HpC";
static uint8_t g_process_running = 0;
static pthread_t g_process_thread;

void demo_ctrlpkt_handle(void *handle, aiot_mqtt_ctrlpkt_t *packet, void *userdata)
{
    switch (packet->ctrltype) {
        case MQTTCTRL_HEARTBEAT_RESPONSE: {
            printf("heartbeat received\n");
        }
        break;
        case MQTTCTRL_SUB_RESPONSE: {

        }
        break;
        case MQTTCTRL_UNSUB_RESPONSE: {

        }
        break;
        case MQTTCTRL_PUB_RESPONSE: {

        }
        break;
    }
}

void demo_datapkt_handle(void *handle, aiot_mqtt_datapkt_t *packet, void *userdata)
{
    printf("data packet received:\n");
    printf("topic  : %.*s\n", packet->topic_len, packet->topic);
    printf("payload: %.*s\n", packet->payload_len, packet->payload);
}

void *demo_process_thread(void *param)
{
    while (g_process_running) {
        sleep(1);

        /* handle heartbeat send and qos1 message re-publish */
        aiot_mqtt_process(param);
    }

    return NULL;
}

int main(int argc, char *argv[])
{
    int32_t res = 0;
    void *mqtt_handle = NULL;
    char *url = "iot-as-mqtt.cn-shanghai.aliyuncs.com";
    char host[100] = {0};
    uint16_t port = 1883;
    const char *host_fmt = "%s.%s";

    /* linux memstat */
    linux_memstat_init();

    /* set log level */
    aiot_log_set_level(AIOT_LOG_INFO);

    /* get mqtt handle */
    mqtt_handle = aiot_mqtt_init();
    if (mqtt_handle == NULL) {
        printf("aiot_mqtt_init failed\n");
        return -1;
    }

    snprintf(host, 100, host_fmt, product_key, url);
    aiot_mqtt_setopt(mqtt_handle, MQTTOPT_HOST, (void *)host);
    aiot_mqtt_setopt(mqtt_handle, MQTTOPT_PORT, (void *)&port);
    aiot_mqtt_setopt(mqtt_handle, MQTTOPT_PRODUCT_KEY, (void *)product_key);
    aiot_mqtt_setopt(mqtt_handle, MQTTOPT_DEVICE_NAME, (void *)device_name);
    aiot_mqtt_setopt(mqtt_handle, MQTTOPT_DEVICE_SECRET, (void *)device_secret);
    aiot_mqtt_setopt(mqtt_handle, MQTTOPT_CTRLPKT_HANDLE, (void *)demo_ctrlpkt_handle);
    aiot_mqtt_setopt(mqtt_handle, MQTTOPT_DATAPKT_HANDLE, (void *)demo_datapkt_handle);

    res = aiot_mqtt_connect(mqtt_handle);
    if (res < 0) {
        printf("aiot_mqtt_connect failed, res = %d\n", res);
        return -1;
    }

    /* create thread for sending heartbeat */
    g_process_running = 1;
    res = pthread_create(&g_process_thread, NULL, demo_process_thread, mqtt_handle);
    if (res < 0) {
        printf("pthread_create failed\n");
        aiot_mqtt_deinit(&mqtt_handle);
        return -1;
    }

    while (1) {
        /* recv packet from network */
        res = aiot_mqtt_recv(mqtt_handle);
        if (res < 0) {
            /**
             * if network closed, aiot_mqtt_recv will be returned immediately if
             * it is not try to reconnect this time.
             */
            if (res == ERRCODE_SYS_NWK_CLOSED) {
                sleep(1);
            }
        }
    }

    g_process_running = 0;
    pthread_join(g_process_thread, NULL);

    aiot_mqtt_deinit(&mqtt_handle);
    linux_memstat_print();
    linux_memstat_deinit();

    return 0;
}