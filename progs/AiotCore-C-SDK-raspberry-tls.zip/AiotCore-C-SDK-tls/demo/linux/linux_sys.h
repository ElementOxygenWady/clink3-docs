#ifndef _LINUX_SYS_H_
#define _LINUX_SYS_H_

#if defined(__cplusplus)
extern "C" {
#endif

#include <stdint.h>
#include "aiot_sys_callback.h"

/* Memory Stat */
void linux_memstat_init(void);
void linux_memstat_deinit(void);
void linux_memstat_print(void);

#if defined(__cplusplus)
}
#endif
#endif