#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <linux/if.h>
#include <linux/if_packet.h>
#include <linux/if_ether.h>
#include <net/ethernet.h>
#include <netinet/in.h>
#include <netdb.h>
#include <pthread.h>
#include <ifaddrs.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include "aiot_errno.h"
#include "aiot_log_api.h"
#include "aiot_wifi_api.h"
#include "linux_sys.h"

#include "aiot_coap_api.h"
#include "aiot_mqtt_api.h"
#include "aiot_bind_api.h"
#include "utils_string.h"

static char *g_ifname = "wlx00259ce04ceb";


const char url[] = "iot-as-mqtt.cn-shanghai.aliyuncs.com";
const uint16_t port = 1883;

const char product_key[]       = "a1X2bEnP82z";
const char product_secret[]    = "7jluWm1zql7bt8qK";
const char device_name[]       = "bind_test";
const char device_secret[]     = "aMkSWA8saaawbJd0P0xB7OVnGoihVLYi";
char local_ip[16]        = {0};
char broadcast_ip[16]    = {0};

static uint8_t g_mqtt_running = 0;
static uint8_t g_coap_running = 0;
static uint8_t g_bind_running = 0;
static pthread_t g_mqtt_thread;
static pthread_t g_coap_thread;
static pthread_t g_bind_thread;


typedef struct {
    void *handle;
    wifi_frame_recv_t frame_recv;
} linux_sniffer_thread_args_t;

static uint8_t sniffer_mode_flag = 0;


void linux_get_network_info(char ip_addr[16], char broadcast_ip_addr[16])
{
    struct ifaddrs *ifap, *ifa;
    struct sockaddr_in *ip, *broadcast_ip;
    char *addr = NULL;

    getifaddrs (&ifap);
    for (ifa = ifap; ifa; ifa = ifa->ifa_next) {
        if (ifa->ifa_addr->sa_family==AF_INET && (strlen(ifa->ifa_name) == strlen(g_ifname)) &&
            (memcmp(ifa->ifa_name, g_ifname, strlen(g_ifname)) == 0)) {

            /* local ip address */
            ip = (struct sockaddr_in *) ifa->ifa_addr;
            addr = inet_ntoa(ip->sin_addr);
            memcpy(ip_addr, addr, strlen(addr));

            /* local broadcast ip address */
            broadcast_ip = (struct sockaddr_in *) ifa->ifa_ifu.ifu_broadaddr;
            addr = inet_ntoa(broadcast_ip->sin_addr);
            memcpy(broadcast_ip_addr, addr, strlen(addr));

            printf("Interface: %s\tAddress: %s\tBroadcast Address: %s\n", ifa->ifa_name, ip_addr, broadcast_ip_addr);
        }
    }

    freeifaddrs(ifap);
}

int32_t linux_raw_socket_init(void)
{
    int32_t raw_socket = 0;
    struct ifreq ifr;
    struct sockaddr_ll sll;
    char buffer[256] = {0};

    memset(&ifr, 0, sizeof(struct ifreq));
    memset(&sll, 0, sizeof(struct sockaddr_ll));

    memset(buffer, 0, 256);
    snprintf(buffer, 256, "ifconfig %s down", g_ifname);
    system(buffer);

    memset(buffer, 0, 256);
    snprintf(buffer, 256, "iwconfig %s mode monitor", g_ifname);
    system(buffer);

    memset(buffer, 0, 256);
    snprintf(buffer, 256, "ifconfig %s up", g_ifname);
    system(buffer);

    raw_socket = socket(AF_PACKET, SOCK_RAW, htons(ETH_P_ALL));
    if (raw_socket < 0) {
        perror("raw socket error: ");
        return -1;
    }

    memcpy(ifr.ifr_name, g_ifname, strlen(g_ifname));
    if (ioctl(raw_socket, SIOCGIFINDEX, &ifr) < 0) {
        perror("SIOCGIFINDED error: ");
        return -1;
    }

    sll.sll_family = AF_PACKET;
    sll.sll_ifindex = ifr.ifr_ifindex;
    sll.sll_protocol = htons(ETH_P_ALL);
    if (bind(raw_socket, (struct sockaddr *)&sll, sizeof(sll)) < 0) {
        perror("bind error: ");
        return -1;
    }

    if (ioctl(raw_socket, SIOCGIFFLAGS, &ifr) < 0) {
        perror("SIOCGIFFLAGS error: ");
        return -1;
    }
    ifr.ifr_flags |= IFF_PROMISC;
    if (ioctl(raw_socket, SIOCSIFFLAGS, &ifr) < 0) {
        perror("SIOCSIFFLAGS error: ");
        return -1;
    }

    return raw_socket;
}

int32_t linux_raw_socket_read(int32_t socket, uint8_t *buffer, uint32_t buffer_len)
{
    int32_t recv_bytes = 0;

    if (socket < 0 || buffer == NULL || buffer_len == 0) {
        printf("invalid socket: %d\n", socket);
        return -1;
    }

    recv_bytes = recvfrom(socket, buffer, buffer_len, 0, NULL, NULL);
    if (recv_bytes < 0) {
        perror("raw socket recv error: ");
        return recv_bytes;
    }

    return recv_bytes;
}

int32_t linux_raw_socket_deinit(int32_t socket)
{
    char buffer[256] = {0};

    memset(buffer, 0, 256);
    snprintf(buffer, 256, "ifconfig %s down", g_ifname);
    system(buffer);

    memset(buffer, 0, 256);
    snprintf(buffer, 256, "iwconfig %s mode managed", g_ifname);
    system(buffer);

    memset(buffer, 0, 256);
    snprintf(buffer, 256, "ifconfig %s up", g_ifname);
    system(buffer);

    return 0;
}

void *linux_sniffer_mode(void *args)
{
    int32_t socket = 0, recv_bytes = 0;
    uint8_t *buffer = NULL;
    const uint32_t buffer_len = 3000;
    linux_sniffer_thread_args_t *thread_args = NULL;
    aiot_wifi_mac_frame_t mac_frame;

    if (args == NULL) {
        printf("invalid args\n");
        return NULL;
    }
    thread_args = (linux_sniffer_thread_args_t *)args;
    memset(&mac_frame, 0, sizeof(aiot_wifi_mac_frame_t));

    buffer = malloc(buffer_len);
    if (buffer == NULL) {
        printf("sniffer buffer malloc failed\n");
        return NULL;
    }

    /* raw socket open */
    socket = linux_raw_socket_init();
    if (socket < 0) {
        free(buffer);
        return NULL;
    }

    while (sniffer_mode_flag) {
        memset(buffer, 0, buffer_len);

        /* read OSI Layer 2 packet*/
        recv_bytes = linux_raw_socket_read(socket, buffer, buffer_len);
        if (recv_bytes < 0) {
            continue;
        }

        /*         {
                    uint32_t idx = 0;
                    printf("recv_bytes: %d\n",buffer_len);
                    printf("--------------------------------------------------\n");
                    for (idx = 0;idx < 180;idx++) {
                        if (idx % 16 == 0) {
                            printf("\n");
                        }
                        printf("%02X ",buffer[idx]);
                    }
                    printf("\n");
                    printf("--------------------------------------------------\n");
                } */

        mac_frame.buffer = buffer;
        mac_frame.buffer_len = recv_bytes;

        thread_args->frame_recv(thread_args->handle, &mac_frame);
    }

    linux_raw_socket_deinit(socket);

    free(buffer);
    free(args);

    return NULL;
}

int32_t linux_ap_mode(void)
{
    char buffer[256] = {0};
    char *ap_ssid = "linkkit-ap";
    char *ap_passwd = "";

    /**
     * using linux16.04 network manager to create wireless access point
     * reference:
     * https://developer.gnome.org/NetworkManager/stable/nmcli.html
     * https://unix.stackexchange.com/questions/234552/create-wireless-access-point-and-share-internet-connection-with-nmcli
     */
    memset(buffer, 0, 256);
    snprintf(buffer, 256, "ifconfig %s down", g_ifname);
    system(buffer);

    memset(buffer, 0, 256);
    snprintf(buffer, 256, "nmcli connection down %s", ap_ssid);
    system(buffer);

    memset(buffer, 0, 256);
    snprintf(buffer, 256, "nmcli connection delete %s", ap_ssid);
    system(buffer);

    memset(buffer, 0, 256);
    snprintf(buffer, 256, "nmcli connection add con-name %s type wifi ifname %s autoconnect yes ssid %s mode ap", ap_ssid,
             g_ifname, ap_ssid);
    system(buffer);

    if (strlen(ap_passwd) == 0) {
        memset(buffer, 0, 256);
        snprintf(buffer, 256, "nmcli connection modify %s 802-11-wireless.mode ap ipv4.method shared", ap_ssid);
        system(buffer);
    } else {
        memset(buffer, 0, 256);
        snprintf(buffer, 256,
                 "nmcli connection modify %s 802-11-wireless.mode ap 802-11-wireless-security.key-mgmt wpa-psk ipv4.method shared 802-11-wireless-security.psk %s",
                 ap_ssid, ap_passwd);
        system(buffer);
    }

    memset(buffer, 0, 256);
    snprintf(buffer, 256, "nmcli connection up %s", ap_ssid);
    system(buffer);

    return 0;
}

int32_t linux_switch_mode(void *handle, aiot_wifi_wlan_mode_t mode, void *data)
{
    int32_t res = 0;
    static pthread_t sniffer_mode_thread;

    switch (mode) {
        case WIFI_MODE_SNIFFER: {
            printf("switch to WIFI_MODE_SNIFFER\n");
            if (sniffer_mode_flag == 0 && sniffer_mode_thread == 0) {
                linux_sniffer_thread_args_t *thread_args = NULL;
                sniffer_mode_flag = 1;

                thread_args = malloc(sizeof(linux_sniffer_thread_args_t));
                if (thread_args == NULL) {
                    return -1;
                }
                memset(thread_args, 0, sizeof(linux_sniffer_thread_args_t));

                thread_args->handle = handle;
                thread_args->frame_recv = (wifi_frame_recv_t)data;

                res = pthread_create(&sniffer_mode_thread, NULL, linux_sniffer_mode, thread_args);
                if (res < 0) {
                    printf("create sniffer mode thread failed\n");
                    return res;
                }
            }
        }
        break;
        case WIFI_MODE_STA: {
            printf("switch to WIFI_MODE_STA\n");
            if (sniffer_mode_flag == 1) {
                sniffer_mode_flag = 0;
                pthread_join(sniffer_mode_thread, NULL);
                sniffer_mode_thread = 0;
            }
        }
        break;
        case WIFI_MODE_AP: {
            printf("switch to WIFI_MODE_AP\n");
            if (sniffer_mode_flag == 1) {
                sniffer_mode_flag = 0;
                pthread_join(sniffer_mode_thread, NULL);
                sniffer_mode_thread = 0;
            }
            linux_ap_mode();
        }
        break;
        default: {
            printf("unknown mode\n");
        }
        break;
    }

    return 0;
}

int32_t linux_switch_channel(void *handle, uint8_t channel)
{
    char buffer[256] = {0};

    memset(buffer, 0, 256);
    snprintf(buffer, 256, "iwconfig %s channel %d", g_ifname, channel);
    system(buffer);
    printf("switch channel: %d\n", channel);

    return 0;
}

int32_t linux_frame_send(void *handle, aiot_wifi_mac_frame_t *mac_frame)
{
    return 0;
}

int32_t linux_connect_ap(void *handle, aiot_wifi_apinfo_t *apinfo)
{
    char buffer[128] = {0};
    char *wifi_name = "linkkit";

    printf("ssid  : %s\n", apinfo->ssid);
    printf("passwd: %s\n", apinfo->passwd);

    /**
     * using linux16.04 network manager to connect ap
     * reference:
     * https://developer.gnome.org/NetworkManager/stable/nmcli.html
     * https://www.96boards.org/documentation/consumer/guides/wifi_commandline.md.html
     */
    memset(buffer, 0, 128);
    snprintf(buffer, 128, "nmcli connection down %s", wifi_name);
    system(buffer);

    memset(buffer, 0, 128);
    snprintf(buffer, 128, "nmcli connection delete %s", wifi_name);
    system(buffer);

    memset(buffer, 0, 128);
    snprintf(buffer, 128, "nmcli connection add con-name %s ifname %s type wifi ssid %s", wifi_name, g_ifname,
             apinfo->ssid);
    system(buffer);

    /**
     * security reference:
     * https://developer.gnome.org/NetworkManager/stable/settings-802-11-wireless-security.html
     */
    if (strlen((char *)apinfo->passwd) == 0) {
        memset(buffer, 0, 128);
        snprintf(buffer, 128, "nmcli connection modify %s wifi-sec.key-mgmt %s", "none", wifi_name);
        system(buffer);
    } else {
        memset(buffer, 0, 128);
        snprintf(buffer, 128, "nmcli connection modify %s wifi-sec.key-mgmt %s", wifi_name, "wpa-psk");
        system(buffer);

        memset(buffer, 0, 128);
        snprintf(buffer, 128, "nmcli connection modify %s wifi-sec.psk %s", wifi_name, apinfo->passwd);
        system(buffer);
    }


    memset(buffer, 0, 128);
    snprintf(buffer, 128, "nmcli connection up %s", wifi_name);
    system(buffer);

    return 0;
}

int32_t linux_wifi_event_handle(void *handle, aiot_wifi_event_t *event)
{
    switch (event->type) {
        case WIFI_EVENT_APINFO: {
            aiot_wifi_apinfo_t apinfo;
            memset(&apinfo, 0, sizeof(aiot_wifi_apinfo_t));

            memcpy(apinfo.ssid, event->data.apinfo.ssid, strlen(event->data.apinfo.ssid));
            memcpy(apinfo.passwd, event->data.apinfo.passwd, strlen(event->data.apinfo.passwd));
            memcpy(apinfo.bssid, event->data.apinfo.bssid, WIFI_BSSID_LEN);

            linux_connect_ap(handle, &apinfo);
        }
        break;
        case WIFI_EVENT_USERDATA: {

        }
        break;
    }

    return 0;
}

void linux_wifi_provision(void)
{
    int32_t res = 0;
    void *handle = NULL;
    uint16_t flags = WIFIOPT_FLAGS_SMARTCONFIG;

    handle = aiot_wifi_init();
    if (handle == NULL) {
        printf("wifi provision init failed\n");
        return;
    }

    aiot_wifi_setopt(handle, WIFIOPT_PRODUCT_KEY, (void *)product_key);
    aiot_wifi_setopt(handle, WIFIOPT_DEVICE_NAME, (void *)device_name);
    aiot_wifi_setopt(handle, WIFIOPT_DECRYPT_KEY, (void *)product_secret);
    aiot_wifi_setopt(handle, WIFIOPT_SWITCH_MODE_CB, (void *)linux_switch_mode);
    aiot_wifi_setopt(handle, WIFIOPT_EVENT_HANDLE, (void *)linux_wifi_event_handle);
    aiot_wifi_setopt(handle, WIFIOPT_SWITCH_CHANNEL_CB, (void *)linux_switch_channel);
    aiot_wifi_setopt(handle, WIFIOPT_MACFRAME_SEND_CB,  (void *)linux_frame_send);

    aiot_wifi_enable(handle, flags);

    while (1) {
        res = aiot_wifi_process(handle);
        if (res == ERRCODE_WIFI_STATE_IDLE) {
            break;
        }
        usleep(100 * 1000);
    }

    /* get local ip and broadcast ip */
    linux_get_network_info(local_ip, broadcast_ip);
    aiot_wifi_setopt(handle, WIFIOPT_IP_ADDR,           (void *)local_ip);
    aiot_wifi_setopt(handle, WIFIOPT_BROADCAST_ADDR,    (void *)broadcast_ip);

    aiot_wifi_notify_success(handle, 5000);

    aiot_wifi_deinit(&handle);
}

void demo_ctrlpkt_handle(void *handle, aiot_mqtt_ctrlpkt_t *packet, void *userdata)
{
    switch (packet->ctrltype) {
        case MQTTCTRL_HEARTBEAT_RESPONSE: {
            printf("heartbeat received\n");
        }
        break;
        case MQTTCTRL_SUB_RESPONSE: {
            printf("sub res: %d, max_qos: %d, packet id: %d\n",
                   packet->data.sub_resp_data.res,
                   packet->data.sub_resp_data.max_qos,
                   packet->data.sub_resp_data.packet_id);
        }
        break;
        case MQTTCTRL_UNSUB_RESPONSE: {

        }
        break;
        case MQTTCTRL_PUB_RESPONSE: {

        }
        break;
    }
}

void demo_datapkt_handle(void *handle, aiot_mqtt_datapkt_t *packet, void *userdata)
{
    printf("data packet received:\n");
    printf("topic  : %.*s\n", packet->topic_len, packet->topic);
    printf("payload: %.*s\n", packet->payload_len, packet->payload);
}

void *demo_mqtt_thread(void *param)
{
    int32_t res;

    while (g_mqtt_running) {
        /* handle heartbeat send and qos1 message re-publish */
        aiot_mqtt_process(param);

        /* recv packet from network */
        res = aiot_mqtt_recv(param);
        if (res < 0) {
            /**
             * if network closed, aiot_mqtt_recv will be returned immediately if
             * it is not try to reconnect this time.
             */
            if (res == ERRCODE_SYS_NWK_CLOSED) {
                sleep(1);
            }
        }
    }

    return NULL;
}

void *demo_coap_thread(void *param)
{
    int32_t res;

    while (g_coap_running) {
        res = aiot_coap_recv(param);
        if (res < 0) {

            if (res == ERRCODE_SYS_NWK_CLOSED) {
                sleep(1);
            }
        }
        usleep(100 * 1000);
    }

    return NULL;
}

void *demo_bind_thread(void *param)
{
    while (g_bind_running) {
        aiot_bind_process(param);
        usleep(100 * 1000);
    }

    return NULL;
}

void *mqtt_start(void)
{
    void *mqtt_handle = NULL;
    char host[100] = {0};
    const char *host_fmt = "%s.%s";
    int32_t res;

    mqtt_handle = aiot_mqtt_init();
    if (mqtt_handle == NULL) {
        printf("aiot_mqtt_init failed\r\n");
        return NULL;
    }

    snprintf(host, 100, host_fmt, product_key, url);
    aiot_mqtt_setopt(mqtt_handle, MQTTOPT_HOST, (void *)host);
    aiot_mqtt_setopt(mqtt_handle, MQTTOPT_PORT, (void *)&port);
    aiot_mqtt_setopt(mqtt_handle, MQTTOPT_PRODUCT_KEY, (void *)product_key);
    aiot_mqtt_setopt(mqtt_handle, MQTTOPT_DEVICE_NAME, (void *)device_name);
    aiot_mqtt_setopt(mqtt_handle, MQTTOPT_DEVICE_SECRET, (void *)device_secret);
    aiot_mqtt_setopt(mqtt_handle, MQTTOPT_CTRLPKT_HANDLE, (void *)demo_ctrlpkt_handle);
    aiot_mqtt_setopt(mqtt_handle, MQTTOPT_DATAPKT_HANDLE, (void *)demo_datapkt_handle);

    res = aiot_mqtt_connect(mqtt_handle);
    if (res < 0) {
        printf("aiot_mqtt_connect failed, res = %d\n", res);
        return NULL;
    }

    /* create thread for mqtt receiving */
    g_mqtt_running = 1;
    res = pthread_create(&g_mqtt_thread, NULL, demo_mqtt_thread, mqtt_handle);
    if (res < 0) {
        printf("pthread_create failed\n");
        aiot_mqtt_deinit(&mqtt_handle);
        return NULL;
    }

    return mqtt_handle;
}

void *coap_start(void)
{
    void *coap_handle = NULL;
    int32_t res;

    coap_handle = aiot_coap_init();
    if (coap_handle == NULL) {
        printf("aiot_coap_init fail\r\n");
        return NULL;
    }

    res = aiot_coap_connect(coap_handle);
    if (res < 0) {
        return NULL;
    }

    g_coap_running = 1;
    res = pthread_create(&g_coap_thread, NULL, demo_coap_thread, coap_handle);
    if (res < 0) {
        printf("pthread_create failed\n");
        aiot_mqtt_deinit(&coap_handle);
        return NULL;
    }

    return coap_handle;
}

void *bind_start(void *mqtt_handle, void *coap_handle)
{
    void   *bind_handle;
    int32_t res;

    bind_handle = aiot_bind_init();
    if (bind_handle == NULL) {
        return NULL;
    }
    aiot_bind_setopt(bind_handle, BINDOPT_MQTT_HANDLE, mqtt_handle);
    aiot_bind_setopt(bind_handle, BINDOPT_COAP_HANDLE, coap_handle);
    aiot_bind_setopt(bind_handle, BINDOPT_PRODUCT_KEY, (void *)product_key);
    aiot_bind_setopt(bind_handle, BINDOPT_DEVICE_NAME, (void *)device_name);
    aiot_bind_setopt(bind_handle, BINDOPT_MAC_ADDR, (void *)"\x8c\x16\x45\x66\x47\x55");
    aiot_bind_setopt(bind_handle, BINDOPT_IP_ADDR, (void *)local_ip);
    aiot_bind_setopt(bind_handle, BINDOPT_BROADCAST_ADDR, (void *)broadcast_ip);

    g_bind_running = 1;
    res = pthread_create(&g_bind_thread, NULL, demo_bind_thread, bind_handle);
    if (res < 0) {
        printf("pthread_create failed\n");
        aiot_mqtt_deinit(&mqtt_handle);
        aiot_coap_deinit(&coap_handle);
        return NULL;
    }

    return bind_handle;
}

int main(int argc, char *argv[])
{
    void *mqtt_handle = NULL;
    void *coap_handle = NULL;
    void *bind_handle = NULL;

    /* linux memstat */
    linux_memstat_init();

    /* set log level */
    aiot_log_set_level(AIOT_LOG_DEBUG);

    /* start wifi provision until succeed */
    linux_wifi_provision();

    /* mqtt init */
    mqtt_handle = mqtt_start();
    if (mqtt_handle == NULL) {
        return -1;
    }
    /* coap init */
    coap_handle = coap_start();
    if (mqtt_handle == NULL) {
        aiot_mqtt_deinit(&mqtt_handle);
        return -1;
    }
    /* bind init */
    bind_handle = bind_start(mqtt_handle, coap_handle);
    if (bind_handle == NULL) {
        aiot_mqtt_deinit(&mqtt_handle);
        aiot_coap_deinit(&coap_handle);
        return -1;
    }

    while (1) {
        sleep(1);
    }

    g_mqtt_running = 0;
    pthread_join(g_mqtt_thread, NULL);
    g_coap_running = 0;
    pthread_join(g_coap_thread, NULL);
    g_bind_running = 0;
    pthread_join(g_bind_thread, NULL);

    aiot_mqtt_deinit(&mqtt_handle);
    aiot_coap_deinit(&coap_handle);
    aiot_bind_deinit(&bind_handle);
    linux_memstat_print();
    linux_memstat_deinit();

    return 0;
}
