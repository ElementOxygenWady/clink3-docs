/**
 * @file aiot_mqtt_api.h
 * @brief log module api header file
 * @version 0.1
 * @date 2019-05-04
 *
 * @copyright Copyright (C) 2015-2018 Alibaba Group Holding Limited
 *
 */

#ifndef _AIOT_LOG_API_H_
#define _AIOT_LOG_API_H_

#if defined(__cplusplus)
extern "C" {
#endif

/**
 * @brief level parameter for @ref printf_t to indicate the log level of sdk.
 * @brief
 * @brief --------------------------------------------------
 * @brief @ref printf_t 函数的level参数，用于表示SDK内部日志的等级
 * 该参数来传递client的地址信息。
 */
typedef enum {
    AIOT_LOG_DEBUG,
    AIOT_LOG_INFO,
    AIOT_LOG_ERROR
} aiot_log_level_t;

/**
 * @brief set sdk log message level
 *
 * @param[in] level sdk log level, see @ref aiot_log_level_t for more information
 * 
 * @return void
 *
 * @brief
 * @brief --------------------------------------------------
 *
 * @brief 设置sdk日志级别
 *
 * @param[in] level sdk日志级别, 更多信息请参考@ref aiot_log_level_t
 * 
 * @return void
 */
void aiot_log_set_level(aiot_log_level_t level);

#if defined(__cplusplus)
}
#endif
#endif