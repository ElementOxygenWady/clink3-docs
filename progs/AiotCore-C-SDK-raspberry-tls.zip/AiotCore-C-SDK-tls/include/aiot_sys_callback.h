/**
 * @file aiot_sys_callback.h
 * @brief system module api header file
 * @version 0.1
 * @date 2019-05-05
 *
 * @copyright Copyright (C) 2015-2018 Alibaba Group Holding Limited
 *
 */

#ifndef _AIOT_SYS_CALLBACK_H_
#define _AIOT_SYS_CALLBACK_H_

#if defined(__cplusplus)
extern "C" {
#endif

#include <stdio.h>
#include <stdint.h>

/**
 * @brief network options for @ref aiot_nwk_setopt function.the data type below indicate data param in @ref aiot_nwk_setopt
 * @brief
 * @brief --------------------------------------------------
 * @brief @ref aiot_nwk_setopt 函数的option参数。下文每一个选项中的数据类型指的是@ref aiot_nwk_setopt 中的data参数。
 */
typedef enum {
    /**
     * network type, tcp or udp
     *
     * data type: (uint8_t *)
     *
     * value:\n
     * 0 - tcp client\n
     * 1 - tcp server\n
     * 2 - udp client\n
     * 3 - udp server\n
     *
     * --------------------------------------------------
     *
     * 网络类型，tcp或udp
     *
     * 数据类型：(uint8_t *)
     *
     * 取值:\n
     * 0 - tcp client\n
     * 1 - tcp server\n
     * 2 - udp client\n
     * 3 - udp server\n
     */
    SYSNWK_TYPE,
    /**
     * domain name or ip address, as with MQTTOPT_HOST in @ref aiot_mqtt_setopt\n
     * if mqtt module is used.
     *
     * data type: (uint8_t*)
     *
     * --------------------------------------------------
     *
     * 域名地址或ip地址。\n
     * 如果使用的是mqtt模块，那么该参数与@ref aiot_mqtt_setopt 中设置的MQTTOPT_HOST参数一致
     *
     * 数据类型：(uint8_t*)
     */
    SYSNWK_HOST,
    /**
     * the port used to establish network connection, as with MQTTOPT_PORT in @ref aiot_mqtt_setopt\n
     * if mqtt module is used.
     *
     * data type: (uint16_t *)
     *
     * --------------------------------------------------
     *
     * 用于建立网络连接的端口号。\n
     * 如果使用的是mqtt模块，那么该参数与@ref aiot_mqtt_setopt 中设置的MQTTOPT_PORT参数一致
     *
     * 数据类型：(uint16_t *)
     */
    SYSNWK_PORT,
    /**
     * specify security option for network connection
     *
     * data type: (uint8_t *)
     *
     * value:\n
     * 0 - using network without security
     * 1 - using network with security
     *
     * --------------------------------------------------
     *
     * 指定网络连接的安全选项
     *
     * 数据类型：(uint8_t *)
     *
     * 取值:\n
     * 0 - 使用非安全的网络连接
     * 1 - 使用安全的网络连接
     */
    SYSNWK_SECURITY,
    SYSNWK_MAX
} aiot_sys_nwk_option_t;

/**
 * @brief addr for @ref aiot_nwk_read and @ref aiot_nwk_write when using tcp or udp server.
 * @brief
 * @brief --------------------------------------------------
 * @brief @ref aiot_nwk_read 和 @ref nwk_write_ 函数的addr参数。当使用tcp或udp server时可使用
 * 该参数来传递client的地址信息。
 */
typedef struct {
    /**
     * ipv4 dot-decimal notation, max length is 15 bytes.
     *
     * --------------------------------------------------
     *
     * ipv4地址点分十进制字符串，最大长度15字节。
     */
    char addr[16];
    /**
     * tcp or udp port
     *
     * --------------------------------------------------
     *
     * tcp/udp 端口号
     */
    uint16_t port;
} aiot_sys_addr_t;

/**
 * @brief allocate memory
 *
 * @param[in] size memory block size
 * @param[in] name who need the memory, can be used for memory statistics.
 *            just ignore it if you don't need
 *
 * @return void* the address of allocated memory block
 * @retval NotNULL the valid address
 * @retval NULL failed to allocate
 *
 * @note this system callback is mandatory, must be implemented by user.
 *
 * @brief
 * @brief --------------------------------------------------
 *
 * @brief 内存分配函数
 *
 * @param[in] size 需要分配的内存块大小
 * @param[in] name 需要该内存块的代码模块，可以用作内存统计。如果不需要的话，忽略即可。
 *
 * @return void* 已分配的内存地址
 * @retval NotNULL 内存申请成功，返回内存地址
 * @retval NULL 内存申请失败
 *
 * @note 此系统回调函数为必选，必须由用户实现
 */
void* aiot_sys_malloc(uint32_t size, char *name);

/**
 * @brief free memory
 *
 * @param[in] ptr the pointer to memory block which want to be freed
 *
 * @return void
 *
 * @note this system callback is mandatory, must be implemented by user.
 *
 * @brief
 * @brief --------------------------------------------------
 *
 * @brief 内存释放函数
 *
 * @param[in] ptr 指向需要释放的内存块
 *
 * @return void
 *
 * @note 此系统回调函数为必选，必须由用户实现
 */
void aiot_sys_free(void *ptr);

/**
 * @brief get current system times(ms)
 *
 * @return uint64_t current system time
 *
 * @note this system callback is mandatory, must be implemented by user.
 *
 * @brief
 * @brief --------------------------------------------------
 *
 * @brief 获取当前系统时间（单位：ms）
 *
 * @return uint64_t 当前系统时间
 *
 * @note 此系统回调函数为必选，必须由用户实现
 */
uint64_t aiot_sys_time(void);

/**
 * @brief init network handle and set default parameter.
 *
 * @return void*
 * @retval NotNULL network handle
 * @retval NULL init failed
 *
 * @note this system callback is mandatory, must be implemented by user.
 *
 * @brief
 * @brief --------------------------------------------------
 *
 * @brief 初始化network句柄并设置默认参数
 *
 * @return void*
 * @retval NotNULL network句柄
 * @retval NULL 初始化失败
 *
 * @note 此系统回调函数为必选，必须由用户实现
 */
void* aiot_nwk_init(void);

/**
 * @brief set network option
 *
 * @param[in] handle network handle
 * @param[in] option network config option, see @ref aiot_sys_nwk_option_t for more information
 * @param[in] data network config option data, see @ref aiot_sys_nwk_option_t for more information
 *
 * @return int32_t
 * @retval 0 set option succeed
 * @retval -1 set option failed
 *
 * @note this system callback is mandatory, must be implemented by user.
 *
 * @brief
 * @brief --------------------------------------------------
 *
 * @brief 设置网络参数
 *
 * @param[in] handle network句柄
 * @param[in] option 网络配置选项，更多信息请参考@ref aiot_sys_nwk_option_t
 * @param[in] data 网络配置参数，更多信息请参考@ref aiot_sys_nwk_option_t
 *
 * @return int32_t
 * @retval 0 参数设置成功
 * @retval -1 参数设置失败
 *
 * @note 此系统回调函数为必选，必须由用户实现
 */
int32_t aiot_nwk_setopt(void *handle, aiot_sys_nwk_option_t option, void *data);

/**
 * @brief establish network connection
 *
 * @param[in] handle network handle
 *
 * @return int32_t
 * @retval 0 establish succeed
 * @retval -1 establish failed
 *
 * @note this system callback is mandatory, must be implemented by user.
 *
 * @brief
 * @brief --------------------------------------------------
 *
 * @brief 建立网络连接
 *
 * @param[in] handle network句柄
 *
 * @return int32_t
 * @retval 0 建立连接成功
 * @retval -1 建立连接失败
 *
 * @note 此系统回调函数为必选，必须由用户实现
 */
int32_t aiot_nwk_establish(void *handle);

/**
 * @brief try to read data from network
 *
 * @param[in] handle network handle
 * @param[in] buffer used for storing data which read from network
 * @param[in] len the maximum length which the buffer can be write in by read data
 * @param[in] timeout_ms the maximum time this function can be used for reading data
 * @param[in] addr only can be used when establish tcp/udp server
 *
 * @return int32_t
 * @retval >=0 the number of bytes read from network
 * @retval <0 network error indicate current network disconnected
 *
 * @note this system callback is mandatory, must be implemented by user.
 *
 * @brief
 * @brief --------------------------------------------------
 *
 * @brief 尝试从网络读取数据
 *
 * @param[in] handle network句柄
 * @param[in] buffer 存放从网络上读取到的数据
 * @param[in] len buffer最多能存放的数据长度
 * @param[in] timeout_ms 该函数从网络读取报文的最长时间
 * @param[in] addr 仅在当前连接为tcp/udp服务器时使用
 *
 * @return int32_t
 * @retval >=0 从网络上读取到的数据长度
 * @retval <0 网络异常，表示检测到网络已断开
 *
 * @note 此系统回调函数为必选，必须由用户实现
 */
int32_t aiot_nwk_read(void *handle, uint8_t *buffer, uint32_t len, uint32_t timeout_ms, aiot_sys_addr_t *addr);

/**
 * @brief try to write data to network
 *
 * @param[in] handle network handle
 * @param[in] buffer data in this buffer will be write to netowrk
 * @param[in] len the length which the data need to be written
 * @param[in] timeout_ms the maximum time this function can be used for writing data
 *
 * @return int32_t
 * @retval >=0 the number of bytes write to network
 * @retval <0 network error indicate current network disconnected
 *
 * @note this system callback is mandatory, must be implemented by user.
 *
 * @brief
 * @brief --------------------------------------------------
 *
 * @brief 尝试向网络发送数据
 *
 * @param[in] handle network句柄
 * @param[in] buffer 需要发送到网络的数据
 * @param[in] len 需要发送的数据长度
 * @param[in] timeout_ms 该函数向网络发送数据的最长时间
 *
 * @return int32_t
 * @retval >=0 向网络发送的数据长度
 * @retval <0 网络异常，表示检测到网络已断开
 *
 * @note 此系统回调函数为必选，必须由用户实现
 */
int32_t aiot_nwk_write(void *handle, uint8_t *buffer, uint32_t len, uint32_t timeout_ms, aiot_sys_addr_t *addr);

/**
 * @brief free memory for network handle
 *
 * @param[in] handle network handle
 *
 * @return int32_t
 * @retval >=0 free memory succeed
 * @retval <0 free memory failed
 *
 * @note this system callback is mandatory, must be implemented by user.
 *
 * @brief
 * @brief --------------------------------------------------
 *
 * @brief 回收network句柄的资源
 *
 * @param[in] handle network句柄
 *
 * @return int32_t
 * @retval >=0 回收资源成功
 * @retval <0 回收资源失败
 *
 * @note 此系统回调函数为必选，必须由用户实现
 */
int32_t aiot_nwk_deinit(void *handle);

/**
 * @brief random buffer generator
 *
 * @param[out] output the random buffer generated should be copied to this buffer
 * @param[in] output_len the length of output buffer
 *
 * @note this system callback is optional if there is no need for dynamic register and bind\n
 *       when using dynamic register or bind without this system callback, related api will\n
 *       return @ref ERRCODE_SYS_MISSING_SYSCB_RAND
 *
 * @brief
 * --------------------------------------------------
 *
 * @brief 随机数产生器
 *
 * @param[out] output 产生的随机数需要拷贝到该地址上
 * @param[in] output_len output的最大长度，即需要产生的随机数长度
 *
 * @note 此系统回调函数为可选，除非需要使用动态注册和绑定模块。如果在使用动态注册或者绑定模块时没有设置此回调函数\n
 *       相关api会返回@ref ERRCODE_SYS_MISSING_SYSCB_RAND
 */
void aiot_sys_rand(uint8_t *output, uint32_t output_len);

/**
 * @brief print sdk log message
 *
 * @param[in] log sdk log information
 *
 * @return void
 *
 * @note this system callback is optional if there is no need to see log of sdk
 *
 * @brief
 * @brief --------------------------------------------------
 *
 * @brief 打印sdk日志信息
 *
 * @param[in] log sdk日志信息
 *
 * @return void
 *
 * @note 此系统回调函数为可选，除非无需查看sdk日志信息
 */
void aiot_sys_printf(char *log);

/**
 * @brief init a mutex
 *
 * @return void*
 * @retval NotNULL init mutex succeed
 * @retval NULL init mutex failed
 *
 * @note this system callback is optional if there is no need to guarantee thread-safe
 *
 * @brief
 * @brief --------------------------------------------------
 *
 * @brief 初始化互斥锁
 *
 * @return void*
 * @retval NotNULL 初始化互斥锁成功
 * @retval NULL 初始化互斥锁失败
 *
 * @note 此系统回调函数为可选，除非需要保证线程安全
 */
void* aiot_mutex_init(void);

/**
 * @brief lock a mutex
 *
 * @param[in] mutex the mutex try to lock
 *
 * @return void
 *
 * @note this system callback is optional if there is no need to guarantee thread-safe
 *
 * @brief
 * @brief --------------------------------------------------
 *
 * @brief 对一个互斥锁加锁
 *
 * @param[in] mutex 待加锁的互斥锁
 *
 * @return void
 *
 * @note 此系统回调函数为可选，除非需要保证线程安全
 */
void aiot_mutex_lock(void *mutex);

/**
 * @brief unlock a mutex
 *
 * @param[in] mutex the mutex try to unlock
 *
 * @return void
 *
 * @note this system callback is optional if there is no need to guarantee thread-safe
 *
 * @brief
 * @brief --------------------------------------------------
 *
 * @brief 对一个互斥锁解锁
 *
 * @param[in] mutex 待解锁的互斥锁
 *
 * @return void
 *
 * @note 此系统回调函数为可选，除非需要保证线程安全
 */
void aiot_mutex_unlock(void *mutex);

/**
 * @brief free memory for a mutex
 *
 * @param[in] mutex the mutex try to free memory
 *
 * @return void
 *
 * @note this system callback is optional if there is no need to guarantee thread-safe
 *
 * @brief
 * @brief --------------------------------------------------
 *
 * @brief 回收一个互斥锁的资源
 *
 * @param[in] mutex 待回收资源的互斥锁
 *
 * @return void
 *
 * @note 此系统回调函数为可选，除非需要保证线程安全
 */
void aiot_mutex_deinit(void *mutex);

#if defined(__cplusplus)
}
#endif
#endif