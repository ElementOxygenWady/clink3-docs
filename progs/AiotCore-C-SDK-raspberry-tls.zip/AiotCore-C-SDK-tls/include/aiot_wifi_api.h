/**
 * @file aiot_wifi_api.h
 * @brief wifi provision basic API
 * @version 0.1
 * @date 2019-05-07
 *
 * @copyright Copyright (C) 2015-2018 Alibaba Group Holding Limited
 *
 */

#ifndef _AIOT_WIFI_API_H_
#define _AIOT_WIFI_API_H_

#if defined(__cplusplus)
extern "C" {
#endif

#include <stdio.h>
#include <stdint.h>

#define WIFI_SSID_LEN           (32)
#define WIFI_PASSWD_LEN         (64)
#define WIFI_BSSID_LEN          (6)
#define WIFI_APPTOKEN_LEN       (32)

typedef struct {
    uint8_t *buffer;
    uint32_t buffer_len;
} aiot_wifi_mac_frame_t;

typedef enum {
    WIFI_EVENT_APINFO,
    WIFI_EVENT_USERDATA
} aiot_wifi_event_type_t;

typedef struct {
    char ssid[WIFI_SSID_LEN + 1];      /* string */
    char passwd[WIFI_PASSWD_LEN + 1];  /* string */
    uint8_t bssid[WIFI_BSSID_LEN];     /* hex */
    char token[WIFI_APPTOKEN_LEN + 1]; /* string */
} aiot_wifi_event_apinfo_t;

typedef struct {
    uint8_t *buffer;
    uint32_t buffer_len;
} aiot_wifi_event_userdata_t;

typedef struct {
    aiot_wifi_event_type_t type;
    union {
        aiot_wifi_event_apinfo_t apinfo;
        aiot_wifi_event_userdata_t userdata;
    }data;
} aiot_wifi_event_t;

typedef int32_t (*aiot_wifi_event_handle_t)(void *handle, aiot_wifi_event_t *event);

typedef enum {
    WIFIOPT_PRODUCT_KEY,      /**< data type: (char *)                                */
    WIFIOPT_DEVICE_NAME,      /**< data type: (char *)                                */
    /**
     * after wifi provision succeed,  the receiving encryped password need this decrypt key to
     * work out plain password. the value should be product secret of current device.
     *
     * data type: (char *)
     *
     * --------------------------------------------------
     *
     * 在wifi配网成功后，需要使用该选项配置的密钥去解密收到的已加密的密码。目前该选项的值必须为设备的product secret。
     *
     * 数据类型：(char *)
     */
    WIFIOPT_DECRYPT_KEY,
    /**
     * set device ip address after wifi provision succeed, which will be used in @ref aiot_wifi_notify_success.
     *
     * data type: (char *)
     *
     * --------------------------------------------------
     *
     * 设置设备在配网成功后获取的ip地址，在使用@ref aiot_wifi_notify_success 向移动端广播配网成功的消息时需要用到。
     *
     * 数据类型：(char *)
     */
    WIFIOPT_IP_ADDR,
    /**
     * set device broadcast address after wifi provision succeed, which will be used in @ref aiot_wifi_notify_success.
     *
     * data type: (char *)
     *
     * --------------------------------------------------
     *
     * 设置设备在配网成功后的广播地址，在使用@ref aiot_wifi_notify_success 向移动端广播配网成功的消息时需要用到。
     *
     * 数据类型：(char *)
     */
    WIFIOPT_BROADCAST_ADDR,
    /**
     * set device broadcast port after wifi provision succeed, which will be used in @ref aiot_wifi_notify_success.
     *
     * data type: (uint16_t *) default: 5683
     *
     * --------------------------------------------------
     *
     * 设置设备在配网成功后的广播端口号，在使用@ref aiot_wifi_notify_success 向移动端广播配网成功的消息时需要用到。
     *
     * 数据类型：(uint16_t *) 默认值：5683
     */
    WIFIOPT_BROADCAST_PORT,
    /**
     * set device mac address after wifi provision succeed, which will be used in @ref aiot_wifi_notify_success.
     *
     * data type: (uint8_t *) length: 6 bytes
     *
     * --------------------------------------------------
     *
     * 设置设备的mac地址，在使用@ref aiot_wifi_notify_success 向移动端广播配网成功的消息时需要用到。
     *
     * 数据类型：(uint8_t *) 长度: 6 bytes
     */
    WIFIOPT_MAC_ADDR,
    /**
     * set wifi provision event callback, see @ref aiot_wifi_event_handle_t for more information.
     *
     * data type: (aiot_wifi_event_handle_t)
     *
     * --------------------------------------------------
     *
     * 设置wifi配网事件回调函数，更多信息请参考@ref aiot_wifi_event_handle_t。
     *
     * 数据类型：(aiot_wifi_event_handle_t)
     */
    WIFIOPT_EVENT_HANDLE,
    /**
     * set wifi mode switch callback which used for switching mode between STA/AP/SNIFFER, see @ref wificb_switch_mode_t for more information.
     *
     * data type: (wificb_switch_mode_t)
     *
     * --------------------------------------------------
     *
     * 设置wifi模式切换回调函数，用于在STA/AP/SNIFFER三种模式中进行切换，更多信息请参考@ref wificb_switch_mode_t。
     *
     * 数据类型：(wificb_switch_mode_t)
     */
    WIFIOPT_SWITCH_MODE_CB,
    /**
     * set wifi channel switch callback, see @ref wificb_switch_channel_t for more information.
     *
     * data type: (wificb_switch_channel_t)
     *
     * --------------------------------------------------
     *
     * 设置wifi信道切换回调函数，更多信息请参考@ref wificb_switch_channel_t。
     *
     * 数据类型：(wificb_switch_channel_t)
     */
    WIFIOPT_SWITCH_CHANNEL_CB,
    /**
     * set wifi 802.11 mac frame send callback, see @ref wificb_frame_send_t for more information.
     *
     * data type: (wificb_frame_send_t)
     *
     * --------------------------------------------------
     *
     * 设置wifi 802.11 mac层帧发送函数，更多信息请参考@ref wificb_frame_send_t
     *
     * 数据类型：(wificb_frame_send_t)
     */
    WIFIOPT_MACFRAME_SEND_CB,
    /**
     * set system sleep_ms callback, see @ref wificb_sleep_ms_t for more information.
     *
     * data type: (wificb_sleep_ms_t)
     *
     * --------------------------------------------------
     *
     * 配置睡眠回调函数，更多信息请参考@ref wificb_sleep_ms_t
     *
     * 数据类型：(wificb_sleep_ms_t)
     */
    WIFIOPT_SLEEP_MS_CB,
    WIFIOPT_HAS_FCS,          /**< data type: (uint8_t *)                             */
    WIFIOPT_DEVAP_SSID,       /**< data type: (char *) strlen: 8 bytes, reserved      */
    WIFIOPT_MAX
} aiot_wifi_option_t;

#define WIFIOPT_FLAGS_SMARTCONFIG (1 << 0)
#define WIFIOPT_FLAGS_ZEROCONFIG  (1 << 1)
#define WIFIOPT_FLAGS_DEVICEAP    (1 << 2)

typedef enum {
    WIFI_MODE_SNIFFER,
    WIFI_MODE_STA,
    WIFI_MODE_AP
} aiot_wifi_wlan_mode_t;

typedef struct {
    char ssid[WIFI_SSID_LEN + 1];      /* string */
    char passwd[WIFI_PASSWD_LEN + 1];  /* string */
    uint8_t bssid[WIFI_BSSID_LEN];     /* hex */
} aiot_wifi_apinfo_t;

typedef enum {
    WIFI_FRAME_PROBE_REQUEST,
} aiot_wifi_frame_type_t;

/**
 * @brief this function will be used as parameter of @ref wificb_switch_mode_t when switch wifi mode to SNIFFER mode
 *
 * this function is implemented by SDK and pass to user when @ref wificb_switch_mode_t used for switching wifi mode to SNIFFER mode.
 * when user receive 802.11 mac frame, pass it to this function.
 *
 * @brief
 * @brief --------------------------------------------------
 * @brief 此函数在切换wifi模式为SNIFFER模式时被使用
 *
 * 此函数由SDK实现，当SDK使用@ref wificb_switch_mode_t 切换wifi至SNIFFER模式时，作为参数传递给用户。
 * 当用户收到8021.11 mac层帧时，将该帧传递给此函数。
 *
 */
typedef int32_t (*wifi_frame_recv_t)(void *handle, aiot_wifi_mac_frame_t *mac_frame);

/**
 * @brief called when SDK need switch wifi mode between STA/AP/SNIFFER
 *
 * 1. when using smartconfig and zeroconfig:
 *    this callback should be called to switch wifi mode between STA/SNIFFER
 *
 * 2. when using deviceap:
 *    this callback should be called to switch wifi mode between STA/AP
 *
 * @note when switch to SNIFFER mode, @ref wifi_frame_recv_t which implemented by SDK will be passed to user as data parameter.
 *
 * @brief
 * @brief --------------------------------------------------
 * @brief 当SDK需要切换wifi模式时，该回调函数被调用
 *
 * 1. 当使用一键配网和零配时：
 *    该回调函数需要支持在STA/SNIFFER模式之间切换
 *
 * 2. 当使用设备热点配网时：
 *    该回调函数需要支持在STA/AP模式之间切换
 *
 * @note 当切换至sniffer模式时，由SDK实现的@ref wifi_frame_recv_t 会通过data参数传递给用户。
 */
typedef int32_t (*wificb_switch_mode_t)(void *handle, aiot_wifi_wlan_mode_t mode, void *data);

/**
 * @brief called when using smartconfig/zeroconfig to switch wifi channel
 * @brief
 * @brief --------------------------------------------------
 * @brief 配网模式为一键配网/零配时，该回调函数被调用，用于切换信道以监听802.11 mac层帧
 */
typedef int32_t (*wificb_switch_channel_t)(void *handle, uint8_t channel);

/**
 * @brief called when using zeroconfig to send 802.11 probe request/probe response frame
 * @brief
 * @brief --------------------------------------------------
 * @brief 当配网模式为零配时，该回调函数被调用，用于发送802.11 probe request/probe response 管理帧
 */
typedef int32_t (*wificb_frame_send_t)(void *handle, aiot_wifi_frame_type_t type, aiot_wifi_mac_frame_t *mac_frame);

/**
 * @brief called when internal sleep used
 * @brief
 * @brief --------------------------------------------------
 * @brief 当配网模式为零配时，该回调函数被调用，用于发送802.11 probe request/probe response 管理帧
 */
typedef void (*wificb_sleep_ms_t)(uint32_t ms);

/**
 * @brief init wifi provision handle
 *
 * @return void*
 * @retval NotNULL wifi provision handle
 * @retval NULL init failed
 *
 * @brief
 * @brief --------------------------------------------------
 *
 * @brief 初始化wifi配网句柄
 *
 * @return void*
 * @retval 非NULL wifi配网句柄
 * @retval NULL 初始化失败
 */
void* aiot_wifi_init(void);

/**
 * @brief set wifi provision configuration
 *
 * @param[in] handle the wifi provision handle
 * @param[in] option the wifi provision configuration option, see @ref aiot_wifi_option_t for more information
 * @param[in] data the wifi provision configuration data, see @ref aiot_wifi_option_t for more information
 *
 * @return int32_t
 * @retval <ERRCODE_SUCCESS set opt failed
 * @retval >=ERRCODE_SUCCESS set opt succeed
 *
 * @brief
 * @brief --------------------------------------------------
 *
 * @brief 设置wifi配网参数
 *
 * @param[in] handle wifi配网句柄
 * @param[in] option 配置选项, 更多信息请参考@ref aiot_wifi_option_t
 * @param[in] data   配置选项数据，更多信息请参考@ref aiot_wifi_option_t
 *
 * @return int32_t
 * @retval <ERRCODE_SUCCESS 参数设置失败
 * @retval >=ERRCODE_SUCCESS 参数设置成功
 */
int32_t aiot_wifi_setopt(void *handle, aiot_wifi_option_t option, void *data);

/**
 * @brief enable specific wifi provison mode
 *
 * 1. WIFIOPT_FLAGS_SMARTCONFIG\n
 *    smartconfig wifi provision. deivce uses wifi sniffer mode to receive 802.11 mac frame, and then connect router.\n
 * 2. WIFIOPT_FLAGS_ZEROCONFIG\n
 *    zeroconfig wifi provision. deivce uses sniffer mode to receive 802.11 mac frame(probe request/probe response), and the connect router.\n
 * 3. WIFIOPT_FLAGS_DEVICEAP\n
 *    device ap wifi provision. deivce uses ap mode to receive ssid and password from phone, then connect to router.\n
 *
 * @param[in] handle the wifi provision handle
 * @param[in] flag the wifi provison mode flags which consist of bitwise or of above three values
 *
 * @return int32_t
 * @retval <ERRCODE_SUCCESS enable wifi provision mode failed
 * @retval >=ERRCODE_SUCCESS enable wifi provision mode succeed
 *
 * @brief
 * @brief --------------------------------------------------
 *
 * @brief 使能指定的wifi配网模式
 *
 * 1. WIFIOPT_FLAGS_SMARTCONFIG\n
 *    一键配网模式。设备切换至sniffer模式，接收802.11 mac层数据帧以获取ssid和密码。
 * 2. WIFIOPT_FLAGS_ZEROCONFIG\n
 *    零配模式。设备切换至sniffer模式，接收802.11 mac层管理帧（probe request/probe response）以获取ssid和密码
 * 3. WIFIOPT_FLAGS_DEVICEAP\n
 *    设备热点配网模式。设备切换至AP模式，移动端连接设备，设备从移动端获取ssid和密码。
 *
 * @params[in] handle wifi配网句柄
 * @params[in] flag wifi配网模式的标志位，可由上面三种配网模式的值进行按位与运算组成。
 *
 * @return int32_t
 * @retval <ERRCODE_SUCCESS 使能wifi配网模式失败
 * @retval >=ERRCODE_SUCCESS 使能wifi配网模式成功
 */
int32_t aiot_wifi_enable(void *handle, uint16_t flag);

/**
 * @brief send connect ap message to notify ios/android app through local area network
 *
 * @param[in] handle the wifi provision handle
 * @param[in] timeout_ms the notify response timeout
 *
 * @return int32_t
 * @retval <ERRCODE_SUCCESS send notify failed
 * @retval >=ERRCODE_SUCCESS send notify succeed
 *
 * @note before send notify message, device should join the same local area network that ios/android app is in
 *
 * @brief
 * @brief --------------------------------------------------
 *
 * @brief 通过局域网广播将配网成功的消息告知移动端
 *
 * @param[in] handle wifi配网句柄
 * @param[in] timeout_ms 局域网最长广播时长
 *
 * @return int32_t
 * @retval <ERRCODE_SUCCESS 广播消息失败
 * @retval >=ERRCODE_SUCCESS 广播消息成功
 *
 * @note 广播配网成功的消息时，设备应该与移动端在同一局域网内
 */
int32_t aiot_wifi_notify_success(void *handle, uint32_t timeout_ms);

/**
 * @brief free memory for wifi provision handle
 *
 * @param[in] handle the pointer to the wifi provision handle
 *
 * @return int32_t
 * @retval <ERRCODE_SUCCESS execute failed
 * @retval >=ERRCODE_SUCCESS execute succeed
 *
 * @brief
 * @brief --------------------------------------------------
 *
 * @brief 反初始化wifi配网句柄
 *
 * @param[in] handle 指向wifi配网句柄的指针
 *
  * @return int32_t
 * @retval <ERRCODE_SUCCESS 执行失败
 * @retval >=ERRCODE_SUCCESS 执行成功
 */
int32_t aiot_wifi_deinit(void **handle);

/**
 * @brief state machine for wifi provision
 *
 * @param[in] handle wifi provision handle, initialized by @aiot_wifi_init
 *
 * @return int32_t
 * @retval >=ERRCODE_SUCCESS wifi provision succeed
 * @retval <ERRCODE_SUCCESS indicate current state or error
 *
 * @note this api should be called repeatedlly after choose wifi provision mode using @ref aiot_wifi_enable
 *
 * @brief
 * @brief --------------------------------------------------
 *
 * @brief wifi配网状态机
 *
 * @param[in] handle wifi配网句柄
 *
 * @return int32_t
 * @retval >=ERRCODE_SUCCESS wifi配网成功
 * @retval <ERRCODE_SUCCESS wifi配网状态或错误码
 *
 * @note 在使用@ref aiot_wifi_enable 选择配网模式后，可反复调用此API进行配网
 */
int32_t aiot_wifi_process(void *handle);

#if defined(__cplusplus)
}
#endif
#endif