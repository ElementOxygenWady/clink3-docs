/**
 * @file aiot_bind_api.h
 * @brief bind module api header file
 * @version 0.1
 * @date 2019-05-28
 *
 * @copyright Copyright (c) 2015-2018 Alibaba Group Holding Limited
 *
 */

#ifndef _AIOT_BIND_API_H_
#define _AIOT_BIND_API_H_

#if defined(__cplusplus)
extern "C" {
#endif

#include <stdio.h>
#include <stdint.h>
#include "aiot_mqtt_api.h"

/**
 * @brief extern mqtt api prototype define for compatiblity, ignore this if internal mqtt lib used
 *
 */
typedef int32_t (*bind_mqtt_sub_func_t)(void *handle, aiot_mqtt_sub_t *sub);
typedef int32_t (*bind_mqtt_pub_func_t)(void *handle, aiot_mqtt_datapkt_t *packet);
typedef struct {
    bind_mqtt_sub_func_t mqtt_sub_func;
    bind_mqtt_pub_func_t mqtt_pub_func;
} aiot_bind_ext_mqtt_api_t;

/**
 * @brief bind event type define
 *
 */
typedef enum {
    BIND_EVENT_POST_CLOUD_SUCCEED,      /* post token to cloud succeed event */
    BIND_EVENT_TOKEN_REQ_RECVED,        /* receive token request from phone event */
    BIND_EVENT_TOKEN_RSP_SENDED,        /* response token to phone succeed event */
    BIND_EVENT_NUM,
} aiot_bind_event_type_t;

/**
 * @brief event data of @ref BIND_EVENT_POST_CLOUD_SUCCEED event
 *
 */
typedef struct {
    const char *token;                  /* pointer to token string */
    uint32_t ttl;                       /* time to live of the token */
} bind_event_post_cloud_data_t;

/**
 * @brief event data of @ref BIND_EVENT_TOKEN_REQ_RECVED event
 *
 */
typedef struct {
    const char *req_data;               /* token request data from phone */
    uint32_t req_data_len;              /* length of request data */
    const char *remote_ip;              /* the ip address string of request device */
} bind_event_token_req_data_t;

/**
 * @brief event data of @ref BIND_EVENT_TOKEN_RSP_SENDED event
 *
 */
typedef struct {
    const char *rsp_data;               /* response data of token request */
    uint32_t rsp_data_len;              /* length fo response data */
    const char *remote_ip;              /* the ip address string of remote device */
} bind_event_token_rsp_data_t;

/**
 * @brief bind event data define
 *
 */
typedef struct {
    aiot_bind_event_type_t type;
    union {
        bind_event_post_cloud_data_t post_cloud;
        bind_event_token_req_data_t token_req;
        bind_event_token_rsp_data_t token_rsp;
    } data;
} aiot_bind_event_data_t;

/**
 * @brief bind event handler function prototype
 *
 */
typedef void (*aiot_bind_event_handler_t)(void *handle, aiot_bind_event_data_t *data);

/**
 * @brief bind option, all mandatory option shall be setup
 *
 */
typedef enum {
    BINDOPT_MQTT_HANDLE,        /**< dataType:(void *), mqtt handle, @b mandatory option */
    BINDOPT_COAP_HANDLE,        /**< dataType:(void *), coap handle, @b mandatory option */
    BINDOPT_PRODUCT_KEY,        /**< dataType:(char *), product key, @b mandatory option */
    BINDOPT_DEVICE_NAME,        /**< dataType:(char *), device name, @b mandatory option */
    BINDOPT_IP_ADDR,            /**< dataType:(char *), local ip address, @b mandatory option */
    BINDOPT_BROADCAST_ADDR,     /**< dataType:(char *), broadcast ip address, @b mandatory option */
    BINDOPT_COAP_PORT,          /**< dataType:(uint16_t *), destination port of coap notify, default = 5683 */
    BINDOPT_MAC_ADDR,           /**< dataType:(uint8_t *), arrayLen = 6 bytes, mac address */
    BINDOPT_TOKEN_INPUT,        /**< dataType:(uint8_t *), stringLen = 32 bytes, token string */
    BINDOPT_TOKEN_TTL,          /**< dataType:(uint32_t *), token time to live, unit = ms, default = 60000ms */
    BINDOPT_NOTIFY_CNT,         /**< dataType:(uint16_t *), token notify count, default = 5 */
    BINDOPT_NOTIFY_INTERVAL,    /**< dataType:(uint32_t *), token notify interval, unit = ms, default = 1500ms */
    BINDOPT_EVENT_CB,           /**< dataType:(aiot_bind_event_handler_t), pointer to bind event handler function */
    BINDOPT_EXT_MQTT_API,       /**< dataType:(aiot_bind_ext_mqtt_api_t *), external mqtt sub api and pub api */
    BINDOPT_MAX
} aiot_bind_option_t;

/**
 * @brief initializes the bind module
 *
 * @return void*
 * @reval NotNULL handle of bind module
 * @reval NULL initializes failed, system callbacks not complete or malloc failed.
 *
 * @brief
 * @brief --------------------------------------------------
 *
 * @brief 初始化绑定模块
 *
 * @return void*
 * @reval NotNULL 绑定模块句柄
 * @reval NULL 初始化失败, 系统回调不完整或者内存分配失败.
 *
 */
void *aiot_bind_init(void);

/**
 * @brief set option of bind moduel
 *
 * @param[in] handle handle of bind module
 * @param[in] option the configuration option, see @ref aiot_bind_option_t
 * @param[in] data   the configuration data, see @ref aiot_bind_option_t
 *
 * @return int32_t
 * @retval ERRCODE_SUCCESS set option successfully
 * @retval <ERRCODE_SUCCESS set option failed
 *
 * @brief
 * @brief --------------------------------------------------
 *
 * @brief 配置绑定模块选项
 *
 * @param[in] handle 绑定模块句柄
 * @param[in] option 配置选项, 查看 @ref aiot_bind_option_t
 * @param[in] data   配置数据, 查看 @ref aiot_bind_option_t
 *
 * @return int32_t
 * @retval ERRCODE_SUCCESS 配置成功
 * @retval <ERRCODE_SUCCESS 配置失败
 */
int32_t aiot_bind_setopt(void *handle, aiot_bind_option_t option, void *data);

/**
 * @brief bind process routine
 *
 * @param[in] handle handle of bind module
 *
 * @return int32_t
 * @retval ERRCODE_INVALID_PARAMETER parameter handle is NULL
 * @retval ERRCODE_MISSING_MADANTORY_OPTION missing madantory option, include mqtt_handle, coap_handle, product_key, device_name, ip_address and broadcoast_address
 * @retval ERRCODE_SUCCESS execute successfully
 *
 * @note this api should be polled in main funciton or invoked in independent thread
 *
 * @brief
 * @brief --------------------------------------------------
 *
 * @brief 绑定处理函数
 *
 * @param[in] handle 绑定模块句柄
 *
 * @return int32_t
 * @retval ERRCODE_INVALID_PARAMETER parameter 句柄为NULL
 * @retval ERRCODE_MISSING_MADANTORY_OPTION 丢失强制性选项, 强制性选项包括了mqtt句柄, coap句柄, product_key, device_name, 本地IP地址和广播IP地址
 * @retval ERRCODE_SUCCESS 执行成功
 *
 * @note 用户应该在main中轮询此函数或者在独立线程中调用此函数，函数调用间隔时间必须小于BINDOPT_NOTIFY_INTERVAL/2.
 *
 */
int32_t aiot_bind_process(void *handle);

/**
 * @brief release resource of bind module
 *
 * @param[in] handle the pointer to the bind handle
 *
 * @return int32_t
 * @retval ERRCODE_SUCCESS execute success
 * @retval ERRCODE_INVALID_PARAMETER handle is NULL or the content of handle is NULL
 *
 * @brief
 * @brief --------------------------------------------------
 *
 * @brief 释放bind句柄的资源
 *
 * @param[in] handle 指向绑定句柄的指针
 *
 * @return int32_t
 * @retval ERRCODE_SUCCESS 执行成功
 * @retval ERRCODE_INVALID_PARAMETER handle为NULL或者handle的值为NULL
 *
 */
int32_t aiot_bind_deinit(void **handle);

#if defined(__cplusplus)
}
#endif
#endif /* #ifndef _AIOT_BIND_API_H_ */