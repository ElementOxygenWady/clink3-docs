/**
 * @file aiot_mqtt_api.h
 * @brief mqtt module api header file
 * @version 0.1
 * @date 2019-05-04
 *
 * @copyright Copyright (C) 2015-2018 Alibaba Group Holding Limited
 *
 */

#ifndef _AIOT_MQTT_API_H_
#define _AIOT_MQTT_API_H_

#if defined(__cplusplus)
extern "C" {
#endif

#include <stdio.h>
#include <stdint.h>

/**
 * @brief mqtt options for @ref aiot_mqtt_setopt function.the data type below indicate data param in @ref aiot_mqtt_setopt
 * @brief
 * @brief --------------------------------------------------
 * @brief @ref aiot_mqtt_setopt 函数的option参数。下文每一个选项中的数据类型指的是@ref aiot_mqtt_setopt 中的data参数。
 */
typedef enum {
    /**
     * if domain name or ip address used to connect mqtt broker,
     * the domain name resolution must be performed in @ref SYSCB_NWK_ESTABLISH callback if using domain name.
     *
     * Aliyun LinkPlatform domain name list (${pk} must be replaced with your own product key):
     *
     * |                   domian name                   |  region   |
     * |-------------------------------------------------|-----------|
     * | ${pk}.iot-as-mqtt.cn-shanghai.aliyuncs.com      | Shanghai  |
     * | ${pk}.iot-as-mqtt.ap-southeast-1.aliyuncs.com   | Singapore |
     * | ${pk}.iot-as-mqtt.ap-northeast-1.aliyuncs.com   | Japan     |
     * | ${pk}.iot-as-mqtt.us-west-1.aliyuncs.com        | America   |
     * | ${pk}.iot-as-mqtt.eu-central-1.aliyuncs.com     | Germany   |
     *
     *
     * data type: (char *)
     *
     * --------------------------------------------------
     *
     * mqtt broker的域名地址或者ip地址
     *
     * 如果使用的是域名地址，那么在@ref SYSCB_NWK_ESTABLISH回调函数中必须进行域名解析
     *
     * 阿里云LinkPlatform域名地址列表(必须使用自己的product key替换${pk})：
     *
     * |                      域名地址                    |    区域    |
     * |------------------------------------------------ |-----------|
     * | ${pk}.iot-as-mqtt.cn-shanghai.aliyuncs.com      | 上海       |
     * | ${pk}.iot-as-mqtt.ap-southeast-1.aliyuncs.com   | 新加坡     |
     * | ${pk}.iot-as-mqtt.ap-northeast-1.aliyuncs.com   | 日本       |
     * | ${pk}.iot-as-mqtt.us-west-1.aliyuncs.com        | 美西       |
     * | ${pk}.iot-as-mqtt.eu-central-1.aliyuncs.com     | 德国       |
     *
     * 数据类型：(char *)
     */
    MQTTOPT_HOST,
    /**
     * the port used to connect mqtt broker is 1883 without TLS and 443 with TLS
     *
     * data type: (uint16_t *)
     *
     * --------------------------------------------------
     *
     * 连接mqtt broker使用的端口号\n
     * 如果使用TLS连接，那么端口号为443\n
     * 如果使用TCP连接，那么端口号为1883\n
     * \n
     * 数据类型：(uint16_t *)
     */
    MQTTOPT_PORT,
    /**
     * security level for mqtt connection\n
     * \n
     * data type: (uint8_t *)
     * 
     * value:\n
     * 0 - using mqtt without security\n
     * in this situation, the @ref NWKOPT_SECURITY option of @ref nwk_setopt_t will be set to 0\n
     * 
     * 1 - using mqtt with security\n
     * in this situation, the @ref NWKOPT_SECURITY option of @ref nwk_setopt_t will be set to 1\n
     * \n
     * note: \n
     * 1. when using @ref aiot_mqtt_dynreg to get device secret, this option must be set to 1.\n
     * 2. when using @ref aiot_mqtt_preauth to get fastest mqtt broker informaion, this option must be set ot 1.
     * 
     * --------------------------------------------------
     * 
     * mqtt连接使用的安全级别
     * \n
     * 数据类型：(uint8_t *)
     * 
     * 取值：\n
     * 0 - 使用非安全的mqtt连接\n
     * 在这种情况下，@ref nwk_setopt_t 函数的@ref NWKOPT_SECURITY 选项会被设置为0\n
     * 
     * 1 - 使用安全的mqtt连接\n
     * 在这种情况下，@ref nwk_setopt_t 函数的@ref NWKOPT_SECURITY 选项会被设置为1\n
     * \n
     * 注意：\n
     * 1. 当使用@ref aiot_mqtt_dynreg 获取device secret时，该选项必须被设置为1\n
     * 2. 当使用@ref aiot_mqtt_preauth 获取速度最快的站点时，该选项必须被设置为1
     */
    MQTTOPT_SECURITY,
    /**
     * these domian name is used by @ref aiot_mqtt_preauth , through which mqtt module can choose a\n
     * fastest mqtt broker for you.\n
     * the domain name resolution must be performed in @ref SYSCB_NWK_ESTABLISH callback if using domain name.
     * 
     * pre-auth domain name list
     * 
     * |                domian name             |  region   |
     * |----------------------------------------|-----------|
     * | iot-auth.cn-shanghai.aliyuncs.com      | Shanghai  |
     * | iot-auth.ap-southeast-1.aliyuncs.com   | Singapore |
     * | iot-auth.ap-northeast-1.aliyuncs.com   | Japan     |
     * | iot-auth.us-west-1.aliyuncs.com        | America   |
     * | iot-auth.eu-central-1.aliyuncs.com     | Germany   |
     * 
     * data type: (char *)
     *
     * --------------------------------------------------
     *
     * 这些域名被@ref aiot_mqtt_preauth 函数使用，用于实现预认证功能，主要是为了获取最快的mqtt broker站点信息。
     *
     * 如果使用的是域名地址，那么在@ref SYSCB_NWK_ESTABLISH回调函数中必须进行域名解析
     *
     * 预认证域名列表
     *
     * |                domian name             | 区域    |
     * |----------------------------------------|--------|
     * | iot-auth.cn-shanghai.aliyuncs.com      | 上海    |
     * | iot-auth.ap-southeast-1.aliyuncs.com   | 新加坡  |
     * | iot-auth.ap-northeast-1.aliyuncs.com   | 日本    |
     * | iot-auth.us-west-1.aliyuncs.com        | 美西    |
     * | iot-auth.eu-central-1.aliyuncs.com     | 德国    |
     *
     * 数据类型：(char *)
     */
    MQTTOPT_PREAUTH_HOST,
    MQTTOPT_PRODUCT_KEY,                          /**< data type: (char *)                                     */
    MQTTOPT_DEVICE_NAME,                          /**< data type: (char *)                                     */
    MQTTOPT_DEVICE_SECRET,                        /**< data type: (char *)                                     */
    MQTTOPT_PRODUCT_SECRET,                       /**< data type: (char *)                                     */
    /**
     * mqtt keep alive params, the range is 30 ~ 1200 limited by Aliyun LinkPlatform.
     *
     * if the value less than 30, the connecting will be rejected and @ref aiot_mqtt_connect will
     * return @ref ERRCODE_MQTT_CONNACK_RCODE_SERVER_UNAVAILABLE.
     *
     * if the value greater than 1200, the connection can be established but this config value will be overwrite to 1200 by Aliyun LinkPlatform.
     *
     * data type: (uint16_t *) range: 30 ~ 1200s default: 1200s
     *
     * --------------------------------------------------
     *
     * mqtt keep alive参数，受阿里云Link Platform限制，取值范围为30 ~ 1200s。
     *
     * 如果设置的值小于30，mqtt连接会被云端拒绝，@ref aiot_mqtt_connect函数会返回@ref ERRCODE_MQTT_CONNACK_RCODE_SERVER_UNAVAILABLE错误。
     *
     * 如果设置的值大于1200，mqtt连接仍然可以建立，但是此参数会被云端覆写为1200。
     *
     * 数据类型：(uint16_t *) 取值范围：30 ~ 1200s 默认值：1200s
     */
    MQTTOPT_KEEPALIVE_S,
    /**
     * mqtt PINGREQ packet send interval time(ms). this value should be less than @ref MQTTOPT_KEEPALIVE_S * 1000
     * for staying online. @ref aiot_mqtt_process will send this mqtt PINGREQ packet
     * 
     * data type: (uint32_t *) default: 25 * 1000ms
     * 
     * --------------------------------------------------
     * 
     * mqtt PINGREQ报文发送间隔，该间隔应当小于@ref MQTTOPT_KEEPALIVE_S * 1000，以确保设备的在线状态。
     * @ref aiot_mqtt_process 会发送此mqtt PINGREQ报文。
     * 
     * 数据类型：(uint32_t *) 默认值：25 * 1000ms
     */
    MQTTOPT_HEARTBEAT_INTERVAL_MS,
    /**
     * mqtt reconnect caused by mqtt PINGRESP packet missing times. when mqtt send PINGREQ packet in every 
     * @ref MQTTOPT_HEARTBEAT_INTERVAL_MS times, mqtt PINGRESP packet should be received. if received times exceed
     * this missing times, @ref aiot_mqtt_recv will execute reconnect.
     * 
     * data type: (uint8_t *) default: 2
     * 
     * --------------------------------------------------
     * 
     * 此配置为mqtt PINGRESP报文丢失次数最大值。当mqtt PINGREQ报文在每@ref MQTTOPT_HEARTBEAT_INTERVAL_MS 时间内发送后，
     * 都应当收到mqtt PINGRESP报文。若mqtt PINGRESP报文丢失次数超过此最大值，将会在@ref aiot_mqtt_recv 中触发重连。
     * 
     * 数据类型：(uint8_t *) 默认值：2
     */
    MQTTOPT_HEARTBEAT_MAX_MISSING_TIMES,
    MQTTOPT_SEND_TIMEOUT_MS,                   /**< data type: (uint32_t *) default: 5000ms                 */
    MQTTOPT_RECV_TIMEOUT_MS,                   /**< data type: (uint32_t *) default: 5000ms                 */
    /**
     * after sending qos1 mqtt PUBLISH packet,
     * if can not receive PUBACK packet before MQTTOPT_REPUB_TIMEOUT_MS,
     * @ref aiot_mqtt_process will resend this mqtt PUBLISH packet, until receive PUBACK packet
     *
     * data type: (uint32_t *) default: 2000ms
     *
     * --------------------------------------------------
     *
     * 当发送qos1 mqtt PUBLISH报文后，如果在MQTTOPT_REPUB_TIMEOUT_MS时间内未收到mqtt PUBACK报文，
     * @ref aiot_mqtt_repub会重新发送此qo1 mqtt PUBLISH报文，直到收到PUBACK报文为止。
     *
     * 数据类型：(uint32_t *) 默认值: 2000ms
     */
    MQTTOPT_REPUB_TIMEOUT_MS,
    /**
     * reconnect strategy:
     *
     * 0: try to reconnect every "MQTTOPT_RECONNECT_BASE_MS" ms.
     *
     *    ex: MQTTOPT_RECONNECT_BASE_MS, MQTTOPT_RECONNECT_BASE_MS, MQTTOPT_RECONNECT_BASE_MS...
     *
     * 1: try to reconnect multiply based on "MQTTOPT_RECONNECT_BASE_MS" ms, retry times on each rank.
     *    if max retry interval exceed MQTTOPT_RECONNECT_STGY1_MAX_MS, this strategy will be reset.
     *
     *    ex: MQTTOPT_RECONNECT_BASE_MS, MQTTOPT_RECONNECT_BASE_MS*2, MQTTOPT_RECONNECT_BASE_MS*4...
     *
     * data type: (uint8_t *)  default: 0
     *
     * --------------------------------------------------
     *
     * 重连策略：
     *
     * 0：每隔MQTTOPT_RECONNECT_BASE_MS毫秒尝试进行重连
     *
     *    例：MQTTOPT_RECONNECT_BASE_MS, MQTTOPT_RECONNECT_BASE_MS, MQTTOPT_RECONNECT_BASE_MS...
     *
     * 1：以MQTTOPT_RECONNECT_BASE_MS乘以2的倍数为间隔尝试进行重连，可通过MQTTOPT_RECONNECT_STGY1_RETRY_PERRANK设置
     *    在每个倍数上重试的次数。MQTTOPT_RECONNECT_STGY1_MAX_MS指定最大不能超过的重连时间间隔，超过该值后，倍数重置为1
     *
     *    例: MQTTOPT_RECONNECT_BASE_MS, MQTTOPT_RECONNECT_BASE_MS*2, MQTTOPT_RECONNECT_BASE_MS*4...
     *
     * 数据类型: (uint8_t *)  默认值: 0
     */
    MQTTOPT_RECONNECT_STRATEGY,
    MQTTOPT_RECONNECT_BASE_MS,                 /**< type: (uint32_t *) default: 2000ms               */
    MQTTOPT_RECONNECT_STGY1_RETRY_PERRANK,     /**< type: (uint32_t *) default: 3                    */
    MQTTOPT_RECONNECT_STGY1_MAX_MS,            /**< type: (uint32_t *) default: 30 * 60 * 1000ms     */
    MQTTOPT_DATAPKT_HANDLE,                    /**< type: (aiot_mqtt_datapkt_handle_t)               */
    MQTTOPT_CTRLPKT_HANDLE,                    /**< type: (aiot_mqtt_ctrlpkt_handle_t)               */
    MQTTOPT_USERDATA,                          /**< type: (void* ) userdata for current connection   */
    MQTTOPT_MAX
} aiot_mqtt_option_t;

/**
 * @brief mqtt data packet struct.
 * @brief
 * @brief --------------------------------------------------
 * @brief mqtt PUBLISH报文使用的数据结构
 */
typedef struct {
    /**
     * qos level for mqtt PUBLISH packet, support qos0 and qos1
     *
     * value: 0x00 or 0x01
     *
     * mqtt PUBLISH报文使用的qos级别，支持qos0和qos1
     *
     * 取值：0x00 或0x01
     */
    uint8_t qos;
    char *topic;
    uint16_t topic_len;
    uint8_t *payload;
    uint32_t payload_len;
} aiot_mqtt_datapkt_t;

/**
 * @brief called when mqtt PUBLISH packet received from mqtt broker.
 * @brief
 * @brief --------------------------------------------------
 * @brief 当mqtt PUBLISH报文到达时，该回调函数被调用
 */
typedef void (*aiot_mqtt_datapkt_handle_t)(void *handle, aiot_mqtt_datapkt_t *packet, void *userdata);

/**
 * @brief mqtt control packet type.
 * @brief
 * @brief --------------------------------------------------
 * @brief mqtt控制类报文类型
 */
typedef enum {
    /**
     * mqtt PINGRESP packet type
     *
     * --------------------------------------------------
     *
     * mqtt PINGRESP报文类型
     */
    MQTTCTRL_HEARTBEAT_RESPONSE,
    /**
     * mqtt SUBACK packet type
     *
     * --------------------------------------------------
     *
     * mqtt SUBACK报文类型
     */
    MQTTCTRL_SUB_RESPONSE,
    /**
     * mqtt UNSUBACK packet type
     *
     * --------------------------------------------------
     *
     * mqtt UNSUBACK报文类型
     */
    MQTTCTRL_UNSUB_RESPONSE,
    /**
     * mqtt PUBACK packet type
     *
     * --------------------------------------------------
     *
     * mqtt PUBACK报文类型
     */
    MQTTCTRL_PUB_RESPONSE
} aiot_mqtt_ctrltype_t;

/**
 * @brief mqtt control packet type struct.
 * @brief
 * @brief --------------------------------------------------
 * @brief mqtt控制类报文数据结构
 */
typedef struct {
    /**
     * see @ref aiot_mqtt_ctrltype_t for more information
     *
     * --------------------------------------------------
     *
     * 更多信息请参考@ref aiot_mqtt_ctrltype_t
     */
    aiot_mqtt_ctrltype_t ctrltype;
    union {
        struct sub_resp {
            int32_t res;
            uint8_t max_qos;
            uint16_t packet_id;
        } sub_resp_data;
        struct unsub_resp {
            uint16_t packet_id;
        } unsub_resp_data;
        struct pub_resp {
            uint16_t packet_id;
        } pub_resp_data;
    } data;
} aiot_mqtt_ctrlpkt_t;

/**
 * @brief called when mqtt control packet(PINGRESP, SUBACK, UNSUBACK and PUBACK) received from mqtt broker.
 * @brief
 * @brief --------------------------------------------------
 * @brief 当mqtt控制类报文到达时（包括PINGRESP，SUBACK，UNSUBACK和PUBACK），该回调函数被调用
 */
typedef void (*aiot_mqtt_ctrlpkt_handle_t)(void *handle, aiot_mqtt_ctrlpkt_t *packet, void *userdata);

/**
 * @brief mqtt subscribe packet struct for @ref aiot_mqtt_sub
 * @brief
 * @brief --------------------------------------------------
 * @brief mqtt订阅报文结构体，用于@ref aiot_mqtt_sub
 */
typedef struct {
    uint8_t qos;
    char *topic;
    uint16_t topic_len;
    /**
     * if is_cb_only equals 0, @ref aiot_mqtt_sub will store the ralation between
     * topic and handle, then send mqtt SUBSCRIBE packet.
     * if is_cb_only equals 1, @ref aiot_mqtt_sub will store the ralation between
     * topic and handle only.
     * 
     * --------------------------------------------------
     * 
     * 如果is_cb_only等于0，@ref aiot_mqtt_sub 会存储topic和handle之间的对应关系，并发送
     * mqtt SUBSCRIBE报文。
     * 如果is_cb_only等于1，@ref aiot_mqtt_sub 仅会存储topic和handle之间的对应关系，不会
     * 发送mqtt SUBSCRIBE报文。
     */
    uint8_t is_cb_only;
    /**
     * this data packet handle will be bind to topic specified and is optional.
     * if this handle is NULL, default data packet handle set by @ref MQTTOPT_DATAPKT_HANDLE
     * will be called when message publish received from mqtt broker.
     * 
     * --------------------------------------------------
     * 
     * 该publish报文的回调函数会与参数中的topic进行绑定，并且为可选参数
     * 如果此参数为NULL，那么当接收到云端发送给参数中的topic的publish消息到达时，
     * 通过@ref MQTTOPT_DATAPKT_HANDLE 设置的默认回调函数将会被调用。
     */
    aiot_mqtt_datapkt_handle_t handle;
    void *userdata;
} aiot_mqtt_sub_t;

/**
 * @brief mqtt unsubscribe packet struct for @ref aiot_mqtt_unsub
 * @brief
 * @brief --------------------------------------------------
 * @brief mqtt取消订阅报文结构体，用于@ref aiot_mqtt_unsub
 */
typedef struct {
    char *topic;
    uint16_t topic_len;
    /**
     * if is_cb_only equals 0, @ref aiot_mqtt_sub will delete the ralation between
     * topic and handle, then send mqtt UNSUBSCRIBE packet.
     * if is_cb_only equals 1, @ref aiot_mqtt_sub will delete the ralation between
     * topic and handle only.
     * 
     * --------------------------------------------------
     * 
     * 如果is_cb_only等于0，@ref aiot_mqtt_sub 会删除topic和handle之间的对应关系，并发送
     * mqtt SUBSCRIBE报文。
     * 如果is_cb_only等于1，@ref aiot_mqtt_sub 仅会删除topic和handle之间的对应关系，不会
     * 发送mqtt UNSUBSCRIBE报文。
     */
    uint8_t is_cb_only;
} aiot_mqtt_unsub_t;

/**
 * @brief init mqtt handle and set default parameter.
 *
 * @return void*
 * @retval NotNULL mqtt handle
 * @retval NULL init failed
 *
 * @brief
 * @brief --------------------------------------------------
 *
 * @brief 初始化mqtt句柄并设置默认参数
 *
 * @return void*
 * @retval 非NULL mqtt句柄
 * @retval NULL 初始化失败
 *
 */
void *aiot_mqtt_init(void);


/**
 * @brief set mqtt configuration
 *
 * @param[in] handle the mqtt handle
 * @param[in] option the configuration option, see @ref aiot_mqtt_option_t
 * @param[in] data   the configuration data, see @ref aiot_mqtt_option_t
 *
 * @return int32_t
 * @retval <ERRCODE_SUCCESS set opt failed
 * @retval >=ERRCODE_SUCCESS set opt succeed
 *
 * @brief
 * @brief --------------------------------------------------
 *
 * @brief 设置mqtt参数
 *
 * @param[in] handle mqtt句柄
 * @param[in] option 配置选项, 更多信息请参考@ref aiot_mqtt_option_t
 * @param[in] data   配置选项数据，更多信息请参考@ref aiot_mqtt_option_t
 *
 * @return int32_t
 * @retval <ERRCODE_SUCCESS 参数设置失败
 * @retval >=ERRCODE_SUCCESS 参数设置成功
 *
 */
int32_t aiot_mqtt_setopt(void *handle, aiot_mqtt_option_t option, void *data);

/**
 * @brief mqtt dynamic register, get device secret from cloud using product key, device name\n
 *        and product secret
 *
 * @param[in] handle the mqtt handle
 * @param[out] device_secret the buffer to store device secret
 * @param[out] device_secret_len the length of device_secret
 * 
 * @return int32_t
 * @retval <ERRCODE_SUCCESS get device secret failed
 * @retval >=ERRCODE_SUCCESS get device secret succeed
 *
 * @note @ref sys_rand_t system callback must be set, and security option must be set to 1 for security reason\n
 *       when this function return success, device secret will be stored internally, @ref aiot_mqtt_connect can\n
 *       be used to establish mqtt connection directly without calling @ref aiot_mqtt_setopt to set @ref MQTTOPT_DEVICE_SECRET
 * 
 * @brief
 * @brief --------------------------------------------------
 *
 * @brief mqtt动态注册，使用product key，device name和product secret从服务器获取device secret
 *
 * @param[in] handle mqtt句柄
 * @param[out] device_secret 用来存放device secret的buffer
 * @param[out] device_secret_len 用来存放device secret的buffer长度
 * 
 * @return int32_t
 * @retval <ERRCODE_SUCCESS 获取设备device secret失败
 * @retval >=ERRCODE_SUCCESS 获取设备device secret成功
 * 
 * @note 从安全角度考虑，@ref sys_rand_t 系统回调函数必须设置，@ref MQTTOPT_SECURITY 选项必须设置为1\n
 *       当该函数返回成功时，device secret在mqtt内部也会保存，可以直接调用@ref aiot_mqtt_connect 建立\n
 *       mqtt连接，无需再使用@ref aiot_mqtt_setopt 去设置@ref MQTTOPT_DEVICE_SECRET
 */
int32_t aiot_mqtt_dynreg(void *handle, char *device_secret, uint32_t device_secret_len);

/**
 * @brief pre-auth function, used to get the fastest mqtt broker information.
 * 
 * this function generally used by overseas products and used to get the fastest mqtt broker information.\n
 * before calling this function, @ref MQTTOPT_PRODUCT_KEY , @ref MQTTOPT_DEVICE_NAME and @ref MQTTOPT_DEVICE_SECRET \n
 * must be set.\n
 * \n
 * pre-auth is using https connection now and domain name is set by @ref MQTTOPT_PREAUTH_HOST\n
 * \n
 * after pre-auth success, @ref aiot_mqtt_connect can be called to connect the fastest mqtt broker.\n
 * 
 * @param[in] handle the mqtt handle
 * 
 * @return int32_t
 * @retval <ERRCODE_SUCCESS pre-auth failed
 * @retval >=ERRCODE_SUCCESS pre-auth succeed
 * 
 * @brief
 * @brief --------------------------------------------------
 * 
 * @brief 该函数用于预认证功能，用于获取连接最快的mqtt broker信息。
 * 
 * 该函数一般用于海外产品，用于获取连接最快的mqtt broker信息。\n
 * 在调用该函数之前，@ref MQTTOPT_PRODUCT_KEY ，@ref MQTTOPT_DEVICE_NAME 和@ref MQTTOPT_DEVICE_SECRET \n
 * 必须被设置。\n
 * \n
 * 预认证目前使用的是https连接，域名需要通过@ref MQTTOPT_PREAUTH_HOST 进行设置。\n
 * \n
 * 在预认证成功之后，@ref aiot_mqtt_connect 就可以连接最快的mqtt broker了。
 * 
 * @param[in] handle mqtt句柄
 * 
 * @return int32_t
 * @retval <ERRCODE_SUCCESS 预认证失败
 * @retval >=ERRCODE_SUCCESS 预认证成功
 */ 
int32_t aiot_mqtt_preauth(void *handle);

/**
 * @brief establish mqtt connection to mqtt broker. if mqtt connection has already established,
 *        this function will disconnect first and connect to mqtt broker again.
 *
 * @param[in] handle the mqtt handle
 * 
 * @return int32_t
 * @retval <ERRCODE_SUCCESS establish connection failed
 * @retval >=ERRCODE_SUCCESS establish connection succeed
 *
 * @note if using product key, device name and device secret to establish mqtt connection,\n
 *       @ref MQTTOPT_PRODUCT_KEY, @ref MQTTOPT_DEVICE_NAME and @ref MQTTOPT_DEVICE_SECRET\n
 *       must be set using @ref aiot_mqtt_setopt, then @ref aiot_mqtt_connect can be used\n
 *       to establish mqtt connection \n
 *       \n
 *       if using product key, device name and product secret to establish mqtt connection,\n
 *       @ref MQTTOPT_PRODUCT_KEY, @ref MQTTOPT_DEVICE_NAME and @ref MQTTOPT_PRODUCT_SECRET\n
 *       must be set using @ref aiot_mqtt_setopt, and @ref aiot_mqtt_dynreg must be called first\n
 *       to get device secret, then @ref aiot_mqtt_connect can be used to establish mqtt connection
 * 
 * @brief
 * @brief --------------------------------------------------
 *
 * @brief 与mqtt broker建立mqtt连接。如果此时mqtt连接已建立，该函数会先断开连接，并尝试重新连接。
 *
 * @param[in] handle mqtt句柄
 * 
 * @return int32_t
 * @retval <ERRCODE_SUCCESS 建联失败
 * @retval >=ERRCODE_SUCCESS 建联成功
 *
 * @note 如果使用product key，device name和device secret建立mqtt连接，那么\n
 *       @ref MQTTOPT_PRODUCT_KEY ，@ref MQTTOPT_DEVICE_NAME 和@ref MQTTOPT_DEVICE_SECRET\n
 *       必须使用@ref aiot_mqtt_setopt 进行设置，然后调用@ref aiot_mqtt_connect 建立mqtt连接\n
 *       \n
 *       如果使用product key，device name和product secret建立mqtt连接,那么\n
 *       @ref MQTTOPT_PRODUCT_KEY ，@ref MQTTOPT_DEVICE_NAME 和@ref MQTTOPT_PRODUCT_SECRET\n
 *       必须使用@ref aiot_mqtt_setopt 进行设置，然后首先调用一次@ref aiot_mqtt_dynreg 来获取\n
 *       device secret，之后再调用@ref aiot_mqtt_connect 建立mqtt连接
 * 
 */
int32_t aiot_mqtt_connect(void *handle);

/**
 * @brief disconnect mqtt connection with mqtt broker
 *
 * @param[in] handle the pointer to the mqtt handle
 *
 * @return int32_t
 * @retval <ERRCODE_SUCCESS execute failed
 * @retval >=ERRCODE_SUCCESS execute succeed
 *
 * @brief
 * @brief --------------------------------------------------
 *
 * @brief 断开与mqtt broker的连接
 *
 * @param[in] handle 指向mqtt句柄的指针
 *
 * @return int32_t
 * @retval <ERRCODE_SUCCESS 执行失败
 * @retval >=ERRCODE_SUCCESS 执行成功
 *
 */
int32_t aiot_mqtt_disconnect(void *handle);

/**
 * @brief free memory for mqtt handle
 *
 * @param[in] handle the pointer to the mqtt handle
 *
 * @return int32_t
 * @retval <ERRCODE_SUCCESS execute failed
 * @retval >=ERRCODE_SUCCESS execute succeed
 *
 * @brief
 * @brief --------------------------------------------------
 *
 * @brief 释放mqtt句柄的资源
 *
 * @param[in] handle 指向mqtt句柄的指针
 *
 * @return int32_t
 * @retval <ERRCODE_SUCCESS 执行失败
 * @retval >=ERRCODE_SUCCESS 执行成功
 *
 */
int32_t aiot_mqtt_deinit(void **handle);

/**
 * @brief this function used to handle heartbeat send and qos1 message re-publish logic.
 * 
 * 1. send heartbeat to mqtt broker for keeping alive, the heartbeat send interval controlled by @ref MQTTOPT_HEARTBEAT_INTERVAL_MS\n
 * 2. if a sending qos1 PUBLISH packet can not receive a mqtt PUBACK packet before @ref MQTTOPT_REPUB_TIMEOUT_MS, \n
 *    this qos1 PUBLISH packet will be resend until succeed.
 * 
 * @param[in] handle the mqtt handle
 * 
 * @return int32_t 
 * @retval <ERRCODE_SUCCESS some error occur, see @ref aiot_errno.h for more information
 * @retval >=ERRCODE_SUCCESS execute success
 * 
 * @note this function is non-block and should be called intermittently. the interval timeout this function be called should be less than\n
 *       the minimum time between @ref MQTTOPT_HEARTBEAT_INTERVAL_MS and @ref MQTTOPT_REPUB_TIMEOUT_MS to ensure heartbeat send and qos1\n
 *       message re-publish logic work properly.
 * 
 * @brief
 * @brief --------------------------------------------------
 * 
 * @brief 此函数用于处理心跳发送和qos1消息的重传逻辑。
 * 
 * 1. 发送心跳至mqtt broker以维护mqtt连接，心跳发送间隔由@ref MQTTOPT_HEARTBEAT_INTERVAL_MS 参数控制\n
 * 2. 如果一条qos1的mqtt PUBLISH报文在@ref MQTTOPT_REPUB_TIMEOUT_MS时间内没有收到mqtt PUBACK应答报文，该函数会重发此消息，直到成功为止。
 * 
 * @param[in] handle mqtt句柄
 *
 * @return int32_t
 * @retval <ERRCODE_SUCCESS 执行过程发生错误，更多信息请参考@ref aiot_errno.h
 * @retval >=ERRCODE_SUCCESS 执行成功
 * 
 * @note 该函数为非阻塞，需要间歇性被调用，调用间隔应当小于@ref MQTTOPT_HEARTBEAT_INTERVAL_MS和@ref MQTTOPT_REPUB_TIMEOUT_MS的最小值，\n
 *       以确保心跳发送和qos1消息的重传逻辑正常工作
 */
int32_t aiot_mqtt_process(void *handle);

/**
 * @brief send a mqtt PUBLISH packet to mqtt broker.
 *
 * @param[in] handle the mqtt handle
 * @param[in] packet the content of mqtt PUBLISH packet, see @ref aiot_mqtt_datapkt_t for more information
 *
 * @return int32_t
 * @retval <ERRCODE_SUCCESS send failed
 * @retval >=ERRCODE_SUCCESS send succeed (for qos0, return ERRCODE_SUCCESS, for qos1, return packet id)
 *
 * @brief
 * @brief --------------------------------------------------
 *
 * @brief 发送一条mqtt PUBLISH报文到mqtt broker
 *
 * @param[in] handle mqtt句柄
 * @param[in] packet mqtt PUBLISH报文内容，更多信息请参考@ref aiot_mqtt_datapkt_t
 *
 * @return int32_t
 * @retval <ERRCODE_SUCCESS 发送失败
 * @retval >=ERRCODE_SUCCESS 发送成功 (发送qos0消息时，返回ERRCODE_SUCCESS；发送qos1消息时，返回packet id)
 *
 */
int32_t aiot_mqtt_pub(void *handle, aiot_mqtt_datapkt_t *packet);

/**
 * @brief send a mqtt SUBSCRIBE packet to mqtt broker.
 *
 * @param[in] handle the mqtt handle
 * @param[in] sub the parameter of mqtt SUBSCRIBE packet, see @ref aiot_mqtt_sub_t for more information
 *
 * @return int32_t
 * @retval <ERRCODE_SUCCESS send failed
 * @retval >ERRCODE_SUCCESS send succeed, return packet id
 *
 * @brief
 * @brief --------------------------------------------------
 *
 * @brief 发送一条mqtt SUBSCRIBE报文到mqtt broker
 *
 * @param[in] handle mqtt句柄
 * @param[in] sub mqtt SUBSCRIBE报文相关参数，更多信息请参考@ref aiot_mqtt_sub_t
 *
 * @return int32_t
 * @retval <ERRCODE_SUCCESS 发送失败
 * @retval >=ERRCODE_SUCCESS 发送成功，并返回packet id
 *
 */
int32_t aiot_mqtt_sub(void *handle, aiot_mqtt_sub_t *sub);

/**
 * @brief send a mqtt UNSUBSCRIBE packet to mqtt broker.
 *
 * @param[in] handle the mqtt handle
 * @param[in] unsub the parameter of mqtt UNSUBSCRIBE packet, see @ref aiot_mqtt_unsub_t for more information
 *
 * @return int32_t
 * @retval <ERRCODE_SUCCESS send failed
 * @retval >ERRCODE_SUCCESS send succeed, return packet id
 *
 * @brief
 * @brief --------------------------------------------------
 *
 * @brief 发送一条mqtt UNSUBSCRIBE报文到mqtt broker
 *
 * @param[in] handle mqtt句柄
 * @param[in] unsub mqtt UNSUBSCRIBE报文相关参数，更多信息请参考@ref aiot_mqtt_unsub_t
 *
 * @return int32_t
 * @retval <ERRCODE_SUCCESS 发送失败
 * @retval >=ERRCODE_SUCCESS 发送成功，并返回packet id
 *
 */
int32_t aiot_mqtt_unsub(void *handle, aiot_mqtt_unsub_t *unsub);

/**
 * @brief try to receive mqtt packet and reconnect to mqtt broker.
 *        see @ref MQTTOPT_RECONNECT_STRATEGY for more information about reconnect machansim
 *
 * @param[in] handle the mqtt handle
 * @return int32_t
 *
 * @retval <ERRCODE_SUCCESS execute failed
 * @retval >ERRCODE_SUCCESS execute succeed
 *
 * @brief
 * @brief --------------------------------------------------
 *
 * @brief 尝试收取mqtt报文并且该函数中包含重连机制。
 *        更多重连机制的信息请参考@ref MQTTOPT_RECONNECT_STRATEGY
 *
 * @param[in] handle mqtt句柄
 *
 * @return int32_t
 * @retval <ERRCODE_SUCCESS 执行成功
 * @retval >=ERRCODE_SUCCESS 执行失败
 *
 */
int32_t aiot_mqtt_recv(void *handle);

#if defined(__cplusplus)
}
#endif
#endif