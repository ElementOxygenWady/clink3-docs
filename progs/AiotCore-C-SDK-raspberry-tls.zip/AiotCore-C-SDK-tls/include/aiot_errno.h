/**
 * @file aiot_errno.h
 * @brief error number for whole sdk
 * @version 0.1
 * @date 2019-05-05
 *
 * @copyright Copyright (C) 2015-2018 Alibaba Group Holding Limited
 *
 */

#ifndef _AIOT_ERRNO_H_
#define _AIOT_ERRNO_H_

#if defined(__cplusplus)
extern "C" {
#endif

#include <stdio.h>
#include <stdint.h>

#define ERRCODE_BASE                                                   (0x0000)

/**
 * operation success
 *
 * --------------------------------------------------
 *
 * 操作成功
 */
#define ERRCODE_SUCCESS                                                (ERRCODE_BASE - 0x0000)

#define ERRCODE_FAIL                                                   (ERRCODE_BASE - 0x0001)
#define ERRCODE_INVALID_PARAMETER                                      (ERRCODE_BASE - 0x0002)
#define ERRCODE_MISSING_MADANTORY_OPTION                               (ERRCODE_BASE - 0x0003)
#define ERRCODE_MEM_MALLOC_FAILED                                      (ERRCODE_BASE - 0x0004)
#define ERRCODE_INVALID_OPTION                                         (ERRCODE_BASE - 0x0005)
#define ERRCODE_INVALID_SECURE_MODE                                    (ERRCODE_BASE - 0x0006)

#define ERRCODE_UTILS_BASE                                             (-0x0100)
#define ERRCODE_UTILS_UINTSTR_INVALID                                  (ERRCODE_UTILS_BASE - 0x0000)

#define ERRCODE_SYS_BASE                                               (-0x0200)
#define ERRCODE_SYS_MISSING_SYSCB                                      (ERRCODE_SYS_BASE - 0x0000)
#define ERRCODE_SYS_MISSING_SYSCB_RAND                                 (ERRCODE_SYS_BASE - 0x0001)
#define ERRCODE_SYS_NWKOPEN_FAILED                                     (ERRCODE_SYS_BASE - 0x0002)
#define ERRCODE_SYS_NWK_CLOSED                                         (ERRCODE_SYS_BASE - 0x0003)
#define ERRCODE_SYS_NWKREAD_LESS_DATA                                  (ERRCODE_SYS_BASE - 0x0004)
#define ERRCODE_SYS_NWKWRITE_LESS_DATA                                 (ERRCODE_SYS_BASE - 0x0005)

#define ERRCODE_MQTT_BASE                                              (-0x0300)
#define ERRCODE_MQTT_CONNPKTLEN_ERROR                                  (ERRCODE_MQTT_BASE - 0x0000)
#define ERRCODE_MQTT_CONNACK_FMT_ERROR                                 (ERRCODE_MQTT_BASE - 0x0001)
#define ERRCODE_MQTT_CONNACK_RCODE_UNACCEPTABLE_PROTOCOL_VERSION       (ERRCODE_MQTT_BASE - 0x0002)
#define ERRCODE_MQTT_CONNACK_RCODE_SERVER_UNAVAILABLE                  (ERRCODE_MQTT_BASE - 0x0003)
#define ERRCODE_MQTT_CONNACK_RCODE_BAD_USERNAME_PASSWORD               (ERRCODE_MQTT_BASE - 0x0004)
#define ERRCODE_MQTT_CONNACK_RCODE_NOT_AUTHORIZED                      (ERRCODE_MQTT_BASE - 0x0005)
#define ERRCODE_MQTT_CONNACK_RCODE_UNKNOWN                             (ERRCODE_MQTT_BASE - 0x0006)

/**
 * 1. MQTT CONN packet format error\n
 * 2. dynamic register uses tcp connection
 */
#define ERRCODE_MQTT_DYNREG_CONNACK_RCODE_IDENTIFIER_REJECTED          (ERRCODE_MQTT_BASE - 0x0007)

/**
 * server error
 */
#define ERRCODE_MQTT_DYNREG_CONNACK_RCODE_SERVER_UNAVAILABLE           (ERRCODE_MQTT_BASE - 0x0008)

/**
 * authentication faied, maybe caused by wrong product key, device name or product secret
 */
#define ERRCODE_MQTT_DYNREG_CONNACK_RCODE_BAD_USERNAME_PASSWORD        (ERRCODE_MQTT_BASE - 0x0009)

#define ERRCODE_MQTT_DYNREG_TIMEOUT                                    (ERRCODE_MQTT_BASE - 0x000A)
#define ERRCODE_DYNREG_RECEIVE_WRONG_PAYLOAD                           (ERRCODE_MQTT_BASE - 0x000B)
#define ERRCODE_DYNREG_DEVICE_SECRET_BUFFER_TOO_SHORT                  (ERRCODE_MQTT_BASE - 0x000C)
#define ERRCODE_MQTT_PACKET_TYPE_UNKNOWN                               (ERRCODE_MQTT_BASE - 0x000D)
#define ERRCODE_MQTT_MALFORMED_REMAINING_LEN                           (ERRCODE_MQTT_BASE - 0x000E)
#define ERRCODE_MQTT_SUBACK_RCODE_FAILURE                              (ERRCODE_MQTT_BASE - 0x000F)
#define ERRCODE_MQTT_SUBACK_RCODE_UNKNOWN                              (ERRCODE_MQTT_BASE - 0x0010)
#define ERRCODE_MQTT_PUBLIST_PACKET_ID_ROLL                            (ERRCODE_MQTT_BASE - 0x0011)
#define ERRCODE_MQTT_PUBLIST_NOT_FOUND                                 (ERRCODE_MQTT_BASE - 0x0012)
#define ERRCODE_MQTT_SUSCRIBE_INVALID_TOPIC                            (ERRCODE_MQTT_BASE - 0x0013)
#define ERRCODE_MQTT_MISSING_MANDATORY_OPTION                          (ERRCODE_MQTT_BASE - 0x0014)
#define ERRCODE_PREAUTH_RECEIVE_WRONG_PAYLOAD                          (ERRCODE_MQTT_BASE - 0x0015)
#define ERRCODE_MQTT_CONNECT_SUCCESS                                   (ERRCODE_MQTT_BASE - 0x0016)

#define ERRCODE_WIFI_BASE                                              (-0x0400)
#define ERRCODE_WIFI_STATE_IDLE                                        (ERRCODE_WIFI_BASE - 0x0000)
#define ERRCODE_WIFI_PROCESS                                           (ERRCODE_WIFI_BASE - 0x0001)
#define ERRCODE_WIFI_INVALID_RADIOTAP                                  (ERRCODE_WIFI_BASE - 0x0002)
#define ERRCODE_WIFI_INVALID_AVS                                       (ERRCODE_WIFI_BASE - 0x0003)
#define ERRCODE_WIFI_INVALID_PRISM                                     (ERRCODE_WIFI_BASE - 0x0004)
#define ERRCODE_WIFI_INVALID_FRAME                                     (ERRCODE_WIFI_BASE - 0x0005)
#define ERRCODE_WIFI_DISCARD_FRAME                                     (ERRCODE_WIFI_BASE - 0x0006)
#define ERRCODE_WIFI_FRAME_INVALID_FCS                                 (ERRCODE_WIFI_BASE - 0x0007)
#define ERRCODE_WIFI_SWITCH_MODE_CB_NOT_SET                            (ERRCODE_WIFI_BASE - 0x0008)
#define ERRCODE_WIFI_CONNECT_AP_CB_NOT_SET                             (ERRCODE_WIFI_BASE - 0x0009)
#define ERRCODE_WIFI_SWITCH_CHANNEL_CB_NOT_SET                         (ERRCODE_WIFI_BASE - 0x000A)
#define ERRCODE_WIFI_FRAME_SEND_CB_NOT_SET                             (ERRCODE_WIFI_BASE - 0x000B)
#define ERRCODE_WIFI_NO_WIFI_PROVISION_CHOOSED                         (ERRCODE_WIFI_BASE - 0x000C)
#define ERRCODE_WIFI_PASSWD_DECRYPT_FAILED                             (ERRCODE_WIFI_BASE - 0x000D)
#define ERRCODE_WIFI_COAP_INIT_ERROR                                   (ERRCODE_WIFI_BASE - 0x000E)
#define ERRCODE_WIFI_STATE_ERROR                                       (ERRCODE_WIFI_BASE - 0x000F)
#define ERRCODE_WIFI_CONN_AP_NOTIFY_FAILED                             (ERRCODE_WIFI_BASE - 0x0010)

#define ERRCODE_COAP_BASE                                              (-0x0500)
#define ERRCODE_COAP_FORMAT_ERROR                                      (ERRCODE_COAP_BASE - 0x0000)
#define ERRCODE_COAP_MSG_LEN_ERROR                                     (ERRCODE_COAP_BASE - 0x0001)
#define ERRCODE_COAP_BUFFER_TOO_SHORT                                  (ERRCODE_COAP_BASE - 0x0002)
#define ERRCODE_COAP_OPT_NOT_IN_ORDER                                  (ERRCODE_COAP_BASE - 0x0003)
#define ERRCODE_COAP_OPTION_CNT_LIMITED                                (ERRCODE_COAP_BASE - 0x0004)
#define ERRCODE_COAP_NWK_SEND_FAILED                                   (ERRCODE_COAP_BASE - 0x0005)
#define ERRCODE_COAP_PROTO_NOT_ALLOW                                   (ERRCODE_COAP_BASE - 0x0006)
#define ERROCDE_COAP_RESOURCE_NOT_EXIST                                (ERRCODE_COAP_BASE - 0x0007)

#define ERRCODE_HTTP_BASE                                              (-0x0600)
#define ERRCODE_HTTP_INVALID_HOST                                      (ERRCODE_HTTP_BASE - 0x0000)
#define ERRCODE_HTTP_INVALID_RESPONSE_HEADER                           (ERRCODE_HTTP_BASE - 0x0001)
#define ERRCODE_HTTP_HEADER_FIELD_MAXLEN_TOO_SHORT                     (ERRCODE_HTTP_BASE - 0x0002)

#define ERRCODE_BIND_BASE                                              (-0x0700)
#define ERRCODE_BIND_FATAL_ERROR                                       (ERRCODE_BIND_BASE - 0x0006)

#define ERRCODE_OTA_BASE                                               (-0x0800)
#define ERRCODE_OTA_DOWNLOAD_START                                     (ERRCODE_OTA_BASE   -0x0000)
#define ERRCODE_OTA_DOWNLOAD_RENEWAL                                   (ERRCODE_OTA_BASE   -0x0001)
#define ERRCODE_OTA_FIRMWARE_VALID_SIGN                                (ERRCODE_OTA_BASE   -0x0002)
#define ERRCODE_OTA_FIRMWARE_INVALID_SIGN                              (ERRCODE_OTA_BASE   -0x0003)
#define ERRCODE_OTA_FIRMWARE_UNKNOWN_SIGN_METHOD                       (ERRCODE_OTA_BASE   -0x0004)
#define ERRCODE_OTA_HTTP_INIT_FAILED                                   (ERRCODE_OTA_BASE   -0x0005)
#define ERRCODE_OTA_DOWNLOAD_STOP                                      (ERRCODE_SUCCESS)

#define ERRCODE_PREAUTH_BASE                                           (-0x0900)
#define ERRCODE_PREAUTH_HTTP_INIT_FAILED                               (ERRCODE_PREAUTH_BASE    -0x0000)

char *aiot_errstr(int32_t err);

#if defined(__cplusplus)
}
#endif
#endif