/**
 * @file aiot_ota_api.h
 * @brief ota module api header file
 * @version 0.1
 * @date 2019-05-26
 * 
 * @copyright Copyright (C) 2015-2018 Alibaba Group Holding Limited
 * 
 */

#ifndef _AIOT_OTA_API_H_
#define _AIOT_OTA_API_H_

#if defined(__cplusplus)
extern "C" {
#endif

#include <stdio.h>
#include <stdint.h>

typedef enum {
    OTAOPT_PRODUCT_KEY,          /**< data type: (char *)                                     */
    OTAOPT_DEVICE_NAME,          /**< data type: (char *)                                     */
    OTAOPT_SECURITY,             /**< data type: (uint8_t *)                                  */
    OTAOPT_MQTT_HANDLE,          /**< data type: (void *)                                     */
    OTAOPT_EVENT_HANDLE,         /**< data type: (aiot_ota_event_t)                           */
    OTAOPT_USERDATA,             /**< type: (void* ) userdata for current connection          */
    OTAOPT_DOWNLOAD_FRIMWARE,    /**< data type: (aiot_ota_firmware_t)                        */
    OTAOPT_SEND_TIMEOUT_MS,      /**< data type: (uint32_t *) default: 5000ms                 */
    OTAOPT_RECV_TIMEOUT_MS,      /**< data type: (uint32_t *) default: 5000ms                 */
    OTAOPT_MAX
} aiot_ota_option_t;

typedef enum {
    OTA_EVENT_NEW_FIRMWARE
} aiot_ota_event_type_t;

typedef struct {
    char *url;
    uint32_t size;
    char *version;
    char *sign_method;
    char *sign;
} aiot_ota_firmware_t;

typedef struct {
    aiot_ota_event_type_t event_type;
    union {
       aiot_ota_firmware_t firmware;
    } data;
} aiot_ota_event_t;

typedef int32_t (*aiot_ota_event_handle_t)(void *handle, aiot_ota_event_t *event, void *userdata);

/**
 * @brief init ota handle and set default parameter
 * 
 * @return void* 
 * @retval NotNULL ota handle
 * @retval NULL init failed
 *
 * @brief
 * @brief --------------------------------------------------
 *
 * @brief 初始化ota句柄并设置默认参数
 *
 * @return void*
 * @retval 非NULL ota句柄
 * @retval NULL 初始化失败
 */
void* aiot_ota_init(void);

/**
 * @brief set ota configuration
 *
 * @param[in] handle the ota handle
 * @param[in] option the configuration option, see @ref aiot_ota_option_t
 * @param[in] data   the configuration data, see @ref aiot_ota_option_t
 *
 * @return int32_t
 * @retval <ERRCODE_SUCCESS set opt failed
 * @retval >=ERRCODE_SUCCESS set opt succeed
 *
 * @brief
 * @brief --------------------------------------------------
 *
 * @brief 设置ota参数
 *
 * @param[in] handle ota句柄
 * @param[in] option 配置选项, 更多信息请参考@ref aiot_ota_option_t
 * @param[in] data   配置选项数据，更多信息请参考@ref aiot_ota_option_t
 *
 * @return int32_t
 * @retval <ERRCODE_SUCCESS 参数设置失败
 * @retval >=ERRCODE_SUCCESS 参数设置成功
 *
 */
int32_t aiot_ota_setopt(void *handle, aiot_ota_option_t option, void *data);

/**
 * @brief enable ota function, you must call this function to enable ota module after a series calling @ref aiot_ota_setopt
 * 
 * you can receive new firmware notification only after success calling of this function.
 * 
 * @param[in] handle the ota handle
 * @return int32_t 
 * @retval <ERRCODE_SUCCESS enable failed, possibly cased the failure of calling @ref aiot_mqtt_init
 * @retval >=ERRCODE_SUCCESS enable success
 * 
 * @note ota module works only after mqtt module initialized, the new firmware notification is received by @ref aiot_mqtt_recv, \n
 *       and notify through @ref OTA_EVENT_NEW_FIRMWARE event
 * 
 * @brief
 * @brief --------------------------------------------------
 * 
 * @brief 使能ota模块，在调用@ref aiot_ota_setopt 设置好ota参数后，必须调用该函数使能ota模块
 * 
 * 只有当此函数调用成功后，应用程序才能正常接收新固件通知
 * 
 * @param[in] handle ota句柄
 * @return int32_t 
 * @retval <ERRCODE_SUCCESS 使能ota失败，可能是由于@ref aiot_mqtt_init 调用失败，导致mqtt_handle无法使用
 * @retval >=ERRCODE_SUCCESS 使能ota成功
 * 
 * @note 在使用ota模块之前，请先初始化mqtt模块，新固件通知信息将由by @ref aiot_mqtt_recv 获取，并通过@ref OTA_EVENT_NEW_FIRMWARE 事件进行通知
 */
int32_t aiot_ota_enable(void *handle);

/**
 * @brief report version of current running firmware
 * 
 * 1. before ota process, you must report your own firmware version for identifying your firmware correctly by server.\n
 * 2. after ota succeed, you must report your new firmware version to indicating the upgrading is successful, or the \n
 *    process bar on the server will never reach 100%.
 * 
 * @param handle the ota handle
 * @param version current firmware version
 * @return int32_t 
 * @retval <ERRCODE_SUCCESS report failed, possibly cased the failure of calling @ref aiot_mqtt_connect
 * @retval >=ERRCODE_SUCCESS report firmware version succeed
 * 
 * @note as reporting firmware version is using mqtt connection, the mqtt connection must be established first
 * 
 * @brief
 * @brief --------------------------------------------------
 * 
 * @brief 上报当前固件的版本号
 * 
 * 1. 在进行ota之前，必须使用该函数上报当前固件的版本号以便服务器能正确识别当前运行的固件。\n
 * 2. 在ota成功结束后，必须使用该函数上报新的固件版本号以便于服务器确认固件升级成功，否则服务器升级进度不能达到100%。
 * 
 * @param handle ota句柄
 * @param version 当前固件版本号
 * @return int32_t 
 * @retval <ERRCODE_SUCCESS 上报固件版本号失败，可能是由于@ref aiot_mqtt_connect 调用失败，尚未与服务器建立连接。
 * @retval >=ERRCODE_SUCCESS 上报固件版本号成功
 * 
 * @note 由于上报版本号使用的是mqtt通道，在上报版本号之前，mqtt连接必须先建立成功
 */
int32_t aiot_ota_report_version(void *handle, char *version);

/**
 * @brief report firmware upgrade progress or uprading error code to server
 * 
 * @param[in] handle ota handle
 * @param[in] value firmware upgrade progress\n
 *            [1,100]: the percetage of upgrade\n
 *            -1: upgrade failed\n
 *            -2: download failed\n
 *            -3: verify firmware failed (this will be report internally if happend)\n
 *            -4: burn firmware failed\n
 * @param[in] desc the discription for current report, can be NULL
 * 
 * @return int32_t
 * @retval <ERRCODE_SUCCESS report failed
 * @retval >=ERRCODE_SUCCESS report succeed
 * 
 * @note as reporting upgrade process is using mqtt connection, the mqtt connection must be established first
 * 
 * @brief
 * @brief --------------------------------------------------
 * 
 * @brief 上报固件升级进度或者固件升级错误码至服务器
 * @param[in] handle ota句柄
 * @param[in] value 升级进度\n
 *            [1,100]: 升级进度百分比\n
 *            -1: 升级失败\n
 *            -2: 下载固件失败\n
 *            -3: 固件验证失败\n
 *            -4: 固件烧录失败\n
 * @param[in] desc 描述信息，可为NULL
 * 
 * @retval <ERRCODE_SUCCESS 上报失败
 * @retval >=ERRCODE_SUCCESS 上报成功
 * 
 * @note 由于上报升级进度使用的是mqtt通道，在上报升级进度之前，mqtt连接必须先建立成功
 */
int32_t aiot_ota_report_progress(void *handle, int32_t value, char *desc);

/**
 * @brief download firmware from server accroding the firmware information assigned by @ref aiot_ota_setopt using 
 *        @ref OTAOPT_DOWNLOAD_FRIMWARE option
 * 
 * @param handle the ota handle
 * @param payload the buffer used to store firmware fragment
 * @param payload_len the max length of payload
 * 
 * @return int32_t 
 * @retval <ERRCODE_SUCCESS some error occur or the current downloading state
 * @retval ERRCODE_OTA_DOWNLOAD_START downloading connection is established
 * @retval ERRCODE_OTA_DOWNLOAD_RENEWAL downloading connection is disconnected and reconnecting is executed internally
 * @retval ERRCODE_OTA_FIRMWARE_VALID_SIGN downloading and verify firmware succeed
 * @retval ERRCODE_OTA_FIRMWARE_INVALID_SIGN downloading and verify firmware failed
 * @retval ERRCODE_OTA_FIRMWARE_UNKNOWN_SIGN_METHOD unknown sign method, the firmware verify is depend on your self
 * @retval ERRCODE_OTA_DOWNLOAD_STOP download and verify firmware completed, there is no need to call this function again
 * @retval >=ERRCODE_SUCCESS the firmware bytes received this time
 * 
 * @note this function is non-block and should be called intermittently. the call to @ref aiot_ota_setopt using @ref \n
 *       OTAOPT_DOWNLOAD_FRIMWARE option will reset downloading state, then this function can be used to a new freshing \n
 *       firmware download
 * 
 * @brief
 * @brief --------------------------------------------------
 * 
 * @brief 从服务器下载固件，固件信息由@ref aiot_ota_setopt 函数的@ref OTAOPT_DOWNLOAD_FRIMWARE 参数指定
 * 
 * @param handle ota句柄
 * @param payload 用来存放固件片段的buffer
 * @param payload_len payload的最大长度
 * 
 * @return int32_t 
 * @retval <ERRCODE_SUCCESS 错误码或者是当前下载流程的状态码
 * @retval ERRCODE_OTA_DOWNLOAD_START 固件下载通道已建立，准备下载固件
 * @retval ERRCODE_OTA_DOWNLOAD_RENEWAL 固件下载通道已断开，正在进行重试
 * @retval ERRCODE_OTA_FIRMWARE_VALID_SIGN 固件下载完成，验证通过
 * @retval ERRCODE_OTA_FIRMWARE_INVALID_SIGN 固件下载完成，验证失败
 * @retval ERRCODE_OTA_FIRMWARE_UNKNOWN_SIGN_METHOD 未知的固件签名方法，固件验证由调用者自行完成
 * @retval ERRCODE_OTA_DOWNLOAD_STOP 固件下载完成，验证通过，流程结束，该函数无需再次被调用
 * @retval >=ERRCODE_SUCCESS 本次获取到的固件片段大小
 * 
 * @note 该函数为非阻塞，需要间歇性被调用。使用@ref aiot_ota_setopt 函数的@ref OTAOPT_DOWNLOAD_FRIMWARE选项可以重置下载状态，\n
 *       然后可以使用此函数进行新一轮的固件下载
 */
int32_t aiot_ota_download(void *handle, uint8_t *payload, uint32_t payload_len);

/**
 * @brief free memory for ota handle
 * 
 * @param handle handle the pointer to the mqtt handle
 * 
 * @return int32_t 
 * @retval <ERRCODE_SUCCESS execute failed
 * @retval >=ERRCODE_SUCCESS execute succeed
 * 
 * @brief
 * @brief --------------------------------------------------
 *
 * @brief 释放ota句柄的资源
 *
 * @param[in] handle 指向ota句柄的指针
 *
 * @return int32_t
 * @retval <ERRCODE_SUCCESS 执行失败
 * @retval >=ERRCODE_SUCCESS 执行成功
 */
int32_t aiot_ota_deinit(void **handle);

#if defined(__cplusplus)
}
#endif
#endif