/**
 * @file aiot_coap_api.h
 * @brief coap module api header file
 * @version 0.1
 * @date 2019-06-18
 *
 * @copyright Copyright (c) 2015-2018 Alibaba Group Holding Limited
 *
 */
#ifndef _AIOT_COAP_API_H_
#define _AIOT_COAP_API_H_

#if defined(__cplusplus)
extern "C" {
#endif

#include <stdio.h>
#include <stdint.h>

/**@brief the role of coap protocol */
#define COAP_ROLE_TYPE_SERVER           (0x00)
#define COAP_ROLE_TYPE_CLIENT           (0x01)

/**@brief the maximum count of options supported for coap message */
#define COAP_OPTION_CNT_MAX             (10)

/**@brief size of coap send buffer, you shall ajust this value if ERRCODE_COAP_BUFFER_TOO_SHORT error occur */
#define COAP_SEND_BUFF_SIZE             (500)

/**@brief size of coap receive buffer, ajust this value if this value is to small for coap message */
#define COAP_RECV_BUFF_SIZE             (500)

/**@brief Enumeration of CoAP options numbers. */
#define COAP_OPTION_IF_MATCH            1   /**< If-Match option number. */
#define COAP_OPTION_URI_HOST            3   /**< URI-Host option number. */
#define COAP_OPTION_ETAG                4   /**< ETag option number. */
#define COAP_OPTION_IF_NONE_MATCH       5   /**< If-None-Match option number. */
#define COAP_OPTION_URI_PORT            7   /**< URI-Port option number. */
#define COAP_OPTION_LOCATION_PATH       8   /**< Location-Path option number. */
#define COAP_OPTION_URI_PATH            11  /**< URI-Path option number. */
#define COAP_OPTION_CONTENT_FORMAT      12  /**< Content-Format option number. */
#define COAP_OPTION_MAX_AGE             14  /**< Max-Age option number. */
#define COAP_OPTION_URI_QUERY           15  /**< URI-Query option number. */
#define COAP_OPTION_ACCEPT              17  /**< Accept option number. */
#define COAP_OPTION_LOCATION_QUERY      20  /**< Location-Query option number. */
#define COAP_OPTION_BLOCK2              23  /**< Block2 option number. */
#define COAP_OPTION_BLOCK1              27  /**< Block1 option number. */
#define COAP_OPTION_SIZE2               28  /**< Size2 option number. */
#define COAP_OPTION_PROXY_URI           35  /**< Proxy-URI option number. */
#define COAP_OPTION_PROXY_SCHEME        39  /**< Proxy-Scheme option number. */
#define COAP_OPTION_SIZE1               60  /**< Size1 option number. */

/*CoAP Content Type*/
#define COAP_CT_TEXT_PLAIN               0  /**< text/plain (UTF-8) */
#define COAP_CT_APP_LINK_FORMAT         40  /**< application/link-format */
#define COAP_CT_APP_XML                 41  /**< application/xml */
#define COAP_CT_APP_OCTET_STREAM        42  /**< application/octet-stream */
#define COAP_CT_APP_RDF_XML             43  /**< application/rdf+xml */
#define COAP_CT_APP_EXI                 47  /**< application/exi  */
#define COAP_CT_APP_JSON                50  /**< application/json  */
#define COAP_CT_APP_CBOR                60  /**< application/cbor  */

/**
 * @brief coap message type
 *
 */
typedef enum {
    COAP_MSG_TYPE_CON                        = 0x00,  /**< CoAP confirmable message type */
    COAP_MSG_TYPE_NON                        = 0x01,  /**< CoAP not confirmable message type */
    COAP_MSG_TYPE_ACK                        = 0x02,  /**< CoAP ack message type */
    COAP_MSG_TYPE_RST                        = 0x03,  /**< CoAP reset message type */
} coap_msg_type_t;

/**
 * @brief coap message method of coap request
 *
 */
typedef enum {
    COAP_METHOD_GET                          = 0x01,  /**< CoAP code 0.01 */
    COAP_METHOD_POST                         = 0x02,  /**< CoAP code 0.02 */
    COAP_METHOD_PUT                          = 0x03,  /**< CoAP code 0.03 */
    COAP_METHOD_DELETE                       = 0x04,  /**< CoAP code 0.04 */
} coap_request_method_t;

/**
 * @brief coap message code of coap response
 *
 */
typedef enum {
    // CoAP Success Response Codes
    COAP_CODE_201_CREATED                    = 0x41,  /**< CoAP code 2.01 */
    COAP_CODE_202_DELETED                    = 0x42,  /**< CoAP code 2.02 */
    COAP_CODE_203_VALID                      = 0x43,  /**< CoAP code 2.03 */
    COAP_CODE_204_CHANGED                    = 0x44,  /**< CoAP code 2.04 */
    COAP_CODE_205_CONTENT                    = 0x45,  /**< CoAP code 2.05 */
    COAP_CODE_231_CONTINUE                   = 0x5F,  /**< CoAP code 2.31 */

    // CoAP Client Error Response Codes
    COAP_CODE_400_BAD_REQUEST                = 0x80,  /**< CoAP code 4.00 */
    COAP_CODE_401_UNAUTHORIZED               = 0x81,  /**< CoAP code 4.01 */
    COAP_CODE_402_BAD_OPTION                 = 0x82,  /**< CoAP code 4.02 */
    COAP_CODE_403_FORBIDDEN                  = 0x83,  /**< CoAP code 4.03 */
    COAP_CODE_404_NOT_FOUND                  = 0x84,  /**< CoAP code 4.04 */
    COAP_CODE_405_METHOD_NOT_ALLOWED         = 0x85,  /**< CoAP code 4.05 */
    COAP_CODE_406_NOT_ACCEPTABLE             = 0x86,  /**< CoAP code 4.06 */
    COAP_CODE_408_REQUEST_ENTITY_INCOMPLETE  = 0x88,  /**< CoAP code 4.08 */
    COAP_CODE_412_PRECONDITION_FAILED        = 0x8C,  /**< CoAP code 4.12 */
    COAP_CODE_413_REQUEST_ENTITY_TOO_LARGE   = 0x8D,  /**< CoAP code 4.13 */
    COAP_CODE_415_UNSUPPORTED_CONTENT_FORMAT = 0x8F,  /**< CoAP code 4.15 */

    // CoAP Server Error Response Codes
    COAP_CODE_500_INTERNAL_SERVER_ERROR      = 0xA0,  /**< CoAP code 5.00 */
    COAP_CODE_501_NOT_IMPLEMENTED            = 0xA1,  /**< CoAP code 5.01 */
    COAP_CODE_502_BAD_GATEWAY                = 0xA2,  /**< CoAP code 5.02 */
    COAP_CODE_503_SERVICE_UNAVAILABLE        = 0xA3,  /**< CoAP code 5.03 */
    COAP_CODE_504_GATEWAY_TIMEOUT            = 0xA4,  /**< CoAP code 5.04 */
    COAP_CODE_505_PROXYING_NOT_SUPPORTED     = 0xA5   /**< CoAP code 5.05 */
} coap_response_code_t;

/**
 * @brief coap header structure
 *
 */
typedef struct {
    uint8_t ver : 2;
    uint8_t t   : 2;
    uint8_t tkl : 4;
    uint8_t code;
    uint16_t msgid;
    uint8_t token[8];
} coap_header_t;

/**
 * @brief coap option structure which is in coap message
 *
 */
typedef struct {
    uint16_t num;
    uint32_t len;
    uint8_t *val;
} coap_option_t;

/**
 * @brief coap message structure
 *
 */
typedef struct {
    coap_header_t header;
    coap_option_t option[COAP_OPTION_CNT_MAX];
    uint8_t option_cnt;

    uint8_t *payload;
    uint32_t payload_len;

    uint8_t *buff;
    uint32_t buff_offset;
} coap_message_t;

/**
 * @brief coap option enum for @ref aiot_coap_setopt api
 *
 */
typedef enum {
    COAPOPT_ROLE,               /**< dataType: uint8_t, coap role, COAP_ROLE_TYPE_SERVER or COAP_ROLE_TYPE_CLIENT */
    COAPOPT_RECV_TIMEOUT_MS,    /**< dataType: uint32_t, udp read timeout*/
    COAPOPT_PORT,               /**< dataType: uint16_t, udp server bind port number*/
    COAPOPT_MAX,
} aiot_coap_option_t;

/**
 * @brief addr for @ref nwk_read_t and @ref nwk_write_t when using tcp or udp server.
 * @brief
 * @brief --------------------------------------------------
 * @brief @ref nwk_read_t 和 @ref nwk_write_ 函数的addr参数。当使用tcp或udp server时可使用
 * 该参数来传递client的地址信息。
 */
typedef struct {
    /**
     * ipv4 dot-decimal notation, max length is 15 bytes.
     *
     * --------------------------------------------------
     *
     * ipv4地址点分十进制字符串，最大长度15字节。
     */
    char addr[16];
    /**
     * udp port
     *
     * --------------------------------------------------
     *
     * udp 端口号
     */
    uint16_t port;
} aiot_coap_addr_t;

/**
 * @brief coap response callback funcition prototype
 *
 * @param handle handle of coap module
 * @param request pointer to request message, see @ref coap_message_t
 * @param remote remote_endpoint, see @ref aiot_coap_addr_t
 * @param user_data pointer to user data
 */
typedef int32_t (*coap_request_cb_t)(void *handle, const coap_message_t *request, aiot_coap_addr_t *remote, void *user_data);

/**
 * @brief coap response callback funcition prototype
 *
 * @param handle handle of coap module
 * @param request pointer to response message, see @ref coap_message_t
 * @param remote remote_endpoint, see @ref aiot_coap_addr_t
 * @param user_data pointer to user data
 */
typedef int32_t (*coap_response_cb_t)(void *handle, const coap_message_t *response, aiot_coap_addr_t *remote, void *user_data);

/**
 * @brief initialize the coap module
 *
 * @return void*
 * @reval NotNULL handle of coap module
 * @reval NULL initializes failed, system callbacks not complete or malloc failed.
 */
void *aiot_coap_init(void);

/**
 * @brief set option of coap module
 *
 * @param handle handle of coap module
 * @param option the configuration option, see @ref aiot_coap_option_t
 * @param data the configuration data, see @ref aiot_coap_option_t
 *
 * @return int32_t
 * @retval ERRCODE_SUCCESS set option successfully
 * @retval <ERRCODE_SUCCESS set option failed
 */
int32_t aiot_coap_setopt(void *handle, aiot_coap_option_t option, void *data);

/**
 * @brief create coap network resource
 *
 * @param handle handle of coap module
 *
 * @return int32_t
 * @retval ERRCODE_SUCCESS create network resource successfully
 * @retval <ERRCODE_SUCCESS create network resource failed
 */
int32_t aiot_coap_connect(void *handle);

/**
 * @brief create one resource for coap sever and register request handler callback function
 *
 * @param handle handle of coap module
 * @param uri the uri path string of the resource
 * @param request_handler the request handler callback function of the resource, see @ref coap_request_cb_t
 * @param user_data pointer to the user data
 *
 * @return int32_t
 * @retval ERRCODE_INVALID_PARAMETER parameter handle, uri or request_handler is NULL; or strlen of uri is 0
 * @retval ERRCODE_COAP_OPTION_CNT_LIMITED the level of uri path is larger than @ref COAP_OPTION_CNT_MAX
 * @retval ERRCODE_MEM_MALLOC_FAILED memery allocate failed
 * @retval ERRCODE_SUCCESS create resource successfully
 */
int32_t aiot_coap_server_create_resource(void *handle, const char *uri, coap_request_cb_t request_handler, void *user_data);

/**
 * @brief remove the resource
 *
 * @param handle handle of coap module
 * @param uri pointer to uri path string that indicate the resource
 *
 * @return int32_t
 * @retval ERRCODE_INVALID_PARAMETER handle or uri is NULL
 * @retval ERROCDE_COAP_RESOURCE_NOT_EXIST the resource is not exist
 * @retval ERRCODE_SUCCESS remvoe resource successfully
 */
int32_t aiot_coap_server_remove_resource(void *handle, const char *uri);

/**
 * @brief create one coap request message
 *
 * @param handle handle of coap module
 * @param method the method type of request, see @ref coap_request_method_t
 * @param is_reliable create a CON message if > 0, otherwise create a NON message
 * @param response_handler the response handler callback function of this request, see @ref coap_response_cb_t
 * @param user_data pointer to the user data
 * @param[out] request pointer to be filled by the allocated coap message
 *
 * @return int32_t
 * @retval ERRCODE_INVALID_PARAMETER, parameter handle or request is NULL
 * @retval ERRCODE_MEM_MALLOC_FAILED, memery allocate failed
 * @retval ERRCODE_SUCCESS create request message successfully
 */
int32_t aiot_coap_create_request_message(void *handle, coap_request_method_t method, uint8_t is_reliable, coap_response_cb_t response_handler, void *user_data, void **request);

/**
 * @brief create one coap response message
 *
 * @param handle handle of coap module
 * @param requset_header the coap header of the corresponding request, see @ref coap_header_t
 * @param return_code return code of this response, see @ref coap_response_code_t
 * @param[out] response pointer to be filled by the allocated coap message
 *
 * @return int32_t
 * @retval ERRCODE_INVALID_PARAMETER parameter handle or response if NULL, or the value of t in requset_header is neither COAP_MSG_TYPE_CON nor COAP_MSG_TYPE_NON.
 * @retval ERRCODE_MEM_MALLOC_FAILED, memery allocate failed
 * @retval ERRCODE_SUCCESS create response message successfully
 */
int32_t aiot_coap_create_response_message(void *handle, const coap_header_t *requset_header, coap_response_code_t return_code, void **response);

/**
 * @brief create one coap empty message
 *
 * @param handle handle of coap module
 * @param type coap message type of this empty message, see @ref coap_msg_type_t, value COAP_MSG_TYPE_NON is forbidden
 * @param msgid the message id of this empty message
 * @param[out] empty pointer to be filled by the allocated coap message
 *
 * @return int32_t
 * @retval ERRCODE_INVALID_PARAMETER parameter handle or response if NULL, or the value of type is COAP_MSG_TYPE_NON
 * @retval ERRCODE_MEM_MALLOC_FAILED, memery allocate failed
 * @retval ERRCODE_SUCCESS create empty message successfully
 */
int32_t aiot_coap_create_empty_message(void *handle, coap_msg_type_t type, uint32_t msgid, void **empty);

/**
 * @brief add one option to the coap message
 *
 * @param message pointer to the message to add the option to
 * @param opt_num the option number of the option
 * @param opt_data pointer to the date of the option data
 * @param opt_len the length of the option data
 *
 * @return int32_t
 * @retval ERRCODE_INVALID_PARAMETER parameter message is NULL
 * @retval ERRCODE_COAP_PROTO_NOT_ALLOW the message is an empty message
 * @retval ERRCODE_COAP_OPTION_CNT_LIMITED the count of option larger than @ref COAP_OPTION_CNT_MAX
 * @retval ERRCODE_COAP_OPT_NOT_IN_ORDER should invoke this function in ascending ordor of option number
 * @retval ERRCODE_COAP_BUFFER_TOO_SHORT @ref COAP_SEND_BUFF_SIZE is too small
 * @retval ERRCODE_SUCCESS execute successfully
 */
int32_t aiot_coap_add_option(coap_message_t *message, uint16_t opt_num, uint8_t *opt_data, uint32_t opt_len);

/**
 * @brief get option from the message
 *
 * @param message pointer to the message to get the option from
 * @param option_num the option number of the option
 * @param[out] option pointer to be filled by the option
 * @param[out] option_cnt pointer to the count of option
 *
 * @return int32_t
 * @retval ERRCODE_SUCCESS execute successfully
 */
int32_t aiot_coap_get_option(coap_message_t *message, uint32_t option_num, coap_option_t **option, uint8_t *option_cnt);

/**
 * @brief send the coap message
 *
 * @param handle handle of coap module
 * @param coap_message pointer to the coap message
 * @param paylaod pointer to the payload of this message
 * @param payload_len length of the payload
 * @param remote remote endpoint, see @ref aiot_coap_addr_t
 *
 * @return int32_t
 * @retval ERRCODE_INVALID_PARAMETER parameter handle or coap_message is NULL
 * @retval ERRCODE_COAP_BUFFER_TOO_SHORT @ref COAP_SEND_BUFF_SIZE is too small
 * @retval ERRCODE_COAP_NWK_SEND_FAILED network error
 * @retval ERRCODE_SUCCESS execute successfully
 */
int32_t aiot_coap_send_message(void *handle, void *coap_message, uint8_t *paylaod, uint32_t payload_len, aiot_coap_addr_t *remote);

/**
 * @brief release memery of the message
 *
 * @param handle handle of coap module
 * @param message pointer to the message to be released
 *
 * @return int32_t
 * @retval ERRCODE_INVALID_PARAMETER parameter handle or message is NULL
 * @retval ERRCODE_SUCCESS execute successfully
 */
int32_t aiot_coap_release_message(void *handle, void *message);

/**
 * @brief receive network data and process coap message
 *
 * @param[in] handle handle of coap module
 *
 * @return int32_t
 * @retval ERRCODE_INVALID_PARAMETER
 * @retval ERRCODE_SYS_NWK_CLOSED
 * @retval ERRCODE_SUCCESS
 * @retval others coap message parse error
 */
int32_t aiot_coap_recv(void *handle);

/**
 * @brief release resource of coap module
 *
 * @param[in] handle pointer to the coap handle
 *
 * @return int32_t
 * @retval ERRCODE_SUCCESS execute success
 * @retval ERRCODE_INVALID_PARAMETER handle is NULL or the content of handle is NULL
 */
int32_t aiot_coap_deinit(void **handle);

#if defined(__cplusplus)
}
#endif
#endif /* #ifndef _AIOT_COAP_API_H_ */